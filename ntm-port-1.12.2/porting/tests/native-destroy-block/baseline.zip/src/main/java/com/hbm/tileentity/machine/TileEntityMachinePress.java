package com.hbm.tileentity.machine;

import com.hbm.blocks.ModBlocks;
import com.hbm.blocks.generic.BlockPlushie.PlushieType;
import com.hbm.blocks.generic.BlockPlushie.TileEntityPlushie;
import com.hbm.explosion.vanillant.ExplosionVNT;
import com.hbm.explosion.vanillant.standard.EntityProcessorCrossSmooth;
import com.hbm.explosion.vanillant.standard.ExplosionEffectWeapon;
import com.hbm.explosion.vanillant.standard.PlayerProcessorStandard;
import com.hbm.inventory.container.ContainerMachinePress;
import com.hbm.inventory.gui.GUIMachinePress;
import com.hbm.inventory.recipes.PressRecipes;
import com.hbm.items.machine.ItemStamp;
import com.hbm.tileentity.IGUIProvider;
import com.hbm.tileentity.TileEntityMachineBase;

import com.hbm.util.BufferUtil;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityFurnace;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import com.hbm.lib.ForgeDirection;

public class TileEntityMachinePress extends TileEntityMachineBase implements IGUIProvider {

	public int speed = 0; // speed ticks up once (or four times if preheated) when operating
	public static final int maxSpeed = 400; // max speed ticks for acceleration
	public static final int progressAtMax = 25; // max progress speed when hot
	public int burnTime = 0; // burn ticks of the loaded fuel, 200 ticks equal one operation

	public int press; // extension of the press, operation is completed if maxPress is reached
	public double renderPress; // client-side version of the press var, a double for smoother rendering
	public double lastPress; // for interp
	private int syncPress; // for interp
	private int turnProgress; // for interp 3: revenge of the sith
	public final static int maxPress = 200; // max tick count per operation assuming speed is 1
	boolean isRetracting = false; // direction the press is currently going
	private int delay; // delay between direction changes to look a bit more appealing

	public ItemStack syncStack;

	public TileEntityMachinePress() {
		super(4);
	}

	@Override
	public String getDefaultName() {
		return "container.press";
	}

	@Override
	public void update() {

		if(!this.world.isRemote) {

			// Triggers the legacy monoblock fix
			if (com.hbm.world.WorldBlockState.metadata(com.hbm.world.WorldBlockState.read(this.world, this.pos.getX(), this.pos.getY(), this.pos.getZ()) ) < 12) {
				this.world.scheduleUpdate(new net.minecraft.util.math.BlockPos(this.pos.getX(), this.pos.getY(), this.pos.getZ()), com.hbm.world.WorldBlockState.read(this.world, this.pos.getX(), this.pos.getY(), this.pos.getZ()).getBlock(), 1);
			}

			boolean preheated = false;

			for(ForgeDirection dir : ForgeDirection.VALID_DIRECTIONS) {
				if(com.hbm.world.WorldBlockState.read(this.world, this.pos.getX() + dir.offsetX, this.pos.getY() + dir.offsetY, this.pos.getZ() + dir.offsetZ).getBlock() == ModBlocks.press_preheater) {
					preheated = true;
					break;
				}
			}

			boolean canProcess = this.canProcess();

			if((canProcess || this.isRetracting) && this.burnTime >= 200) {
				this.speed += preheated ? 4 : 1;

				if(this.speed > this.maxSpeed) {
					this.speed = this.maxSpeed;
				}
			} else {
				this.speed -= 1;
				if(this.speed < 0) {
					this.speed = 0;
				}
			}

			if(delay <= 0) {

				int stampSpeed = speed * progressAtMax / maxSpeed;

				if(this.isRetracting) {
					this.press -= stampSpeed;

					if(this.press <= 0) {
						this.isRetracting = false;
						this.delay = 5;
					}
				} else if(canProcess) {
					this.press += stampSpeed;

					if(this.press >= this.maxPress) {
						String squish = "hbm:block.pressOperate";
						TileEntity tile = this.world.getTileEntity(new net.minecraft.util.math.BlockPos(this.pos.getX(), this.pos.getY() + 1, this.pos.getZ()));
						if(tile instanceof TileEntityPlushie) {
							TileEntityPlushie plushie = (TileEntityPlushie) tile;
							squish = "hbm:block.squeakyPain";

							if(plushie.type == PlushieType.HUNDUN) {
								this.world.func_147480_a(this.pos.getX(), this.pos.getY(), this.pos.getZ(), false);
								ExplosionVNT vnt = new ExplosionVNT(this.world, this.pos.getX() + 0.5, this.pos.getY() + 0.5, this.pos.getZ() + 0.5, 5);
								vnt.setEntityProcessor(new EntityProcessorCrossSmooth(1, 50));
								vnt.setPlayerProcessor(new PlayerProcessorStandard());
								vnt.setSFX(new ExplosionEffectWeapon(10, 2.5F, 1F));
								vnt.explode();
							}
						}
						this.world.playSoundEffect(this.pos.getX(), this.pos.getY(), this.pos.getZ(), squish, getVolume(1.5F), 1.0F);
						ItemStack output = PressRecipes.getOutput(slots[2], slots[1]);
						if(slots[3] == null) {
							slots[3] = output.copy();
						} else {
							slots[3].stackSize += output.stackSize;
						}
						this.decrStackSize(2, 1);

						if(slots[1].getMaxDamage() != 0) {
							slots[1].setItemDamage(slots[1].getItemDamage() + 1);
							if(slots[1].getItemDamage() >= slots[1].getMaxDamage()) {
								slots[1] = null;
							}
						}

						this.isRetracting = true;
						this.delay = 5;
						if(this.burnTime >= 200) {
							this.burnTime -= 200; // only subtract fuel if operation was actually successful
						}

						this.markDirty();
					}
				} else if(this.press > 0){
					this.isRetracting = true;
				}
			} else {
				delay--;
			}

			if(slots[0] != null && burnTime < 200 && TileEntityFurnace.getItemBurnTime(slots[0]) > 0) { // less than one operation stored? burn more fuel!
				burnTime += TileEntityFurnace.getItemBurnTime(slots[0]);

				if(slots[0].stackSize == 1 && slots[0].getItem().hasContainerItem(slots[0])) {
					slots[0] = slots[0].getItem().getContainerItem(slots[0]).copy();
				} else {
					this.decrStackSize(0, 1);
				}
				this.markChanged();
			}

			this.networkPackNT(50);

		} else {

			// approach-based interpolation, GO!
			this.lastPress = this.renderPress;

			if(this.turnProgress > 0) {
				this.renderPress = this.renderPress + ((this.syncPress - this.renderPress) / (double) this.turnProgress);
				--this.turnProgress;
			} else {
				this.renderPress = this.syncPress;
			}

			TileEntity te = this.world.getTileEntity(new net.minecraft.util.math.BlockPos(this.pos.getX(), this.pos.getY() + 1, this.pos.getZ()));
			if(te instanceof TileEntityPlushie) {
				TileEntityPlushie abuseTarget = (TileEntityPlushie) te;
				abuseTarget.miseryFactor = MathHelper.clamp(((float)syncPress - 100.0F) / 100.0F, (float) (0), (float) (1));
			}
		}
	}

	@Override
	public void serialize(ByteBuf buf) {
		super.serialize(buf);
		buf.writeInt(this.speed);
		buf.writeInt(this.burnTime);
		buf.writeInt(this.press);
		BufferUtil.writeItemStack(buf, slots[2]);
	}

	@Override
	public void deserialize(ByteBuf buf) {
		super.deserialize(buf);
		this.speed = buf.readInt();
		this.burnTime = buf.readInt();
		this.syncPress = buf.readInt();
		this.syncStack = BufferUtil.readItemStack(buf);

		this.turnProgress = 2;
	}

	public boolean canProcess() {
		if(burnTime < 200) return false;
		if(slots[1] == null || slots[2] == null) return false;

		ItemStack output = PressRecipes.getOutput(slots[2], slots[1]);

		if(output == null) return false;

		if(slots[3] == null) return true;
		if(slots[3].stackSize + output.stackSize <= slots[3].getMaxStackSize() && slots[3].getItem() == output.getItem() && slots[3].getItemDamage() == output.getItemDamage()) return true;
		return false;
	}

	@Override
	public boolean isItemValidForSlot(int i, ItemStack stack) {

		if(stack.getItem() instanceof ItemStamp)
			return i == 1;

		if(TileEntityFurnace.getItemBurnTime(stack) > 0 && i == 0)
			return true;

		return i == 2;
	}

	@Override
	public int[] getSlotsForFace(net.minecraft.util.EnumFacing nativeFace) {
		int side = com.hbm.lib.ForgeDirection.fromEnumFacing(nativeFace).ordinal();
		return new int[] { 0, 1, 2, 3 };
	}

	@Override
	public boolean canInsertItem(int i, ItemStack itemStack, net.minecraft.util.EnumFacing nativeFace) {
		int j = com.hbm.lib.ForgeDirection.fromEnumFacing(nativeFace).ordinal();
		return this.isItemValidForSlot(i, itemStack);
	}

	@Override
	public boolean canExtractItem(int i, ItemStack itemStack, net.minecraft.util.EnumFacing nativeFace) {
		int j = com.hbm.lib.ForgeDirection.fromEnumFacing(nativeFace).ordinal();
		return i == 3;
	}

	@Override
	public void readFromNBT(NBTTagCompound nbt) {
		super.readFromNBT(nbt);
		press = nbt.getInteger("press");
		burnTime = nbt.getInteger("burnTime");
		speed = nbt.getInteger("speed");
		isRetracting = nbt.getBoolean("ret");
	}

	@Override
	public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
		super.writeToNBT(nbt);
		nbt.setInteger("press", press);
		nbt.setInteger("burnTime", burnTime);
		nbt.setInteger("speed", speed);
		nbt.setBoolean("ret", isRetracting);
		return nbt;
	}

	AxisAlignedBB aabb;

	@Override
	public AxisAlignedBB getRenderBoundingBox() {

		if(aabb != null)
			return aabb;

		aabb = AxisAlignedBB.getBoundingBox(this.pos.getX(), this.pos.getY(), this.pos.getZ(), this.pos.getX() + 1, this.pos.getY() + 3, this.pos.getZ() + 1);
		return aabb;
	}

	@Override
	@SideOnly(Side.CLIENT)
	public double getMaxRenderDistanceSquared() {
		return 65536.0D;
	}

	@Override
	public Container provideContainer(int ID, EntityPlayer player, World world, int x, int y, int z) {
		return new ContainerMachinePress(player.inventory, this);
	}

	@Override
	@SideOnly(Side.CLIENT)
	public Object provideGUI(int ID, EntityPlayer player, World world, int x, int y, int z) {
		return new GUIMachinePress(player.inventory, this);
	}
}