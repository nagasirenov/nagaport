package com.hbm.blocks.generic;

import java.util.Random;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.world.World;

public class BlockLithium extends BlockBeaconable {

	public BlockLithium(Material material) {
		super(material);
	}

	private boolean touchesWater(World world, int x, int y, int z) {

		if (world.isRemote)
			return false;

		return com.hbm.world.WorldBlockState.read(world, x + 1, y, z).getBlock().getDefaultState().getMaterial() == Material.WATER
				|| com.hbm.world.WorldBlockState.read(world, x - 1, y, z).getBlock().getDefaultState().getMaterial() == Material.WATER
				|| com.hbm.world.WorldBlockState.read(world, x, y + 1, z).getBlock().getDefaultState().getMaterial() == Material.WATER
				|| com.hbm.world.WorldBlockState.read(world, x, y - 1, z).getBlock().getDefaultState().getMaterial() == Material.WATER
				|| com.hbm.world.WorldBlockState.read(world, x, y, z + 1).getBlock().getDefaultState().getMaterial() == Material.WATER
				|| com.hbm.world.WorldBlockState.read(world, x, y, z - 1).getBlock().getDefaultState().getMaterial() == Material.WATER;
	}

	public void onNeighborBlockChange(World world, int x, int y, int z, Block block) {

		if (touchesWater(world, x, y, z)) {
			world.func_147480_a(x, y, z, false);
			world.newExplosion(null, x + 0.5, y + 0.5, z + 0.5, 15, false, true);
		}
	}

	public int onBlockPlaced(World world, int x, int y, int z, int side, float fx, float fy, float fz, int meta) {

		if (touchesWater(world, x, y, z)) {
			world.func_147480_a(x, y, z, false);
			world.newExplosion(null, x + 0.5, y + 0.5, z + 0.5, 15, false, true);
		}

		return meta;
	}

	@SideOnly(Side.CLIENT)
	public void randomDisplayTick(World world, int x, int y, int z, Random rand) {

		if (world.canLightningStrikeAt(x, y + 1, z)) {

			float ox = rand.nextFloat();
			float oz = rand.nextFloat();

			world.spawnParticle(net.minecraft.util.EnumParticleTypes.SMOKE_LARGE, x + ox, y + 1, z + oz, 0.0D, 0.0D, 0.0D);
		}
	}
}
