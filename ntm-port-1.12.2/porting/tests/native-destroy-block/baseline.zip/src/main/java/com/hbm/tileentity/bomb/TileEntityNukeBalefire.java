package com.hbm.tileentity.bomb;

import com.hbm.entity.effect.EntityNukeTorex;
import com.hbm.entity.logic.EntityBalefire;
import com.hbm.inventory.container.ContainerNukeFstbmb;
import com.hbm.inventory.gui.GUINukeFstbmb;
import com.hbm.items.ModItems;
import com.hbm.tileentity.IGUIProvider;
import com.hbm.tileentity.TileEntityMachineBase;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.world.World;

public class TileEntityNukeBalefire extends TileEntityMachineBase implements IGUIProvider {

	public boolean loaded;
	public boolean started;
	public int timer;

	public TileEntityNukeBalefire() {
		super(2);
		timer = 18000;
	}

	@Override
	public String getDefaultName() {
		return "container.nukeFstbmb";
	}

	@Override
	public void update() {
		
		if(!this.world.isRemote) {
			
			this.loaded = this.isLoaded();
			
			if(!loaded) {
				started = false;
			}
			
			if(started) {
				timer--;
				
				if(timer % 20 == 0)
					com.hbm.sound.WorldSoundEffects.play(this.world, this.pos.getX(), this.pos.getY(), this.pos.getZ(), "hbm:weapon.fstbmbPing", 5.0F, 1.0F);
			}
			
			if(timer <= 0) {
				explode();
			}

			networkPackNT(250);
		}
	}

	@Override
	public void serialize(ByteBuf buf) {
		super.serialize(buf);

		buf.writeInt(this.timer);
		buf.writeBoolean(this.started);
		buf.writeBoolean(this.loaded);
	}

	@Override
	public void deserialize(ByteBuf buf) {
		super.deserialize(buf);

		this.timer = buf.readInt();
		this.started = buf.readBoolean();
		this.loaded = buf.readBoolean();
	}

	public void handleButtonPacket(int value, int meta) {
		
		if(meta == 0 && this.isLoaded()) {
			com.hbm.sound.WorldSoundEffects.play(this.world, this.pos.getX(), this.pos.getY(), this.pos.getZ(), "hbm:weapon.fstbmbStart", 5.0F, 1.0F);
			started = true;
		}
		
		if(meta == 1)
			timer = value * 20;
	}
	
	public boolean isLoaded() {
		return hasEgg() && hasBattery();
	}
	
	public boolean hasEgg() {
		if(slots[0] != null && slots[0].getItem() == ModItems.egg_balefire) return true;
		return false;
	}
	
	public boolean hasBattery() {
		return getBattery() > 0;
	}
	
	public int getBattery() {
		if(slots[1] != null && slots[1].getItem() == ModItems.battery_spark) return 1;
		if(slots[1] != null && slots[1].getItem() == ModItems.battery_trixite) return 2;
		return 0;
	}
	
	public void explode() {
		
		for(int i = 0; i < slots.length; i++)
			slots[i] = null;
		
		this.world.func_147480_a(this.pos.getX(), this.pos.getY(), this.pos.getZ(), false);
		
		EntityBalefire bf = new EntityBalefire(this.world);
		bf.posX = this.pos.getX() + 0.5;
		bf.posY = this.pos.getY() + 0.5;
		bf.posZ = this.pos.getZ() + 0.5;
		bf.destructionRange = (int) 250;
		this.world.spawnEntityInWorld(bf);
		EntityNukeTorex.statFacBale(this.world, this.pos.getX() + 0.5, this.pos.getY() + 0.5, this.pos.getZ() + 0.5, 250);
	}
	
	public String getMinutes() {
		
		String mins = "" + (timer / 1200);
		
		if(mins.length() == 1)
			mins = "0" + mins;
		
		return mins;
	}
	
	public String getSeconds() {
		
		String mins = "" + ((timer / 20) % 60);
		
		if(mins.length() == 1)
			mins = "0" + mins;
		
		return mins;
	}
	
	@Override
	public void readFromNBT(NBTTagCompound nbt) {
		super.readFromNBT(nbt);
		
		started = nbt.getBoolean("started");
		timer = nbt.getInteger("timer");
	}
	
	@Override
	public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
		super.writeToNBT(nbt);
		
		nbt.setBoolean("started", started);
		nbt.setInteger("timer", timer);
		return nbt;
	}
	
	@Override
	public AxisAlignedBB getRenderBoundingBox() {
		return TileEntity.INFINITE_EXTENT_AABB;
	}
	
	@Override
	@SideOnly(Side.CLIENT)
	public double getMaxRenderDistanceSquared()
	{
		return 65536.0D;
	}

	@Override
	public Container provideContainer(int ID, EntityPlayer player, World world, int x, int y, int z) {
		return new ContainerNukeFstbmb(player.inventory, this);
	}

	@Override
	@SideOnly(Side.CLIENT)
	public Object provideGUI(int ID, EntityPlayer player, World world, int x, int y, int z) {
		return new GUINukeFstbmb(player.inventory, this);
	}
}
