package com.hbm.tileentity.bomb;

import com.hbm.entity.effect.EntityNukeTorex;
import com.hbm.entity.logic.EntityBalefire;
import com.hbm.inventory.container.ContainerNukeAntimatter;
import com.hbm.inventory.gui.GUINukeAntimatter;
import com.hbm.items.ModItems;
import com.hbm.tileentity.IGUIProvider;
import com.hbm.tileentity.TileEntityMachineBase;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.world.World;

public class TileEntityAntimatter extends TileEntityMachineBase implements IGUIProvider {

	public boolean loaded;
	public boolean started;
	public int timer;

	public TileEntityAntimatter() {
		super(8);
		timer = 18000;
	}

	@Override
	public String getDefaultName() {
		return "container.nukeAntimatter";
	}

	@Override
	public void update() {
		
		if(!this.world.isRemote) {
			
			if(!this.isLoaded()) {
				started = false;
			}
			
			if(started) {
				timer--;
				
				if(timer % 20 == 0)
					com.hbm.sound.WorldSoundEffects.play(this.world, this.pos.getX(), this.pos.getY(), this.pos.getZ(), "hbm:weapon.fstbmbPing", 5.0F, 1.0F);
			}
			
			if(timer <= 0) {
				explode();
			}

			networkPackNT(250);
		}
	}

	@Override
	public void serialize(ByteBuf buf) {
		buf.writeInt(timer);
		buf.writeBoolean(isLoaded());
		buf.writeBoolean(started);
	}

	@Override
	public void deserialize(ByteBuf buf) {
		timer = buf.readInt();
		loaded = buf.readBoolean();
		started = buf.readBoolean();
	}
	
	public void handleButtonPacket(int value, int meta) {
		
		if(meta == 0 && this.isLoaded()) {
			com.hbm.sound.WorldSoundEffects.play(this.world, this.pos.getX(), this.pos.getY(), this.pos.getZ(), "hbm:weapon.fstbmbStart", 5.0F, 1.0F);
			started = true;
		}
		
		if(meta == 1)
			timer = value * 20;
	}
	
	public boolean isLoaded() {
		
		return hasAmatCore() && hasRest();
	}
	
	public boolean hasAmatCore() {
		
		if(slots[2] != null && slots[2].getItem() == ModItems.pellet_antimatter) {
			return true;
		}
		
		return false;
	}
	
	public boolean hasRest() {
		
		return getRest() > 0;
	}
	
	public int getRest() {
		
		if(slots[0] != null && slots[1] != null && slots[3] != null && slots[4] != null && slots[1].getItem() == ModItems.particle_lead && slots[0].getItem() == ModItems.particle_lead && 
				slots[3].getItem() == ModItems.ingot_hafnium && slots[4].getItem() == ModItems.ingot_hafnium) {
			return 1;
		}
		
		return 0;
	}
	
	public void explode() {
		
		for(int i = 0; i < slots.length; i++)
			slots[i] = null;
		
		this.world.func_147480_a(this.pos.getX(), this.pos.getY(), this.pos.getZ(), false);
		
		EntityBalefire bf = new EntityBalefire(this.world);
		bf.antimatter();
		bf.posX = this.pos.getX() + 0.5;
		bf.posY = this.pos.getY() + 0.5;
		bf.posZ = this.pos.getZ() + 0.5;
		bf.destructionRange = (int) 150;
		this.world.spawnEntityInWorld(bf);
		EntityNukeTorex.startFacAnti(this.world, this.pos.getX() + 0.5, this.pos.getY() + 5, this.pos.getZ() + 0.5, 1000);
	}
	
	public String getMinutes() {
		
		String mins = "" + (timer / 1200);
		
		if(mins.length() == 1)
			mins = "0" + mins;
		
		return mins;
	}
	
	public String getSeconds() {
		
		String mins = "" + ((timer / 20) % 60);
		
		if(mins.length() == 1)
			mins = "0" + mins;
		
		return mins;
	}
	
	@Override
	public void readFromNBT(NBTTagCompound nbt) {
		super.readFromNBT(nbt);
		
		started = nbt.getBoolean("started");
		timer = nbt.getInteger("timer");
	}
	
	@Override
	public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
		super.writeToNBT(nbt);
		
		nbt.setBoolean("started", started);
		nbt.setInteger("timer", timer);
		return nbt;
	}
	
	@Override
	public AxisAlignedBB getRenderBoundingBox() {
		return TileEntity.INFINITE_EXTENT_AABB;
	}
	
	@Override
	@SideOnly(Side.CLIENT)
	public double getMaxRenderDistanceSquared()
	{
		return 65536.0D;
	}

	@Override
	public Container provideContainer(int ID, EntityPlayer player, World world, int x, int y, int z) {
		return new ContainerNukeAntimatter(player.inventory, this);
	}

	@Override
	@SideOnly(Side.CLIENT)
	public Object provideGUI(int ID, EntityPlayer player, World world, int x, int y, int z) {
		return new GUINukeAntimatter(player.inventory, this);
	}
}
