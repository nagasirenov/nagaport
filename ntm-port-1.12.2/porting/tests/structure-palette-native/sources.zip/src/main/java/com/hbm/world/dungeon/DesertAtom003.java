//Schematic to java Structure by jajo_11 | inspired by "MITHION'S.SCHEMATIC TO JAVA CONVERTINGTOOL"

package com.hbm.world.dungeon;

import java.util.Random;

import com.hbm.blocks.ModBlocks;
import com.hbm.config.GeneralConfig;
import com.hbm.itempool.ItemPool;
import com.hbm.itempool.ItemPoolsLegacy;
import com.hbm.lib.Library;
import com.hbm.tileentity.machine.storage.TileEntityMachinePuF6Tank;
import com.hbm.tileentity.machine.storage.TileEntityMachineUF6Tank;

import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemDoor;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import com.hbm.lib.WeightedRandomChestContent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class DesertAtom003
{
	Block Block2 = ModBlocks.yellow_barrel;
	Block Block3 = ModBlocks.reinforced_sand;
	Block Block4 = ModBlocks.nuke_man;
	Block Block5 = ModBlocks.deco_steel;
	Block Block6 = ModBlocks.brick_light;
	Block Block7 = ModBlocks.deco_tungsten;
	Block Block8 = ModBlocks.steel_poles;
	Block Block9 = ModBlocks.tape_recorder;
	Block Block10 = ModBlocks.machine_rtg_furnace_off;
	Block Block11 = ModBlocks.reinforced_glass;
	Block Block12 = ModBlocks.reinforced_lamp_off;
	Block Block13 = ModBlocks.pole_satellite_receiver;
	Block Block14 = ModBlocks.pwr_fuel;
	Block Block15 = ModBlocks.deco_titanium;
	Block Block16 = ModBlocks.block_lead;
	Block Block17 = ModBlocks.ore_schrabidium;
	Block Block18 = ModBlocks.waste_planks;
	Block Block19 = ModBlocks.machine_centrifuge;
	Block Block20 = ModBlocks.machine_uf6_tank;
	Block Block21 = ModBlocks.machine_puf6_tank;
	Block Block22 = ModBlocks.reinforced_brick;
	Block Block23 = ModBlocks.waste_earth;
	Block Block24 = ModBlocks.deco_lead;
	Block Block25 = ModBlocks.red_wire_coated;
	Block Block26 = ModBlocks.block_uranium;
	Block Block27 = ModBlocks.pole_top;
	Block Block28 = ModBlocks.capacitor_copper;
	Block Block29 = ModBlocks.machine_electric_furnace_off;
	
	public boolean generate_r00(World world, Random rand, int x, int y, int z)
    {
		world.setBlock(x + 21, y + 3, z + 12, Block6, 0, 3);
		world.setBlock(x + 22, y + 3, z + 12, Block6, 0, 3);
		world.setBlock(x + 23, y + 3, z + 12, Block6, 0, 3);
		world.setBlock(x + 24, y + 3, z + 12, Block6, 0, 3);
		world.setBlock(x + 25, y + 3, z + 12, Block6, 0, 3);
		world.setBlock(x + 26, y + 3, z + 12, Block6, 0, 3);
		world.setBlock(x + 27, y + 3, z + 12, Block6, 0, 3);
		world.setBlock(x + 28, y + 3, z + 12, Block6, 0, 3);
		world.setBlock(x + 29, y + 3, z + 12, Block6, 0, 3);
		world.setBlock(x + 30, y + 3, z + 12, Block6, 0, 3);
		world.setBlock(x + 31, y + 3, z + 12, Block6, 0, 3);
		world.setBlock(x + 32, y + 3, z + 12, Block6, 0, 3);
		world.setBlock(x + 33, y + 3, z + 12, Block6, 0, 3);
		world.setBlock(x + 34, y + 3, z + 12, Block6, 0, 3);
		world.setBlock(x + 35, y + 3, z + 12, Block6, 0, 3);
		world.setBlock(x + 36, y + 3, z + 12, Block18, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 3; int nativePlacementZ = z + 12; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 40, y + 3, z + 12, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 13, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 4, y + 3, z + 13, Block5, 0, 3);
		world.setBlock(x + 5, y + 3, z + 13, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 3, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 7, y + 3, z + 13, Block16, 4, 3);
		world.setBlock(x + 8, y + 3, z + 13, Block14, 0, 3);
		world.setBlock(x + 9, y + 3, z + 13, Block16, 2, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 3, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + 3, z + 13, Block5, 0, 3);
		world.setBlock(x + 12, y + 3, z + 13, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 3; int nativePlacementZ = z + 13; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 19, y + 3, z + 13, Block6, 0, 3);
		world.setBlock(x + 20, y + 3, z + 13, Block6, 0, 3);
		world.setBlock(x + 21, y + 3, z + 13, Block6, 0, 3);
		world.setBlock(x + 22, y + 3, z + 13, Block6, 0, 3);
		world.setBlock(x + 23, y + 3, z + 13, Block6, 0, 3);
		world.setBlock(x + 24, y + 3, z + 13, Block6, 0, 3);
		world.setBlock(x + 25, y + 3, z + 13, Block6, 0, 3);
		world.setBlock(x + 26, y + 3, z + 13, Block6, 0, 3);
		world.setBlock(x + 27, y + 3, z + 13, Block6, 0, 3);
		world.setBlock(x + 28, y + 3, z + 13, Block6, 0, 3);
		world.setBlock(x + 29, y + 3, z + 13, Block6, 0, 3);
		world.setBlock(x + 30, y + 3, z + 13, Block6, 0, 3);
		world.setBlock(x + 31, y + 3, z + 13, Block6, 0, 3);
		world.setBlock(x + 32, y + 3, z + 13, Block6, 0, 3);
		world.setBlock(x + 33, y + 3, z + 13, Block6, 0, 3);
		world.setBlock(x + 34, y + 3, z + 13, Block18, 0, 3);
		world.setBlock(x + 35, y + 3, z + 13, Block18, 0, 3);
		world.setBlock(x + 36, y + 3, z + 13, Block18, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 3; int nativePlacementZ = z + 13; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 40, y + 3, z + 13, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 14, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 4, y + 3, z + 14, Block5, 0, 3);
		world.setBlock(x + 5, y + 3, z + 14, Block5, 0, 3);
		world.setBlock(x + 6, y + 3, z + 14, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 3, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 8, y + 3, z + 14, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 3, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 10, y + 3, z + 14, Block5, 0, 3);
		world.setBlock(x + 11, y + 3, z + 14, Block5, 0, 3);
		world.setBlock(x + 12, y + 3, z + 14, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 3; int nativePlacementZ = z + 14; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 3, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		world.setBlock(x + 19, y + 3, z + 14, Block6, 0, 3);
		world.setBlock(x + 20, y + 3, z + 14, Block6, 0, 3);
		world.setBlock(x + 21, y + 3, z + 14, Block6, 0, 3);
		world.setBlock(x + 22, y + 3, z + 14, Block6, 0, 3);
		world.setBlock(x + 23, y + 3, z + 14, Block6, 0, 3);
		world.setBlock(x + 24, y + 3, z + 14, Block6, 0, 3);
		world.setBlock(x + 25, y + 3, z + 14, Block6, 0, 3);
		world.setBlock(x + 26, y + 3, z + 14, Block6, 0, 3);
		world.setBlock(x + 27, y + 3, z + 14, Block6, 0, 3);
		world.setBlock(x + 28, y + 3, z + 14, Block6, 0, 3);
		world.setBlock(x + 29, y + 3, z + 14, Block6, 0, 3);
		world.setBlock(x + 30, y + 3, z + 14, Block6, 0, 3);
		world.setBlock(x + 31, y + 3, z + 14, Block6, 0, 3);
		world.setBlock(x + 32, y + 3, z + 14, Block6, 0, 3);
		world.setBlock(x + 33, y + 3, z + 14, Block18, 0, 3);
		world.setBlock(x + 34, y + 3, z + 14, Block18, 0, 3);
		world.setBlock(x + 35, y + 3, z + 14, Block18, 0, 3);
		world.setBlock(x + 36, y + 3, z + 14, Block18, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 3; int nativePlacementZ = z + 14; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 40, y + 3, z + 14, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 15, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 5, y + 3, z + 15, Block5, 0, 3);
		world.setBlock(x + 6, y + 3, z + 15, Block5, 0, 3);
		world.setBlock(x + 7, y + 3, z + 15, Block5, 0, 3);
		world.setBlock(x + 8, y + 3, z + 15, Block5, 0, 3);
		world.setBlock(x + 9, y + 3, z + 15, Block5, 0, 3);
		world.setBlock(x + 10, y + 3, z + 15, Block5, 0, 3);
		world.setBlock(x + 11, y + 3, z + 15, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 3; int nativePlacementZ = z + 15; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 3, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + 3, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		world.setBlock(x + 19, y + 3, z + 15, Block6, 0, 3);
		world.setBlock(x + 20, y + 3, z + 15, Block6, 0, 3);
		world.setBlock(x + 21, y + 3, z + 15, Block6, 0, 3);
		world.setBlock(x + 22, y + 3, z + 15, Block6, 0, 3);
		world.setBlock(x + 23, y + 3, z + 15, Block6, 0, 3);
		world.setBlock(x + 24, y + 3, z + 15, Block6, 0, 3);
		world.setBlock(x + 25, y + 3, z + 15, Block6, 0, 3);
		world.setBlock(x + 26, y + 3, z + 15, Block6, 0, 3);
		world.setBlock(x + 27, y + 3, z + 15, Block6, 0, 3);
		world.setBlock(x + 28, y + 3, z + 15, Block6, 0, 3);
		world.setBlock(x + 29, y + 3, z + 15, Block6, 0, 3);
		world.setBlock(x + 30, y + 3, z + 15, Block6, 0, 3);
		world.setBlock(x + 31, y + 3, z + 15, Block6, 0, 3);
		world.setBlock(x + 32, y + 3, z + 15, Block18, 0, 3);
		world.setBlock(x + 33, y + 3, z + 15, Block18, 0, 3);
		world.setBlock(x + 34, y + 3, z + 15, Block18, 0, 3);
		world.setBlock(x + 35, y + 3, z + 15, Block18, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 3; int nativePlacementZ = z + 15; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 40, y + 3, z + 15, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 16, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 6, y + 3, z + 16, Block5, 0, 3);
		world.setBlock(x + 7, y + 3, z + 16, Block5, 0, 3);
		world.setBlock(x + 8, y + 3, z + 16, Block5, 0, 3);
		world.setBlock(x + 9, y + 3, z + 16, Block5, 0, 3);
		world.setBlock(x + 10, y + 3, z + 16, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 3; int nativePlacementZ = z + 16; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 17, y + 3, z + 16, Block6, 0, 3);
		world.setBlock(x + 18, y + 3, z + 16, Block6, 0, 3);
		world.setBlock(x + 19, y + 3, z + 16, Block6, 0, 3);
		world.setBlock(x + 20, y + 3, z + 16, Block6, 0, 3);
		world.setBlock(x + 21, y + 3, z + 16, Block6, 0, 3);
		world.setBlock(x + 22, y + 3, z + 16, Block6, 0, 3);
		world.setBlock(x + 23, y + 3, z + 16, Block6, 0, 3);
		world.setBlock(x + 24, y + 3, z + 16, Block6, 0, 3);
		world.setBlock(x + 25, y + 3, z + 16, Block6, 0, 3);
		world.setBlock(x + 26, y + 3, z + 16, Block6, 0, 3);
		world.setBlock(x + 27, y + 3, z + 16, Block6, 0, 3);
		world.setBlock(x + 28, y + 3, z + 16, Block6, 0, 3);
		world.setBlock(x + 29, y + 3, z + 16, Block6, 0, 3);
		world.setBlock(x + 30, y + 3, z + 16, Block6, 0, 3);
		world.setBlock(x + 31, y + 3, z + 16, Block6, 0, 3);
		world.setBlock(x + 32, y + 3, z + 16, Block18, 0, 3);
		world.setBlock(x + 33, y + 3, z + 16, Block18, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 34, y + 3, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 3; int nativePlacementZ = z + 16; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 40, y + 3, z + 16, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 17, ModBlocks.barbed_wire, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 3; int nativePlacementZ = z + 17; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 17, y + 3, z + 17, Block6, 0, 3);
		world.setBlock(x + 18, y + 3, z + 17, Block6, 0, 3);
		world.setBlock(x + 19, y + 3, z + 17, Block6, 0, 3);
		world.setBlock(x + 20, y + 3, z + 17, Block6, 0, 3);
		world.setBlock(x + 21, y + 3, z + 17, Block6, 0, 3);
		world.setBlock(x + 22, y + 3, z + 17, Block6, 0, 3);
		world.setBlock(x + 23, y + 3, z + 17, Block6, 0, 3);
		world.setBlock(x + 24, y + 3, z + 17, Block6, 0, 3);
		world.setBlock(x + 25, y + 3, z + 17, Block6, 0, 3);
		world.setBlock(x + 26, y + 3, z + 17, Block6, 0, 3);
		world.setBlock(x + 27, y + 3, z + 17, Block6, 0, 3);
		world.setBlock(x + 28, y + 3, z + 17, Block6, 0, 3);
		world.setBlock(x + 29, y + 3, z + 17, Block6, 0, 3);
		world.setBlock(x + 30, y + 3, z + 17, Block6, 0, 3);
		world.setBlock(x + 31, y + 3, z + 17, Block6, 0, 3);
		world.setBlock(x + 32, y + 3, z + 17, Block18, 0, 3);
		world.setBlock(x + 33, y + 3, z + 17, Block18, 0, 3);
		world.setBlock(x + 34, y + 3, z + 17, Block18, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 3, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		world.setBlock(x + 40, y + 3, z + 17, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 18, ModBlocks.barbed_wire, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 17; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 18; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 19; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 20; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 21; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 22; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 24; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 25; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 26; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 27; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 28; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 29; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 30; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 31; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 32; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 33; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 34; int nativePlacementY = y + 3; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 3, z + 18); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 3, z + 18); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + 3, z + 18, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 19, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 40, y + 3, z + 19, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 20, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 6, y + 3, z + 20, Block15, 0, 3);
		world.setBlock(x + 7, y + 3, z + 20, Block15, 0, 3);
		world.setBlock(x + 8, y + 3, z + 20, Block15, 0, 3);
		world.setBlock(x + 9, y + 3, z + 20, Block15, 0, 3);
		world.setBlock(x + 10, y + 3, z + 20, Block15, 0, 3);
		world.setBlock(x + 40, y + 3, z + 20, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 21, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 4, y + 3, z + 21, Block15, 0, 3);
		world.setBlock(x + 5, y + 3, z + 21, Block15, 0, 3);
		world.setBlock(x + 11, y + 3, z + 21, Block15, 0, 3);
		world.setBlock(x + 12, y + 3, z + 21, Block15, 0, 3);
		world.setBlock(x + 40, y + 3, z + 21, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 22, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 4, y + 3, z + 22, Block15, 0, 3);
		world.setBlock(x + 12, y + 3, z + 22, Block15, 0, 3);
		world.setBlock(x + 40, y + 3, z + 22, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 23, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 3, y + 3, z + 23, Block15, 0, 3);
		world.setBlock(x + 13, y + 3, z + 23, Block15, 0, 3);
		world.setBlock(x + 40, y + 3, z + 23, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 24, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 3, y + 3, z + 24, Block15, 0, 3);
		world.setBlock(x + 13, y + 3, z + 24, Block15, 0, 3);
		world.setBlock(x + 40, y + 3, z + 24, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 25, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 3, y + 3, z + 25, Block15, 0, 3);
		world.setBlock(x + 13, y + 3, z + 25, Block15, 0, 3);
		world.setBlock(x + 40, y + 3, z + 25, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 26, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 3, y + 3, z + 26, Block15, 0, 3);
		world.setBlock(x + 13, y + 3, z + 26, Block15, 0, 3);
		world.setBlock(x + 40, y + 3, z + 26, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 27, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 3, y + 3, z + 27, Block15, 0, 3);
		world.setBlock(x + 13, y + 3, z + 27, Block15, 0, 3);
		world.setBlock(x + 40, y + 3, z + 27, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 28, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 4, y + 3, z + 28, Block15, 0, 3);
		world.setBlock(x + 12, y + 3, z + 28, Block15, 0, 3);
		world.setBlock(x + 40, y + 3, z + 28, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 29, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 4, y + 3, z + 29, Block15, 0, 3);
		world.setBlock(x + 5, y + 3, z + 29, Block15, 0, 3);
		world.setBlock(x + 11, y + 3, z + 29, Block15, 0, 3);
		world.setBlock(x + 12, y + 3, z + 29, Block15, 0, 3);
		world.setBlock(x + 40, y + 3, z + 29, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 30, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 6, y + 3, z + 30, Block15, 0, 3);
		world.setBlock(x + 7, y + 3, z + 30, Block15, 0, 3);
		world.setBlock(x + 8, y + 3, z + 30, Block15, 0, 3);
		world.setBlock(x + 9, y + 3, z + 30, Block15, 0, 3);
		world.setBlock(x + 10, y + 3, z + 30, Block15, 0, 3);
		world.setBlock(x + 40, y + 3, z + 30, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 16, y + 3, z + 31, Block5, 0, 3);
		world.setBlock(x + 17, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 18, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 19, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 20, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 21, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 22, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 23, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 24, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 25, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 26, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 27, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 28, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 29, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 30, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 31, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 32, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 33, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 34, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 35, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 36, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 37, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 38, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 39, y + 3, z + 31, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 40, y + 3, z + 31, Block5, 0, 3);
		world.setBlock(x + 0, y + 3, z + 32, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 16, y + 3, z + 32, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 33, Block5, 0, 3);
		world.setBlock(x + 1, y + 3, z + 33, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 2, y + 3, z + 33, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 3, y + 3, z + 33, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 4, y + 3, z + 33, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 5, y + 3, z + 33, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 6, y + 3, z + 33, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 7, y + 3, z + 33, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 8, y + 3, z + 33, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 9, y + 3, z + 33, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 10, y + 3, z + 33, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 11, y + 3, z + 33, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 12, y + 3, z + 33, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 13, y + 3, z + 33, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 14, y + 3, z + 33, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 15, y + 3, z + 33, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 16, y + 3, z + 33, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 17; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 18; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 19; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 20; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 21; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 22; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 24; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 25; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 26; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 27; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 28; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 29; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 30; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 31; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 32; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 33; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 34; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 35; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 36; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 4; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 7, y + 4, z + 7, Block8, 2, 3);
		world.setBlock(x + 9, y + 4, z + 7, Block8, 2, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 4; int nativePlacementZ = z + 7; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + 4, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 19, y + 4, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 4, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 4; int nativePlacementZ = z + 7; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 25, y + 4, z + 7, Block8, 3, 3);
		world.setBlock(x + 26, y + 4, z + 7, Block19, 12, 3);
		world.setBlock(x + 27, y + 4, z + 7, Block19, 12, 3);
		world.setBlock(x + 28, y + 4, z + 7, Block20, 3, 3);
		TileEntity tank0 = world.getTileEntity(new BlockPos(x + 28, y + 4, z + 7));
		if(tank0 instanceof TileEntityMachineUF6Tank)
		{
		}
		world.setBlock(x + 29, y + 4, z + 7, Block20, 3, 3);
		world.getTileEntity(new BlockPos(x + 29, y + 4, z + 7));
		if(tank0 instanceof TileEntityMachineUF6Tank)
		{
		}
		world.setBlock(x + 30, y + 4, z + 7, Block21, 3, 3);
		world.getTileEntity(new BlockPos(x + 30, y + 4, z + 7));
		if(tank0 instanceof TileEntityMachinePuF6Tank)
		{
		}
		world.setBlock(x + 31, y + 4, z + 7, Block21, 3, 3);
		TileEntity tank3 = world.getTileEntity(new BlockPos(x + 31, y + 4, z + 7));
		if(tank3 instanceof TileEntityMachinePuF6Tank)
		{
		}
		world.setBlock(x + 32, y + 4, z + 7, Block2, 0, 3);
		world.setBlock(x + 33, y + 4, z + 7, Block22, 0, 3);
		world.setBlock(x + 34, y + 4, z + 7, Block23, 0, 3);
		world.setBlock(x + 35, y + 4, z + 7, Block23, 0, 3);
		world.setBlock(x + 36, y + 4, z + 7, Block23, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 4; int nativePlacementZ = z + 7; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 40, y + 4, z + 7, Block5, 0, 3);
		world.setBlock(x + 6, y + 4, z + 8, Block5, 0, 3);
		world.setBlock(x + 7, y + 4, z + 8, Block5, 0, 3);
		//world.setBlock(x + 8, y + 4, z + 8, Blocks.iron_door, 1, 3);
        ItemDoor.placeDoorBlock(world, x + 8, y + 4, z + 8, 1, Blocks.IRON_DOOR);
		world.setBlock(x + 9, y + 4, z + 8, Block5, 0, 3);
		world.setBlock(x + 10, y + 4, z + 8, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 4; int nativePlacementZ = z + 8; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 19, y + 4, z + 8, ModBlocks.fence_metal, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 4; int nativePlacementZ = z + 8; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 24, y + 4, z + 8, Block12, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 26, y + 4, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.UNPOWERED_REPEATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 4, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.UNPOWERED_REPEATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 4, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.UNPOWERED_REPEATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 32, y + 4, z + 8, Block2, 0, 3);
		world.setBlock(x + 33, y + 4, z + 8, Block22, 0, 3);
		world.setBlock(x + 34, y + 4, z + 8, Block22, 0, 3);
		world.setBlock(x + 35, y + 4, z + 8, Block22, 0, 3);
		world.setBlock(x + 36, y + 4, z + 8, Block22, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 4; int nativePlacementZ = z + 8; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 40, y + 4, z + 8, Block5, 0, 3);
		world.setBlock(x + 5, y + 4, z + 9, Block5, 0, 3);
		world.setBlock(x + 6, y + 4, z + 9, Block2, 0, 3);
		world.setBlock(x + 7, y + 4, z + 9, Block2, 0, 3);
		world.setBlock(x + 10, y + 4, z + 9, Block2, 0, 3);
		world.setBlock(x + 11, y + 4, z + 9, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 4; int nativePlacementZ = z + 9; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 4, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + 4, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		world.setBlock(x + 19, y + 4, z + 9, ModBlocks.fence_metal, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 4; int nativePlacementZ = z + 9; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 4, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 26, y + 4, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 4, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 28, y + 4, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 30, y + 4, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 4, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 32, y + 4, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.UNPOWERED_REPEATER.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 33, y + 4, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 34, y + 4, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		world.setBlock(x + 35, y + 4, z + 9, Block12, 0, 3);
		world.setBlock(x + 35, y + 5, z + 9, ModBlocks.geiger, 2, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 4, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.CHEST.getStateFromMeta(2), 3); }
		if((world.isValid(new BlockPos(x + 36, y + 4, z + 9)) ? world.getBlockState(new BlockPos(x + 36, y + 4, z + 9)).getBlock() : Blocks.AIR) == Blocks.CHEST)
		{
			WeightedRandomChestContent.generateChestContents(rand, ItemPool.getPool(ItemPoolsLegacy.POOL_NUKE_MISC), (TileEntityChest)world.getTileEntity(new BlockPos(x + 36, y + 4, z + 9)), 12);
		}
        { net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 4; int nativePlacementZ = z + 9; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 40, y + 4, z + 9, Block5, 0, 3);
		world.setBlock(x + 4, y + 4, z + 10, Block5, 0, 3);
		world.setBlock(x + 5, y + 4, z + 10, Block2, 0, 3);
		world.setBlock(x + 11, y + 4, z + 10, Block2, 0, 3);
		world.setBlock(x + 12, y + 4, z + 10, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 4; int nativePlacementZ = z + 10; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 4, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(7), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + 4, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(7), 3); }
		world.setBlock(x + 19, y + 4, z + 10, ModBlocks.fence_metal, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 4, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 4; int nativePlacementZ = z + 10; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 4, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 25, y + 4, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 26, y + 4, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 28, y + 4, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 4, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 30, y + 4, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 4, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 4; int nativePlacementZ = z + 10; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 40, y + 4, z + 10, Block5, 0, 3);
		world.setBlock(x + 4, y + 4, z + 11, Block5, 0, 3);
		world.setBlock(x + 5, y + 4, z + 11, Block2, 0, 3);
		world.setBlock(x + 11, y + 4, z + 11, Block2, 0, 3);
		world.setBlock(x + 12, y + 4, z + 11, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 4; int nativePlacementZ = z + 11; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 4, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 4; int nativePlacementZ = z + 11; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 4, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 4, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		world.setBlock(x + 28, y + 4, z + 11, Block24, 0, 3);
		world.setBlock(x + 29, y + 4, z + 11, Block24, 0, 3);
		world.setBlock(x + 30, y + 4, z + 11, Block24, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 34, y + 4, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 4; int nativePlacementZ = z + 11; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 4, y + 4, z + 12, Block5, 0, 3);
		world.setBlock(x + 8, y + 4, z + 12, Block14, 0, 3);
		world.setBlock(x + 11, y + 4, z + 12, Block2, 0, 3);
		world.setBlock(x + 12, y + 4, z + 12, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 4; int nativePlacementZ = z + 12; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 19, y + 4, z + 12, ModBlocks.fence_metal, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 4, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 4; int nativePlacementZ = z + 12; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 4, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 4, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		world.setBlock(x + 28, y + 4, z + 12, Block24, 0, 3);
		world.setBlock(x + 29, y + 4, z + 12, Block24, 0, 3);
		world.setBlock(x + 30, y + 4, z + 12, Block24, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 4, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 32, y + 4, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 4, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 4; int nativePlacementZ = z + 12; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 4, y + 4, z + 13, Block5, 0, 3);
		world.setBlock(x + 5, y + 4, z + 13, Block2, 0, 3);
		world.setBlock(x + 12, y + 4, z + 13, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 4; int nativePlacementZ = z + 13; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 4, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		world.setBlock(x + 19, y + 4, z + 13, ModBlocks.fence_metal, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 4, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 4; int nativePlacementZ = z + 13; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 4, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 25, y + 4, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 26, y + 4, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		world.setBlock(x + 28, y + 4, z + 13, Block24, 0, 3);
		world.setBlock(x + 29, y + 4, z + 13, Block24, 0, 3);
		world.setBlock(x + 30, y + 4, z + 13, Block24, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 4, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 4, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 4; int nativePlacementZ = z + 13; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 4, y + 4, z + 14, Block5, 0, 3);
		world.setBlock(x + 12, y + 4, z + 14, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 4; int nativePlacementZ = z + 14; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 4, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		world.setBlock(x + 19, y + 4, z + 14, ModBlocks.fence_metal, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 4; int nativePlacementZ = z + 14; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 24, y + 4, z + 14, Block12, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 26, y + 4, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 4, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 28, y + 4, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		world.setBlock(x + 29, y + 4, z + 14, Block25, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 30, y + 4, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 4, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 4; int nativePlacementZ = z + 14; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 5, y + 4, z + 15, Block5, 0, 3);
		world.setBlock(x + 8, y + 4, z + 15, Block2, 0, 3);
		world.setBlock(x + 9, y + 4, z + 15, Block2, 0, 3);
		world.setBlock(x + 10, y + 4, z + 15, Block2, 0, 3);
		world.setBlock(x + 11, y + 4, z + 15, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 4; int nativePlacementZ = z + 15; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 19, y + 4, z + 15, ModBlocks.fence_metal, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 23, y + 4, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.IRON_DOOR.getStateFromMeta(0), 3); }
        ItemDoor.placeDoorBlock(world, x + 23, y + 4, z + 15, 0, Blocks.IRON_DOOR);
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 4, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 4, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 30, y + 4, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 4, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 4; int nativePlacementZ = z + 15; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 6, y + 4, z + 16, Block5, 0, 3);
		world.setBlock(x + 7, y + 4, z + 16, Block5, 0, 3);
		world.setBlock(x + 8, y + 4, z + 16, Block5, 0, 3);
		world.setBlock(x + 9, y + 4, z + 16, Block5, 0, 3);
		world.setBlock(x + 10, y + 4, z + 16, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 4; int nativePlacementZ = z + 16; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 4, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		//world.setBlock(x + 23, y + 4, z + 16, Blocks.iron_door, 3, 3);
        ItemDoor.placeDoorBlock(world, x + 23, y + 4, z + 16, 3, Blocks.IRON_DOOR);
		{ BlockPos dungeonPos = new BlockPos(x + 26, y + 4, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 4, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.UNPOWERED_REPEATER.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 37, y + 4, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 4; int nativePlacementZ = z + 17; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + 4, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 4, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 4; int nativePlacementZ = z + 17; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 4, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 28, y + 4, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(9), 3); }
		world.setBlock(x + 29, y + 4, z + 17, Block12, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 33, y + 4, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(3), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 17; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 18; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 19; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 20; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 21; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 22; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 24; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 25; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 26; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 27; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 28; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 29; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 30; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 31; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 32; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 33; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 34; int nativePlacementY = y + 4; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 6, y + 4, z + 20, Block15, 0, 3);
		world.setBlock(x + 7, y + 4, z + 20, Block15, 0, 3);
		world.setBlock(x + 8, y + 4, z + 20, Block15, 0, 3);
		world.setBlock(x + 9, y + 4, z + 20, Block15, 0, 3);
		world.setBlock(x + 10, y + 4, z + 20, Block15, 0, 3);
		world.setBlock(x + 4, y + 4, z + 21, Block15, 0, 3);
		world.setBlock(x + 5, y + 4, z + 21, Block15, 0, 3);
		world.setBlock(x + 6, y + 4, z + 21, Block7, 0, 3);
		world.setBlock(x + 7, y + 4, z + 21, Block7, 0, 3);
		world.setBlock(x + 8, y + 4, z + 21, Block7, 0, 3);
		world.setBlock(x + 9, y + 4, z + 21, Block7, 0, 3);
		world.setBlock(x + 10, y + 4, z + 21, Block7, 0, 3);
		world.setBlock(x + 11, y + 4, z + 21, Block15, 0, 3);
		world.setBlock(x + 12, y + 4, z + 21, Block15, 0, 3);
		world.setBlock(x + 4, y + 4, z + 22, Block15, 0, 3);
		world.setBlock(x + 5, y + 4, z + 22, Block7, 0, 3);
		world.setBlock(x + 11, y + 4, z + 22, Block7, 0, 3);
		world.setBlock(x + 12, y + 4, z + 22, Block15, 0, 3);
		world.setBlock(x + 3, y + 4, z + 23, Block15, 0, 3);
		world.setBlock(x + 4, y + 4, z + 23, Block7, 0, 3);
		world.setBlock(x + 12, y + 4, z + 23, Block7, 0, 3);
		world.setBlock(x + 13, y + 4, z + 23, Block15, 0, 3);
		world.setBlock(x + 3, y + 4, z + 24, Block15, 0, 3);
		world.setBlock(x + 4, y + 4, z + 24, Block7, 0, 3);
		world.setBlock(x + 12, y + 4, z + 24, Block7, 0, 3);
		world.setBlock(x + 13, y + 4, z + 24, Block15, 0, 3);
		world.setBlock(x + 3, y + 4, z + 25, Block15, 0, 3);
		world.setBlock(x + 4, y + 4, z + 25, Block7, 0, 3);
		world.setBlock(x + 12, y + 4, z + 25, Block7, 0, 3);
		world.setBlock(x + 13, y + 4, z + 25, Block15, 0, 3);
		world.setBlock(x + 3, y + 4, z + 26, Block15, 0, 3);
		world.setBlock(x + 4, y + 4, z + 26, Block7, 0, 3);
		world.setBlock(x + 12, y + 4, z + 26, Block7, 0, 3);
		world.setBlock(x + 13, y + 4, z + 26, Block15, 0, 3);
		world.setBlock(x + 3, y + 4, z + 27, Block15, 0, 3);
		world.setBlock(x + 4, y + 4, z + 27, Block7, 0, 3);
		world.setBlock(x + 12, y + 4, z + 27, Block7, 0, 3);
		world.setBlock(x + 13, y + 4, z + 27, Block15, 0, 3);
		world.setBlock(x + 4, y + 4, z + 28, Block15, 0, 3);
		world.setBlock(x + 5, y + 4, z + 28, Block7, 0, 3);
		world.setBlock(x + 11, y + 4, z + 28, Block7, 0, 3);
		world.setBlock(x + 12, y + 4, z + 28, Block15, 0, 3);
		world.setBlock(x + 4, y + 4, z + 29, Block15, 0, 3);
		world.setBlock(x + 5, y + 4, z + 29, Block15, 0, 3);
		world.setBlock(x + 6, y + 4, z + 29, Block7, 0, 3);
		world.setBlock(x + 7, y + 4, z + 29, Block7, 0, 3);
		world.setBlock(x + 8, y + 4, z + 29, Block7, 0, 3);
		world.setBlock(x + 9, y + 4, z + 29, Block7, 0, 3);
		world.setBlock(x + 10, y + 4, z + 29, Block7, 0, 3);
		world.setBlock(x + 11, y + 4, z + 29, Block15, 0, 3);
		world.setBlock(x + 12, y + 4, z + 29, Block15, 0, 3);
		world.setBlock(x + 6, y + 4, z + 30, Block15, 0, 3);
		world.setBlock(x + 7, y + 4, z + 30, Block15, 0, 3);
		world.setBlock(x + 8, y + 4, z + 30, Block15, 0, 3);
		world.setBlock(x + 9, y + 4, z + 30, Block15, 0, 3);
		world.setBlock(x + 10, y + 4, z + 30, Block15, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 17; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 18, y + 5, z + 6, Block11, 0, 3);
		world.setBlock(x + 19, y + 5, z + 6, Block11, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 20; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 21; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 22; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 24; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 25; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 26; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 27; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 28; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 29; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 30; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 31; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 32; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 33; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 34; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 35; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 36; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 5; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 7, y + 5, z + 7, Block8, 2, 3);
		world.setBlock(x + 9, y + 5, z + 7, Block8, 2, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 5; int nativePlacementZ = z + 7; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + 5, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 19, y + 5, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 5, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 5, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 5; int nativePlacementZ = z + 7; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 25, y + 5, z + 7, Block8, 3, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 30, y + 5, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		world.setBlock(x + 32, y + 5, z + 7, Block2, 0, 3);
		world.setBlock(x + 33, y + 5, z + 7, Block11, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 5; int nativePlacementZ = z + 7; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 6, y + 5, z + 8, Block5, 0, 3);
		world.setBlock(x + 7, y + 5, z + 8, Block5, 0, 3);
		//world.setBlock(x + 8, y + 5, z + 8, Blocks.iron_door, 8, 3);
		world.setBlock(x + 9, y + 5, z + 8, Block5, 0, 3);
		world.setBlock(x + 10, y + 5, z + 8, Block5, 0, 3);
		world.setBlock(x + 16, y + 5, z + 8, Block11, 0, 3);
		world.setBlock(x + 23, y + 5, z + 8, Block11, 0, 3);
		world.setBlock(x + 33, y + 5, z + 8, Block11, 0, 3);
		world.setBlock(x + 34, y + 5, z + 8, Block11, 0, 3);
		world.setBlock(x + 35, y + 5, z + 8, Block11, 0, 3);
		world.setBlock(x + 36, y + 5, z + 8, Block11, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 5; int nativePlacementZ = z + 8; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 5, y + 5, z + 9, Block5, 0, 3);
		world.setBlock(x + 11, y + 5, z + 9, Block5, 0, 3);
		world.setBlock(x + 16, y + 5, z + 9, Block11, 0, 3);
		world.setBlock(x + 19, y + 5, z + 9, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 23, y + 5, z + 9, Block11, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 33, y + 5, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 5; int nativePlacementZ = z + 9; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 4, y + 5, z + 10, Block5, 0, 3);
		world.setBlock(x + 12, y + 5, z + 10, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 5; int nativePlacementZ = z + 10; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 5, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + 5, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		world.setBlock(x + 19, y + 5, z + 10, ModBlocks.fence_metal, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 23, y + 5, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 5; int nativePlacementZ = z + 10; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 4, y + 5, z + 11, Block5, 0, 3);
		world.setBlock(x + 12, y + 5, z + 11, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 5; int nativePlacementZ = z + 11; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 5, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(7), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + 5, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(7), 3); }
		world.setBlock(x + 19, y + 5, z + 11, ModBlocks.fence_metal, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 5, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 23, y + 5, z + 11, Block11, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 5, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		world.setBlock(x + 28, y + 5, z + 11, Block16, 4, 3);
		world.setBlock(x + 29, y + 5, z + 11, Block16, 2, 3);
		world.setBlock(x + 30, y + 5, z + 11, Block16, 3, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 5; int nativePlacementZ = z + 11; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 4, y + 5, z + 12, Block5, 0, 3);
		world.setBlock(x + 8, y + 5, z + 12, Block25, 0, 3);
		world.setBlock(x + 12, y + 5, z + 12, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 5; int nativePlacementZ = z + 12; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 5, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 19, y + 5, z + 12, ModBlocks.fence_metal, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 5, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 5, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 5, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		world.setBlock(x + 28, y + 5, z + 12, Block16, 4, 3);
		world.setBlock(x + 29, y + 5, z + 12, Block26, 0, 3);
		world.setBlock(x + 30, y + 5, z + 12, Block16, 3, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 5, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 5, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 5; int nativePlacementZ = z + 12; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 4, y + 5, z + 13, Block5, 0, 3);
		world.setBlock(x + 12, y + 5, z + 13, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 5; int nativePlacementZ = z + 13; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 5, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		world.setBlock(x + 19, y + 5, z + 13, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 23, y + 5, z + 13, Block11, 0, 3);
		world.setBlock(x + 28, y + 5, z + 13, Block16, 3, 3);
		world.setBlock(x + 29, y + 5, z + 13, Block16, 3, 3);
		world.setBlock(x + 30, y + 5, z + 13, Block16, 3, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 5, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 5, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 5, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 5; int nativePlacementZ = z + 13; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 4, y + 5, z + 14, Block5, 0, 3);
		world.setBlock(x + 12, y + 5, z + 14, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 5; int nativePlacementZ = z + 14; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 5, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 5; int nativePlacementZ = z + 14; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 5, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.REDSTONE_WIRE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 5, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 29, y + 5, z + 14, Block25, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 37, y + 5, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 5, y + 5, z + 15, Block5, 0, 3);
		world.setBlock(x + 11, y + 5, z + 15, Block5, 0, 3);
		world.setBlock(x + 16, y + 5, z + 15, Block11, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 5, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		//world.setBlock(x + 23, y + 5, z + 15, Blocks.iron_door, 8, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 5, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 34, y + 5, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 37, y + 5, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 6, y + 5, z + 16, Block5, 0, 3);
		world.setBlock(x + 7, y + 5, z + 16, Block5, 0, 3);
		world.setBlock(x + 8, y + 5, z + 16, Block5, 0, 3);
		world.setBlock(x + 9, y + 5, z + 16, Block5, 0, 3);
		world.setBlock(x + 10, y + 5, z + 16, Block5, 0, 3);
		world.setBlock(x + 16, y + 5, z + 16, Block11, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 5, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		//world.setBlock(x + 23, y + 5, z + 16, Blocks.iron_door, 8, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 34, y + 5, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 5; int nativePlacementZ = z + 17; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + 5, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 5, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 5; int nativePlacementZ = z + 17; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 5, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 5, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 28, y + 5, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 33, y + 5, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(3), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 17; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 18; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 19; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 20; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 21; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 22; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 24; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 25; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 26; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 27; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 28; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 29; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 30; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 31; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 32; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 33; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 34; int nativePlacementY = y + 5; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 6, y + 5, z + 21, Block15, 0, 3);
		world.setBlock(x + 7, y + 5, z + 21, Block15, 0, 3);
		world.setBlock(x + 8, y + 5, z + 21, Block15, 0, 3);
		world.setBlock(x + 9, y + 5, z + 21, Block15, 0, 3);
		world.setBlock(x + 10, y + 5, z + 21, Block15, 0, 3);
		world.setBlock(x + 5, y + 5, z + 22, Block15, 0, 3);
		world.setBlock(x + 11, y + 5, z + 22, Block15, 0, 3);
		world.setBlock(x + 4, y + 5, z + 23, Block15, 0, 3);
		world.setBlock(x + 12, y + 5, z + 23, Block15, 0, 3);
		world.setBlock(x + 4, y + 5, z + 24, Block15, 0, 3);
		world.setBlock(x + 12, y + 5, z + 24, Block15, 0, 3);
		world.setBlock(x + 4, y + 5, z + 25, Block15, 0, 3);
		world.setBlock(x + 12, y + 5, z + 25, Block15, 0, 3);
		world.setBlock(x + 4, y + 5, z + 26, Block15, 0, 3);
		world.setBlock(x + 12, y + 5, z + 26, Block15, 0, 3);
		world.setBlock(x + 4, y + 5, z + 27, Block15, 0, 3);
		world.setBlock(x + 12, y + 5, z + 27, Block15, 0, 3);
		world.setBlock(x + 5, y + 5, z + 28, Block15, 0, 3);
		world.setBlock(x + 11, y + 5, z + 28, Block15, 0, 3);
		world.setBlock(x + 6, y + 5, z + 29, Block15, 0, 3);
		world.setBlock(x + 7, y + 5, z + 29, Block15, 0, 3);
		world.setBlock(x + 8, y + 5, z + 29, Block15, 0, 3);
		world.setBlock(x + 9, y + 5, z + 29, Block15, 0, 3);
		world.setBlock(x + 10, y + 5, z + 29, Block15, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 17; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 18; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 19; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 20; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 21; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 22; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 24; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 25; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 26; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 27; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 28; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 29; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 30; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 31; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 32; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 33; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 34; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 35; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 36; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 6; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 7, y + 6, z + 7, Block5, 0, 3);
		world.setBlock(x + 8, y + 6, z + 7, Block5, 0, 3);
		world.setBlock(x + 9, y + 6, z + 7, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 6; int nativePlacementZ = z + 7; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 19, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 6; int nativePlacementZ = z + 7; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 25, y + 6, z + 7, Block8, 3, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 26, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 30, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 33, y + 6, z + 7, Block22, 0, 3);
		world.setBlock(x + 34, y + 6, z + 7, Block22, 0, 3);
		world.setBlock(x + 35, y + 6, z + 7, Block22, 0, 3);
		world.setBlock(x + 36, y + 6, z + 7, Block22, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 6; int nativePlacementZ = z + 7; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 6, y + 6, z + 8, Block5, 0, 3);
		world.setBlock(x + 7, y + 6, z + 8, Block5, 0, 3);
		world.setBlock(x + 8, y + 6, z + 8, Block5, 0, 3);
		world.setBlock(x + 9, y + 6, z + 8, Block5, 0, 3);
		world.setBlock(x + 10, y + 6, z + 8, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 6; int nativePlacementZ = z + 8; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 6, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 6; int nativePlacementZ = z + 8; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 26, y + 6, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 32, y + 6, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 33, y + 6, z + 8, Block22, 0, 3);
		world.setBlock(x + 34, y + 6, z + 8, Block22, 0, 3);
		world.setBlock(x + 35, y + 6, z + 8, Block22, 0, 3);
		world.setBlock(x + 36, y + 6, z + 8, Block22, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 6; int nativePlacementZ = z + 8; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 5, y + 6, z + 9, Block5, 0, 3);
		world.setBlock(x + 6, y + 6, z + 9, Block5, 0, 3);
		world.setBlock(x + 7, y + 6, z + 9, Block5, 0, 3);
		world.setBlock(x + 8, y + 6, z + 9, Block5, 0, 3);
		world.setBlock(x + 9, y + 6, z + 9, Block5, 0, 3);
		world.setBlock(x + 10, y + 6, z + 9, Block5, 0, 3);
		world.setBlock(x + 11, y + 6, z + 9, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 6; int nativePlacementZ = z + 9; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 6; int nativePlacementZ = z + 9; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 25, y + 6, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 30, y + 6, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 33, y + 6, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 6, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 6, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 6; int nativePlacementZ = z + 9; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 4, y + 6, z + 10, Block5, 0, 3);
		world.setBlock(x + 5, y + 6, z + 10, Block5, 0, 3);
		world.setBlock(x + 6, y + 6, z + 10, Block5, 0, 3);
		world.setBlock(x + 10, y + 6, z + 10, Block5, 0, 3);
		world.setBlock(x + 11, y + 6, z + 10, Block5, 0, 3);
		world.setBlock(x + 12, y + 6, z + 10, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 6; int nativePlacementZ = z + 10; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 19, y + 6, z + 10, ModBlocks.fence_metal, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 6; int nativePlacementZ = z + 10; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 6, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 30, y + 6, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 6, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 6; int nativePlacementZ = z + 10; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 4, y + 6, z + 11, Block5, 0, 3);
		world.setBlock(x + 5, y + 6, z + 11, Block5, 0, 3);
		world.setBlock(x + 11, y + 6, z + 11, Block5, 0, 3);
		world.setBlock(x + 12, y + 6, z + 11, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 6; int nativePlacementZ = z + 11; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 6, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + 6, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		world.setBlock(x + 19, y + 6, z + 11, ModBlocks.fence_metal, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 6, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 6; int nativePlacementZ = z + 11; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 6, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		world.setBlock(x + 28, y + 6, z + 11, Block24, 0, 3);
		world.setBlock(x + 29, y + 6, z + 11, Block24, 0, 3);
		world.setBlock(x + 30, y + 6, z + 11, Block24, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 6, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 6; int nativePlacementZ = z + 11; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 4, y + 6, z + 12, Block5, 0, 3);
		world.setBlock(x + 5, y + 6, z + 12, Block5, 0, 3);
		world.setBlock(x + 8, y + 6, z + 12, Block25, 0, 3);
		world.setBlock(x + 11, y + 6, z + 12, Block5, 0, 3);
		world.setBlock(x + 12, y + 6, z + 12, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 6; int nativePlacementZ = z + 12; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 6, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(7), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + 6, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(7), 3); }
		world.setBlock(x + 19, y + 6, z + 12, ModBlocks.fence_metal, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 6, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 6, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 6; int nativePlacementZ = z + 12; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 6, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 6, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		world.setBlock(x + 28, y + 6, z + 12, Block24, 0, 3);
		world.setBlock(x + 29, y + 6, z + 12, Block24, 0, 3);
		world.setBlock(x + 30, y + 6, z + 12, Block24, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 6, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 6, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 6; int nativePlacementZ = z + 12; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 4, y + 6, z + 13, Block5, 0, 3);
		world.setBlock(x + 5, y + 6, z + 13, Block5, 0, 3);
		world.setBlock(x + 11, y + 6, z + 13, Block5, 0, 3);
		world.setBlock(x + 12, y + 6, z + 13, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 6; int nativePlacementZ = z + 13; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 6, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 6; int nativePlacementZ = z + 13; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 6, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 28, y + 6, z + 13, Block24, 0, 3);
		world.setBlock(x + 29, y + 6, z + 13, Block24, 0, 3);
		world.setBlock(x + 30, y + 6, z + 13, Block24, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 6, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 6, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 6, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 37, y + 6, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 4, y + 6, z + 14, Block5, 0, 3);
		world.setBlock(x + 5, y + 6, z + 14, Block5, 0, 3);
		world.setBlock(x + 6, y + 6, z + 14, Block5, 0, 3);
		world.setBlock(x + 10, y + 6, z + 14, Block5, 0, 3);
		world.setBlock(x + 11, y + 6, z + 14, Block5, 0, 3);
		world.setBlock(x + 12, y + 6, z + 14, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 6; int nativePlacementZ = z + 14; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 6, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 6; int nativePlacementZ = z + 14; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 6, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 26, y + 6, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 28, y + 6, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 29, y + 6, z + 14, Block25, 0, 3);
		world.setBlock(x + 5, y + 6, z + 15, Block5, 0, 3);
		world.setBlock(x + 6, y + 6, z + 15, Block5, 0, 3);
		world.setBlock(x + 7, y + 6, z + 15, Block5, 0, 3);
		world.setBlock(x + 8, y + 6, z + 15, Block5, 0, 3);
		world.setBlock(x + 9, y + 6, z + 15, Block5, 0, 3);
		world.setBlock(x + 10, y + 6, z + 15, Block5, 0, 3);
		world.setBlock(x + 11, y + 6, z + 15, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 6; int nativePlacementZ = z + 15; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 6, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 6; int nativePlacementZ = z + 15; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 6, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 6, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 34, y + 6, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		world.setBlock(x + 6, y + 6, z + 16, Block5, 0, 3);
		world.setBlock(x + 7, y + 6, z + 16, Block5, 0, 3);
		world.setBlock(x + 8, y + 6, z + 16, Block5, 0, 3);
		world.setBlock(x + 9, y + 6, z + 16, Block5, 0, 3);
		world.setBlock(x + 10, y + 6, z + 16, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 6; int nativePlacementZ = z + 16; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 6, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 6, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 6; int nativePlacementZ = z + 16; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 6, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 6, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 34, y + 6, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 6; int nativePlacementZ = z + 17; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 6, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + 6, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 6, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + 6, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 6, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 6; int nativePlacementZ = z + 17; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 25, y + 6, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 6, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 28, y + 6, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 30, y + 6, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 33, y + 6, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(3), 3); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 6; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 17; int nativePlacementY = y + 6; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 18; int nativePlacementY = y + 6; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 19; int nativePlacementY = y + 6; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 20; int nativePlacementY = y + 6; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 21; int nativePlacementY = y + 6; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 22; int nativePlacementY = y + 6; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 6; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 24; int nativePlacementY = y + 6; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 25; int nativePlacementY = y + 6; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 26; int nativePlacementY = y + 6; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 27; int nativePlacementY = y + 6; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 28; int nativePlacementY = y + 6; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 29; int nativePlacementY = y + 6; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 30; int nativePlacementY = y + 6; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 31; int nativePlacementY = y + 6; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 32; int nativePlacementY = y + 6; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 33; int nativePlacementY = y + 6; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 34, y + 6, z + 18); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 6, y + 6, z + 21, Block15, 0, 3);
		world.setBlock(x + 7, y + 6, z + 21, Block15, 0, 3);
		world.setBlock(x + 8, y + 6, z + 21, Block15, 0, 3);
		world.setBlock(x + 9, y + 6, z + 21, Block15, 0, 3);
		world.setBlock(x + 10, y + 6, z + 21, Block15, 0, 3);
		world.setBlock(x + 5, y + 6, z + 22, Block15, 0, 3);
		world.setBlock(x + 11, y + 6, z + 22, Block15, 0, 3);
		world.setBlock(x + 4, y + 6, z + 23, Block15, 0, 3);
		world.setBlock(x + 12, y + 6, z + 23, Block15, 0, 3);
		world.setBlock(x + 4, y + 6, z + 24, Block15, 0, 3);
		world.setBlock(x + 12, y + 6, z + 24, Block15, 0, 3);
		world.setBlock(x + 4, y + 6, z + 25, Block15, 0, 3);
		world.setBlock(x + 12, y + 6, z + 25, Block15, 0, 3);
		world.setBlock(x + 4, y + 6, z + 26, Block15, 0, 3);
		world.setBlock(x + 12, y + 6, z + 26, Block15, 0, 3);
		world.setBlock(x + 4, y + 6, z + 27, Block15, 0, 3);
		world.setBlock(x + 12, y + 6, z + 27, Block15, 0, 3);
		world.setBlock(x + 5, y + 6, z + 28, Block15, 0, 3);
		world.setBlock(x + 11, y + 6, z + 28, Block15, 0, 3);
		world.setBlock(x + 6, y + 6, z + 29, Block15, 0, 3);
		world.setBlock(x + 7, y + 6, z + 29, Block15, 0, 3);
		world.setBlock(x + 8, y + 6, z + 29, Block15, 0, 3);
		world.setBlock(x + 9, y + 6, z + 29, Block15, 0, 3);
		world.setBlock(x + 10, y + 6, z + 29, Block15, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 17; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 18; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 19; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 20; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 21; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 22; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 24; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 25; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 26; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 27; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 28; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 29; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 30; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 31; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 32; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 33; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 34; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 35; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 36; int nativePlacementY = y + 7; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 7; int nativePlacementZ = z + 7; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 19, y + 7, z + 7, Block6, 0, 3);
		world.setBlock(x + 20, y + 7, z + 7, Block6, 0, 3);
		world.setBlock(x + 21, y + 7, z + 7, Block6, 0, 3);
		world.setBlock(x + 22, y + 7, z + 7, Block6, 0, 3);
		world.setBlock(x + 23, y + 7, z + 7, Block6, 0, 3);
		world.setBlock(x + 24, y + 7, z + 7, Block6, 0, 3);
		world.setBlock(x + 25, y + 7, z + 7, Block6, 0, 3);
		world.setBlock(x + 26, y + 7, z + 7, Block6, 0, 3);
		world.setBlock(x + 27, y + 7, z + 7, Block6, 0, 3);
		world.setBlock(x + 28, y + 7, z + 7, Block6, 0, 3);
		world.setBlock(x + 29, y + 7, z + 7, Block6, 0, 3);
		world.setBlock(x + 30, y + 7, z + 7, Block6, 0, 3);
		world.setBlock(x + 31, y + 7, z + 7, Block6, 0, 3);
		world.setBlock(x + 32, y + 7, z + 7, Block6, 0, 3);
		world.setBlock(x + 33, y + 7, z + 7, Block6, 0, 3);
		world.setBlock(x + 34, y + 7, z + 7, Block6, 0, 3);
		world.setBlock(x + 35, y + 7, z + 7, Block6, 0, 3);
		world.setBlock(x + 36, y + 7, z + 7, Block6, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 7; int nativePlacementZ = z + 7; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 7; int nativePlacementZ = z + 8; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 19, y + 7, z + 8, Block6, 0, 3);
		world.setBlock(x + 20, y + 7, z + 8, Block6, 0, 3);
		world.setBlock(x + 21, y + 7, z + 8, Block6, 0, 3);
		world.setBlock(x + 22, y + 7, z + 8, Block6, 0, 3);
		world.setBlock(x + 23, y + 7, z + 8, Block6, 0, 3);
		world.setBlock(x + 24, y + 7, z + 8, Block6, 0, 3);
		world.setBlock(x + 25, y + 7, z + 8, Block6, 0, 3);
		world.setBlock(x + 26, y + 7, z + 8, Block6, 0, 3);
		world.setBlock(x + 27, y + 7, z + 8, Block6, 0, 3);
		world.setBlock(x + 28, y + 7, z + 8, Block6, 0, 3);
		world.setBlock(x + 29, y + 7, z + 8, Block6, 0, 3);
		world.setBlock(x + 30, y + 7, z + 8, Block6, 0, 3);
		world.setBlock(x + 31, y + 7, z + 8, Block6, 0, 3);
		world.setBlock(x + 32, y + 7, z + 8, Block6, 0, 3);
		world.setBlock(x + 33, y + 7, z + 8, Block6, 0, 3);
		world.setBlock(x + 34, y + 7, z + 8, Block6, 0, 3);
		world.setBlock(x + 35, y + 7, z + 8, Block6, 0, 3);
		world.setBlock(x + 36, y + 7, z + 8, Block6, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 7; int nativePlacementZ = z + 8; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 6, y + 7, z + 9, Block5, 0, 3);
		world.setBlock(x + 7, y + 7, z + 9, Block5, 0, 3);
		world.setBlock(x + 8, y + 7, z + 9, Block5, 0, 3);
		world.setBlock(x + 9, y + 7, z + 9, Block5, 0, 3);
		world.setBlock(x + 10, y + 7, z + 9, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 7; int nativePlacementZ = z + 9; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 19, y + 7, z + 9, Block6, 0, 3);
		world.setBlock(x + 20, y + 7, z + 9, Block25, 0, 3);
		world.setBlock(x + 21, y + 7, z + 9, Block25, 0, 3);
		world.setBlock(x + 22, y + 7, z + 9, Block25, 0, 3);
		world.setBlock(x + 23, y + 7, z + 9, Block25, 0, 3);
		world.setBlock(x + 24, y + 7, z + 9, Block6, 0, 3);
		world.setBlock(x + 25, y + 7, z + 9, Block6, 0, 3);
		world.setBlock(x + 26, y + 7, z + 9, Block6, 0, 3);
		world.setBlock(x + 27, y + 7, z + 9, Block6, 0, 3);
		world.setBlock(x + 28, y + 7, z + 9, Block6, 0, 3);
		world.setBlock(x + 29, y + 7, z + 9, Block6, 0, 3);
		world.setBlock(x + 30, y + 7, z + 9, Block6, 0, 3);
		world.setBlock(x + 31, y + 7, z + 9, Block6, 0, 3);
		world.setBlock(x + 32, y + 7, z + 9, Block6, 0, 3);
		world.setBlock(x + 33, y + 7, z + 9, Block6, 0, 3);
		world.setBlock(x + 34, y + 7, z + 9, Block6, 0, 3);
		world.setBlock(x + 35, y + 7, z + 9, Block6, 0, 3);
		world.setBlock(x + 36, y + 7, z + 9, Block6, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 7; int nativePlacementZ = z + 9; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 5, y + 7, z + 10, Block5, 0, 3);
		world.setBlock(x + 6, y + 7, z + 10, Block5, 0, 3);
		world.setBlock(x + 10, y + 7, z + 10, Block5, 0, 3);
		world.setBlock(x + 11, y + 7, z + 10, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 7; int nativePlacementZ = z + 10; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 19, y + 7, z + 10, Block6, 0, 3);
		world.setBlock(x + 20, y + 7, z + 10, Block25, 0, 3);
		world.setBlock(x + 21, y + 7, z + 10, Block6, 0, 3);
		world.setBlock(x + 22, y + 7, z + 10, Block6, 0, 3);
		world.setBlock(x + 23, y + 7, z + 10, Block6, 0, 3);
		world.setBlock(x + 24, y + 7, z + 10, Block6, 0, 3);
		world.setBlock(x + 25, y + 7, z + 10, Block6, 0, 3);
		world.setBlock(x + 26, y + 7, z + 10, Block6, 0, 3);
		world.setBlock(x + 27, y + 7, z + 10, Block6, 0, 3);
		world.setBlock(x + 28, y + 7, z + 10, Block6, 0, 3);
		world.setBlock(x + 29, y + 7, z + 10, Block6, 0, 3);
		world.setBlock(x + 30, y + 7, z + 10, Block6, 0, 3);
		world.setBlock(x + 31, y + 7, z + 10, Block6, 0, 3);
		world.setBlock(x + 32, y + 7, z + 10, Block6, 0, 3);
		world.setBlock(x + 33, y + 7, z + 10, Block6, 0, 3);
		world.setBlock(x + 34, y + 7, z + 10, Block6, 0, 3);
		world.setBlock(x + 35, y + 7, z + 10, Block6, 0, 3);
		world.setBlock(x + 36, y + 7, z + 10, Block18, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 7; int nativePlacementZ = z + 10; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 5, y + 7, z + 11, Block5, 0, 3);
		world.setBlock(x + 11, y + 7, z + 11, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 7; int nativePlacementZ = z + 11; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 19, y + 7, z + 11, Block6, 0, 3);
		world.setBlock(x + 20, y + 7, z + 11, Block25, 0, 3);
		world.setBlock(x + 21, y + 7, z + 11, Block6, 0, 3);
		world.setBlock(x + 22, y + 7, z + 11, Block6, 0, 3);
		world.setBlock(x + 23, y + 7, z + 11, Block6, 0, 3);
		world.setBlock(x + 24, y + 7, z + 11, Block6, 0, 3);
		world.setBlock(x + 25, y + 7, z + 11, Block6, 0, 3);
		world.setBlock(x + 26, y + 7, z + 11, Block6, 0, 3);
		world.setBlock(x + 27, y + 7, z + 11, Block6, 0, 3);
		world.setBlock(x + 28, y + 7, z + 11, Block6, 0, 3);
		world.setBlock(x + 29, y + 7, z + 11, Block6, 0, 3);
		world.setBlock(x + 30, y + 7, z + 11, Block6, 0, 3);
		world.setBlock(x + 31, y + 7, z + 11, Block6, 0, 3);
		world.setBlock(x + 32, y + 7, z + 11, Block6, 0, 3);
		world.setBlock(x + 33, y + 7, z + 11, Block6, 0, 3);
		world.setBlock(x + 34, y + 7, z + 11, Block6, 0, 3);
		world.setBlock(x + 35, y + 7, z + 11, Block18, 0, 3);
		world.setBlock(x + 36, y + 7, z + 11, Block18, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 7; int nativePlacementZ = z + 11; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 5, y + 7, z + 12, Block5, 0, 3);
		world.setBlock(x + 8, y + 7, z + 12, Block25, 0, 3);
		world.setBlock(x + 9, y + 7, z + 12, Block25, 0, 3);
		world.setBlock(x + 10, y + 7, z + 12, Block25, 0, 3);
		world.setBlock(x + 11, y + 7, z + 12, Block25, 0, 3);
		world.setBlock(x + 12, y + 7, z + 12, Block25, 0, 3);
		world.setBlock(x + 13, y + 7, z + 12, Block25, 0, 3);
		world.setBlock(x + 14, y + 7, z + 12, Block25, 0, 3);
		world.setBlock(x + 15, y + 7, z + 12, Block25, 0, 3);
		world.setBlock(x + 16, y + 7, z + 12, Block25, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 7, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + 7, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		world.setBlock(x + 19, y + 7, z + 12, Block6, 0, 3);
		world.setBlock(x + 20, y + 7, z + 12, Block25, 0, 3);
		world.setBlock(x + 21, y + 7, z + 12, Block6, 0, 3);
		world.setBlock(x + 22, y + 7, z + 12, Block6, 0, 3);
		world.setBlock(x + 23, y + 7, z + 12, Block6, 0, 3);
		world.setBlock(x + 24, y + 7, z + 12, Block6, 0, 3);
		world.setBlock(x + 25, y + 7, z + 12, Block6, 0, 3);
		world.setBlock(x + 26, y + 7, z + 12, Block6, 0, 3);
		world.setBlock(x + 27, y + 7, z + 12, Block6, 0, 3);
		world.setBlock(x + 28, y + 7, z + 12, Block6, 0, 3);
		world.setBlock(x + 29, y + 7, z + 12, Block6, 0, 3);
		world.setBlock(x + 30, y + 7, z + 12, Block6, 0, 3);
		world.setBlock(x + 31, y + 7, z + 12, Block6, 0, 3);
		world.setBlock(x + 32, y + 7, z + 12, Block6, 0, 3);
		world.setBlock(x + 33, y + 7, z + 12, Block18, 0, 3);
		world.setBlock(x + 34, y + 7, z + 12, Block18, 0, 3);
		world.setBlock(x + 35, y + 7, z + 12, Block18, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 37, y + 7, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 5, y + 7, z + 13, Block5, 0, 3);
		world.setBlock(x + 11, y + 7, z + 13, Block5, 0, 3);
		world.setBlock(x + 16, y + 7, z + 13, Block25, 0, 3);
		world.setBlock(x + 17, y + 7, z + 13, Block6, 0, 3);
		world.setBlock(x + 18, y + 7, z + 13, Block6, 0, 3);
		world.setBlock(x + 19, y + 7, z + 13, Block6, 0, 3);
		world.setBlock(x + 20, y + 7, z + 13, Block25, 0, 3);
		world.setBlock(x + 21, y + 7, z + 13, Block6, 0, 3);
		world.setBlock(x + 22, y + 7, z + 13, Block6, 0, 3);
		world.setBlock(x + 23, y + 7, z + 13, Block6, 0, 3);
		world.setBlock(x + 24, y + 7, z + 13, Block6, 0, 3);
		world.setBlock(x + 25, y + 7, z + 13, Block6, 0, 3);
		world.setBlock(x + 26, y + 7, z + 13, Block6, 0, 3);
		world.setBlock(x + 27, y + 7, z + 13, Block6, 0, 3);
		world.setBlock(x + 28, y + 7, z + 13, Block6, 0, 3);
		world.setBlock(x + 29, y + 7, z + 13, Block6, 0, 3);
		world.setBlock(x + 30, y + 7, z + 13, Block6, 0, 3);
		world.setBlock(x + 31, y + 7, z + 13, Block6, 0, 3);
		world.setBlock(x + 32, y + 7, z + 13, Block6, 0, 3);
		world.setBlock(x + 33, y + 7, z + 13, Block18, 0, 3);
		world.setBlock(x + 34, y + 7, z + 13, Block18, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 7, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		world.setBlock(x + 5, y + 7, z + 14, Block5, 0, 3);
		world.setBlock(x + 6, y + 7, z + 14, Block5, 0, 3);
		world.setBlock(x + 10, y + 7, z + 14, Block5, 0, 3);
		world.setBlock(x + 11, y + 7, z + 14, Block5, 0, 3);
		world.setBlock(x + 16, y + 7, z + 14, Block25, 0, 3);
		world.setBlock(x + 17, y + 7, z + 14, Block25, 0, 3);
		world.setBlock(x + 18, y + 7, z + 14, Block25, 0, 3);
		world.setBlock(x + 19, y + 7, z + 14, Block25, 0, 3);
		world.setBlock(x + 20, y + 7, z + 14, Block25, 0, 3);
		world.setBlock(x + 21, y + 7, z + 14, Block25, 0, 3);
		world.setBlock(x + 22, y + 7, z + 14, Block25, 0, 3);
		world.setBlock(x + 23, y + 7, z + 14, Block25, 0, 3);
		world.setBlock(x + 24, y + 7, z + 14, Block25, 0, 3);
		world.setBlock(x + 25, y + 7, z + 14, Block25, 0, 3);
		world.setBlock(x + 26, y + 7, z + 14, Block25, 0, 3);
		world.setBlock(x + 27, y + 7, z + 14, Block25, 0, 3);
		world.setBlock(x + 28, y + 7, z + 14, Block25, 0, 3);
		world.setBlock(x + 29, y + 7, z + 14, Block25, 0, 3);
		world.setBlock(x + 30, y + 7, z + 14, Block6, 0, 3);
		world.setBlock(x + 31, y + 7, z + 14, Block6, 0, 3);
		world.setBlock(x + 32, y + 7, z + 14, Block18, 0, 3);
		world.setBlock(x + 33, y + 7, z + 14, Block18, 0, 3);
		world.setBlock(x + 34, y + 7, z + 14, Block18, 0, 3);
		world.setBlock(x + 6, y + 7, z + 15, Block5, 0, 3);
		world.setBlock(x + 7, y + 7, z + 15, Block5, 0, 3);
		world.setBlock(x + 8, y + 7, z + 15, Block5, 0, 3);
		world.setBlock(x + 9, y + 7, z + 15, Block5, 0, 3);
		world.setBlock(x + 10, y + 7, z + 15, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 7; int nativePlacementZ = z + 15; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 17, y + 7, z + 15, Block6, 0, 3);
		world.setBlock(x + 18, y + 7, z + 15, Block6, 0, 3);
		world.setBlock(x + 19, y + 7, z + 15, Block6, 0, 3);
		world.setBlock(x + 20, y + 7, z + 15, Block6, 0, 3);
		world.setBlock(x + 21, y + 7, z + 15, Block6, 0, 3);
		world.setBlock(x + 22, y + 7, z + 15, Block6, 0, 3);
		world.setBlock(x + 23, y + 7, z + 15, Block6, 0, 3);
		world.setBlock(x + 24, y + 7, z + 15, Block6, 0, 3);
		world.setBlock(x + 25, y + 7, z + 15, Block6, 0, 3);
		world.setBlock(x + 26, y + 7, z + 15, Block6, 0, 3);
		world.setBlock(x + 27, y + 7, z + 15, Block6, 0, 3);
		world.setBlock(x + 28, y + 7, z + 15, Block6, 0, 3);
		world.setBlock(x + 29, y + 7, z + 15, Block6, 0, 3);
		world.setBlock(x + 30, y + 7, z + 15, Block6, 0, 3);
		world.setBlock(x + 31, y + 7, z + 15, Block6, 0, 3);
		world.setBlock(x + 32, y + 7, z + 15, Block18, 0, 3);
		world.setBlock(x + 33, y + 7, z + 15, Block18, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 34, y + 7, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		world.setBlock(x + 8, y + 7, z + 16, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 7; int nativePlacementZ = z + 16; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 17, y + 7, z + 16, Block6, 0, 3);
		world.setBlock(x + 18, y + 7, z + 16, Block6, 0, 3);
		world.setBlock(x + 19, y + 7, z + 16, Block6, 0, 3);
		world.setBlock(x + 20, y + 7, z + 16, Block6, 0, 3);
		world.setBlock(x + 21, y + 7, z + 16, Block6, 0, 3);
		world.setBlock(x + 22, y + 7, z + 16, Block6, 0, 3);
		world.setBlock(x + 23, y + 7, z + 16, Block6, 0, 3);
		world.setBlock(x + 24, y + 7, z + 16, Block6, 0, 3);
		world.setBlock(x + 25, y + 7, z + 16, Block6, 0, 3);
		world.setBlock(x + 26, y + 7, z + 16, Block6, 0, 3);
		world.setBlock(x + 27, y + 7, z + 16, Block6, 0, 3);
		world.setBlock(x + 28, y + 7, z + 16, Block6, 0, 3);
		world.setBlock(x + 29, y + 7, z + 16, Block6, 0, 3);
		world.setBlock(x + 30, y + 7, z + 16, Block6, 0, 3);
		world.setBlock(x + 31, y + 7, z + 16, Block18, 0, 3);
		world.setBlock(x + 32, y + 7, z + 16, Block18, 0, 3);
		world.setBlock(x + 33, y + 7, z + 16, Block18, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 34, y + 7, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		world.setBlock(x + 8, y + 7, z + 17, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 7; int nativePlacementZ = z + 17; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 17, y + 7, z + 17, Block6, 0, 3);
		world.setBlock(x + 18, y + 7, z + 17, Block6, 0, 3);
		world.setBlock(x + 19, y + 7, z + 17, Block6, 0, 3);
		world.setBlock(x + 20, y + 7, z + 17, Block6, 0, 3);
		world.setBlock(x + 21, y + 7, z + 17, Block6, 0, 3);
		world.setBlock(x + 22, y + 7, z + 17, Block6, 0, 3);
		world.setBlock(x + 23, y + 7, z + 17, Block6, 0, 3);
		world.setBlock(x + 24, y + 7, z + 17, Block6, 0, 3);
		world.setBlock(x + 25, y + 7, z + 17, Block6, 0, 3);
		world.setBlock(x + 26, y + 7, z + 17, Block6, 0, 3);
		world.setBlock(x + 27, y + 7, z + 17, Block6, 0, 3);
		world.setBlock(x + 28, y + 7, z + 17, Block6, 0, 3);
		world.setBlock(x + 29, y + 7, z + 17, Block6, 0, 3);
		world.setBlock(x + 30, y + 7, z + 17, Block6, 0, 3);
		world.setBlock(x + 31, y + 7, z + 17, Block18, 0, 3);
		world.setBlock(x + 32, y + 7, z + 17, Block18, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 33, y + 7, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		world.setBlock(x + 8, y + 7, z + 18, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 7; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 17; int nativePlacementY = y + 7; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 18; int nativePlacementY = y + 7; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 19; int nativePlacementY = y + 7; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 20; int nativePlacementY = y + 7; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 21; int nativePlacementY = y + 7; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 22; int nativePlacementY = y + 7; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 7; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 24; int nativePlacementY = y + 7; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 25; int nativePlacementY = y + 7; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 26; int nativePlacementY = y + 7; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 27; int nativePlacementY = y + 7; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 28; int nativePlacementY = y + 7; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 29; int nativePlacementY = y + 7; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 30; int nativePlacementY = y + 7; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 31; int nativePlacementY = y + 7; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 32; int nativePlacementY = y + 7; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 33; int nativePlacementY = y + 7; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 8, y + 7, z + 19, Block5, 0, 3);
		world.setBlock(x + 8, y + 7, z + 20, Block5, 0, 3);
		world.setBlock(x + 6, y + 7, z + 21, Block15, 0, 3);
		world.setBlock(x + 7, y + 7, z + 21, Block15, 0, 3);
		world.setBlock(x + 8, y + 7, z + 21, Block15, 0, 3);
		world.setBlock(x + 9, y + 7, z + 21, Block15, 0, 3);
		world.setBlock(x + 10, y + 7, z + 21, Block15, 0, 3);
		world.setBlock(x + 5, y + 7, z + 22, Block15, 0, 3);
		world.setBlock(x + 6, y + 7, z + 22, Block7, 0, 3);
		world.setBlock(x + 7, y + 7, z + 22, Block7, 0, 3);
		world.setBlock(x + 8, y + 7, z + 22, Block7, 0, 3);
		world.setBlock(x + 9, y + 7, z + 22, Block7, 0, 3);
		world.setBlock(x + 10, y + 7, z + 22, Block7, 0, 3);
		world.setBlock(x + 11, y + 7, z + 22, Block15, 0, 3);
		world.setBlock(x + 4, y + 7, z + 23, Block15, 0, 3);
		world.setBlock(x + 5, y + 7, z + 23, Block7, 0, 3);
		world.setBlock(x + 7, y + 7, z + 23, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 8, y + 7, z + 23, Block7, 0, 3);
		world.setBlock(x + 11, y + 7, z + 23, Block7, 0, 3);
		world.setBlock(x + 12, y + 7, z + 23, Block15, 0, 3);
		world.setBlock(x + 4, y + 7, z + 24, Block15, 0, 3);
		world.setBlock(x + 5, y + 7, z + 24, Block7, 0, 3);
		world.setBlock(x + 8, y + 7, z + 24, Block7, 0, 3);
		world.setBlock(x + 9, y + 7, z + 24, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 11, y + 7, z + 24, Block7, 0, 3);
		world.setBlock(x + 12, y + 7, z + 24, Block15, 0, 3);
		world.setBlock(x + 4, y + 7, z + 25, Block15, 0, 3);
		world.setBlock(x + 5, y + 7, z + 25, Block7, 0, 3);
		world.setBlock(x + 7, y + 7, z + 25, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 8, y + 7, z + 25, Block7, 0, 3);
		world.setBlock(x + 9, y + 7, z + 25, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 11, y + 7, z + 25, Block7, 0, 3);
		world.setBlock(x + 12, y + 7, z + 25, Block15, 0, 3);
		world.setBlock(x + 4, y + 7, z + 26, Block15, 0, 3);
		world.setBlock(x + 5, y + 7, z + 26, Block7, 0, 3);
		world.setBlock(x + 8, y + 7, z + 26, Block7, 0, 3);
		world.setBlock(x + 11, y + 7, z + 26, Block7, 0, 3);
		world.setBlock(x + 12, y + 7, z + 26, Block15, 0, 3);
		world.setBlock(x + 4, y + 7, z + 27, Block15, 0, 3);
		world.setBlock(x + 5, y + 7, z + 27, Block7, 0, 3);
		world.setBlock(x + 7, y + 7, z + 27, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 8, y + 7, z + 27, Block7, 0, 3);
		world.setBlock(x + 9, y + 7, z + 27, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 11, y + 7, z + 27, Block7, 0, 3);
		world.setBlock(x + 12, y + 7, z + 27, Block15, 0, 3);
		world.setBlock(x + 5, y + 7, z + 28, Block15, 0, 3);
		world.setBlock(x + 6, y + 7, z + 28, Block7, 0, 3);
		world.setBlock(x + 7, y + 7, z + 28, Block7, 0, 3);
		world.setBlock(x + 8, y + 7, z + 28, Block7, 0, 3);
		world.setBlock(x + 9, y + 7, z + 28, Block7, 0, 3);
		world.setBlock(x + 10, y + 7, z + 28, Block7, 0, 3);
		world.setBlock(x + 11, y + 7, z + 28, Block15, 0, 3);
		world.setBlock(x + 6, y + 7, z + 29, Block15, 0, 3);
		world.setBlock(x + 7, y + 7, z + 29, Block15, 0, 3);
		world.setBlock(x + 8, y + 7, z + 29, Block15, 0, 3);
		world.setBlock(x + 9, y + 7, z + 29, Block15, 0, 3);
		world.setBlock(x + 10, y + 7, z + 29, Block15, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 17; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 18; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 19; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 20; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 21; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 25; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 26; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 27; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 28; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 29; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 30; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 31; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 32; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 33; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 34; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 35; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 36; int nativePlacementY = y + 8; int nativePlacementZ = z + 6; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 8; int nativePlacementZ = z + 7; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 19, y + 8, z + 7, ModBlocks.fence_metal, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 8; int nativePlacementZ = z + 8; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 19, y + 8, z + 8, ModBlocks.fence_metal, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 8; int nativePlacementZ = z + 8; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 6, y + 8, z + 9, Block5, 0, 3);
		world.setBlock(x + 7, y + 8, z + 9, Block5, 0, 3);
		world.setBlock(x + 8, y + 8, z + 9, Block5, 0, 3);
		world.setBlock(x + 9, y + 8, z + 9, Block5, 0, 3);
		world.setBlock(x + 10, y + 8, z + 9, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 8; int nativePlacementZ = z + 9; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 19, y + 8, z + 9, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 23, y + 8, z + 9, Block25, 0, 3);
		world.setBlock(x + 24, y + 8, z + 9, Block25, 0, 3);
		world.setBlock(x + 25, y + 8, z + 9, Block28, 0, 3);
		world.setBlock(x + 26, y + 8, z + 9, Block25, 0, 3);
		world.setBlock(x + 27, y + 8, z + 9, Block25, 0, 3);
		world.setBlock(x + 28, y + 8, z + 9, Block28, 0, 3);
		world.setBlock(x + 29, y + 8, z + 9, Block25, 0, 3);
		world.setBlock(x + 30, y + 8, z + 9, Block25, 0, 3);
		world.setBlock(x + 31, y + 8, z + 9, Block29, 3, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 8; int nativePlacementZ = z + 9; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 5, y + 8, z + 10, Block5, 0, 3);
		world.setBlock(x + 6, y + 8, z + 10, Block5, 0, 3);
		world.setBlock(x + 7, y + 8, z + 10, Block11, 0, 3);
		world.setBlock(x + 8, y + 8, z + 10, Block5, 0, 3);
		world.setBlock(x + 9, y + 8, z + 10, Block11, 0, 3);
		world.setBlock(x + 10, y + 8, z + 10, Block5, 0, 3);
		world.setBlock(x + 11, y + 8, z + 10, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 8; int nativePlacementZ = z + 10; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 37; int nativePlacementY = y + 8; int nativePlacementZ = z + 10; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 5, y + 8, z + 11, Block5, 0, 3);
		world.setBlock(x + 6, y + 8, z + 11, Block11, 0, 3);
		world.setBlock(x + 10, y + 8, z + 11, Block11, 0, 3);
		world.setBlock(x + 11, y + 8, z + 11, Block5, 0, 3);
		world.setBlock(x + 12, y + 8, z + 11, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 14, y + 8, z + 11, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 15, y + 8, z + 11, ModBlocks.fence_metal, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 8; int nativePlacementZ = z + 11; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 19, y + 8, z + 11, ModBlocks.fence_metal, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 37, y + 8, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 5, y + 8, z + 12, Block5, 0, 3);
		world.setBlock(x + 6, y + 8, z + 12, Block5, 0, 3);
		world.setBlock(x + 8, y + 8, z + 12, Block25, 0, 3);
		world.setBlock(x + 10, y + 8, z + 12, Block5, 0, 3);
		world.setBlock(x + 11, y + 8, z + 12, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 8; int nativePlacementZ = z + 12; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 19, y + 8, z + 12, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 5, y + 8, z + 13, Block5, 0, 3);
		world.setBlock(x + 6, y + 8, z + 13, Block11, 0, 3);
		world.setBlock(x + 10, y + 8, z + 13, Block11, 0, 3);
		world.setBlock(x + 11, y + 8, z + 13, Block5, 0, 3);
		world.setBlock(x + 12, y + 8, z + 13, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 13, y + 8, z + 13, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 14, y + 8, z + 13, ModBlocks.fence_metal, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 8; int nativePlacementZ = z + 13; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 33, y + 8, z + 13, Block13, 5, 3);
		world.setBlock(x + 5, y + 8, z + 14, Block5, 0, 3);
		world.setBlock(x + 6, y + 8, z + 14, Block5, 0, 3);
		world.setBlock(x + 7, y + 8, z + 14, Block11, 0, 3);
		world.setBlock(x + 8, y + 8, z + 14, Block5, 0, 3);
		world.setBlock(x + 9, y + 8, z + 14, Block11, 0, 3);
		world.setBlock(x + 10, y + 8, z + 14, Block5, 0, 3);
		world.setBlock(x + 11, y + 8, z + 14, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 8; int nativePlacementZ = z + 14; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 22, y + 8, z + 14, Block5, 0, 3);
		world.setBlock(x + 23, y + 8, z + 14, Block25, 0, 3);
		world.setBlock(x + 27, y + 8, z + 14, Block5, 0, 3);
		world.setBlock(x + 28, y + 8, z + 14, Block25, 0, 3);
		world.setBlock(x + 29, y + 8, z + 14, Block5, 0, 3);
		world.setBlock(x + 32, y + 8, z + 14, Block8, 5, 3);
		world.setBlock(x + 6, y + 8, z + 15, Block5, 0, 3);
		world.setBlock(x + 7, y + 8, z + 15, Block5, 0, 3);
		world.setBlock(x + 8, y + 8, z + 15, Block5, 0, 3);
		world.setBlock(x + 9, y + 8, z + 15, Block5, 0, 3);
		world.setBlock(x + 10, y + 8, z + 15, Block5, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 8; int nativePlacementZ = z + 15; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 22, y + 8, z + 15, Block5, 0, 3);
		world.setBlock(x + 23, y + 8, z + 15, Block5, 0, 3);
		world.setBlock(x + 24, y + 8, z + 15, Block5, 0, 3);
		world.setBlock(x + 27, y + 8, z + 15, Block5, 0, 3);
		world.setBlock(x + 28, y + 8, z + 15, Block5, 0, 3);
		world.setBlock(x + 29, y + 8, z + 15, Block5, 0, 3);
		world.setBlock(x + 30, y + 8, z + 15, Block8, 2, 3);
		world.setBlock(x + 31, y + 8, z + 15, Block8, 3, 3);
		world.setBlock(x + 7, y + 8, z + 16, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 9, y + 8, z + 16, ModBlocks.fence_metal, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 8; int nativePlacementZ = z + 16; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 22, y + 8, z + 16, Block5, 0, 3);
		world.setBlock(x + 23, y + 8, z + 16, Block5, 0, 3);
		world.setBlock(x + 24, y + 8, z + 16, Block5, 0, 3);
		world.setBlock(x + 27, y + 8, z + 16, Block5, 0, 3);
		world.setBlock(x + 28, y + 8, z + 16, Block5, 0, 3);
		world.setBlock(x + 29, y + 8, z + 16, Block5, 0, 3);
		world.setBlock(x + 7, y + 8, z + 17, ModBlocks.fence_metal, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 8; int nativePlacementZ = z + 17; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		world.setBlock(x + 7, y + 8, z + 18, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 9, y + 8, z + 18, ModBlocks.fence_metal, 0, 3);
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 16; int nativePlacementY = y + 8; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 17; int nativePlacementY = y + 8; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 18; int nativePlacementY = y + 8; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 19; int nativePlacementY = y + 8; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 20; int nativePlacementY = y + 8; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 21; int nativePlacementY = y + 8; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 22; int nativePlacementY = y + 8; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 23; int nativePlacementY = y + 8; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 24; int nativePlacementY = y + 8; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 25; int nativePlacementY = y + 8; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 26; int nativePlacementY = y + 8; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 27; int nativePlacementY = y + 8; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 28; int nativePlacementY = y + 8; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 29; int nativePlacementY = y + 8; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 30; int nativePlacementY = y + 8; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 31; int nativePlacementY = y + 8; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ net.minecraft.world.World nativePlacementWorld = world; int nativePlacementX = x + 32; int nativePlacementY = y + 8; int nativePlacementZ = z + 18; net.minecraft.block.Block nativePlacementBlock = Library.getRandomConcrete(); int nativePlacementMeta = 0; int nativePlacementFlags = 3; if (nativePlacementWorld == null) throw new NullPointerException(); if (nativePlacementX >= -30000000 && nativePlacementX < 30000000 && nativePlacementZ >= -30000000 && nativePlacementZ < 30000000 && nativePlacementY >= 0 && nativePlacementY < 256) nativePlacementWorld.setBlockState(new net.minecraft.util.math.BlockPos(nativePlacementX, nativePlacementY, nativePlacementZ), nativePlacementBlock.getStateFromMeta(nativePlacementMeta), nativePlacementFlags); }
		{ BlockPos dungeonPos = new BlockPos(x + 33, y + 8, z + 18); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 9, y + 8, z + 19, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 7, y + 8, z + 21, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 9, y + 8, z + 21, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 8, z + 22, Block15, 0, 3);
		world.setBlock(x + 7, y + 8, z + 22, Block15, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 8, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.IRON_DOOR.getStateFromMeta(1), 3); }
        ItemDoor.placeDoorBlock(world, x + 8, y + 8, z + 22, 1, Blocks.IRON_DOOR);
		world.setBlock(x + 9, y + 8, z + 22, Block15, 0, 3);
		world.setBlock(x + 10, y + 8, z + 22, Block15, 0, 3);
		world.setBlock(x + 5, y + 8, z + 23, Block15, 0, 3);
		world.setBlock(x + 7, y + 8, z + 23, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 11, y + 8, z + 23, Block15, 0, 3);
		world.setBlock(x + 5, y + 8, z + 24, Block15, 0, 3);
		world.setBlock(x + 9, y + 8, z + 24, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 11, y + 8, z + 24, Block15, 0, 3);
		world.setBlock(x + 5, y + 8, z + 25, Block15, 0, 3);
		world.setBlock(x + 9, y + 8, z + 25, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 11, y + 8, z + 25, Block15, 0, 3);
		world.setBlock(x + 5, y + 8, z + 26, Block15, 0, 3);
		world.setBlock(x + 11, y + 8, z + 26, Block15, 0, 3);
		world.setBlock(x + 5, y + 8, z + 27, Block15, 0, 3);
		world.setBlock(x + 7, y + 8, z + 27, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 9, y + 8, z + 27, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 11, y + 8, z + 27, Block15, 0, 3);
		world.setBlock(x + 6, y + 8, z + 28, Block15, 0, 3);
		world.setBlock(x + 7, y + 8, z + 28, Block15, 0, 3);
		world.setBlock(x + 8, y + 8, z + 28, Block15, 0, 3);
		world.setBlock(x + 9, y + 8, z + 28, Block15, 0, 3);
		world.setBlock(x + 10, y + 8, z + 28, Block15, 0, 3);
		world.setBlock(x + 7, y + 9, z + 10, Block11, 0, 3);
		world.setBlock(x + 8, y + 9, z + 10, Block5, 0, 3);
		world.setBlock(x + 9, y + 9, z + 10, Block11, 0, 3);
		world.setBlock(x + 6, y + 9, z + 11, Block11, 0, 3);
		world.setBlock(x + 7, y + 9, z + 11, Block11, 0, 3);
		world.setBlock(x + 8, y + 9, z + 11, Block5, 0, 3);
		world.setBlock(x + 9, y + 9, z + 11, Block11, 0, 3);
		world.setBlock(x + 10, y + 9, z + 11, Block11, 0, 3);
		world.setBlock(x + 6, y + 9, z + 12, Block5, 0, 3);
		world.setBlock(x + 7, y + 9, z + 12, Block5, 0, 3);
		world.setBlock(x + 8, y + 9, z + 12, Block5, 0, 3);
		world.setBlock(x + 9, y + 9, z + 12, Block5, 0, 3);
		world.setBlock(x + 10, y + 9, z + 12, Block5, 0, 3);
		world.setBlock(x + 6, y + 9, z + 13, Block11, 0, 3);
		world.setBlock(x + 7, y + 9, z + 13, Block11, 0, 3);
		world.setBlock(x + 8, y + 9, z + 13, Block5, 0, 3);
		world.setBlock(x + 9, y + 9, z + 13, Block11, 0, 3);
		world.setBlock(x + 10, y + 9, z + 13, Block11, 0, 3);
		world.setBlock(x + 7, y + 9, z + 14, Block11, 0, 3);

		generate_r01(world, rand, x, y, z);
		return true;

	}
	public boolean generate_r01(World world, Random rand, int x, int y, int z)
	{

		world.setBlock(x + 8, y + 9, z + 14, Block5, 0, 3);
		world.setBlock(x + 9, y + 9, z + 14, Block11, 0, 3);
		world.setBlock(x + 23, y + 9, z + 15, Block5, 0, 3);
		world.setBlock(x + 28, y + 9, z + 15, Block5, 0, 3);
		world.setBlock(x + 29, y + 9, z + 15, Block8, 5, 3);
		world.setBlock(x + 6, y + 9, z + 22, Block15, 0, 3);
		world.setBlock(x + 7, y + 9, z + 22, Block15, 0, 3);
		//world.setBlock(x + 8, y + 9, z + 22, Blocks.iron_door, 8, 3);
		world.setBlock(x + 9, y + 9, z + 22, Block15, 0, 3);
		world.setBlock(x + 10, y + 9, z + 22, Block15, 0, 3);
		world.setBlock(x + 5, y + 9, z + 23, Block15, 0, 3);
		world.setBlock(x + 11, y + 9, z + 23, Block15, 0, 3);
		world.setBlock(x + 5, y + 9, z + 24, Block15, 0, 3);
		world.setBlock(x + 11, y + 9, z + 24, Block15, 0, 3);
		world.setBlock(x + 5, y + 9, z + 25, Block15, 0, 3);
		world.setBlock(x + 11, y + 9, z + 25, Block15, 0, 3);
		world.setBlock(x + 5, y + 9, z + 26, Block15, 0, 3);
		world.setBlock(x + 11, y + 9, z + 26, Block15, 0, 3);
		world.setBlock(x + 5, y + 9, z + 27, Block15, 0, 3);
		world.setBlock(x + 11, y + 9, z + 27, Block15, 0, 3);
		world.setBlock(x + 6, y + 9, z + 28, Block15, 0, 3);
		world.setBlock(x + 7, y + 9, z + 28, Block15, 0, 3);
		world.setBlock(x + 8, y + 9, z + 28, Block15, 0, 3);
		world.setBlock(x + 9, y + 9, z + 28, Block15, 0, 3);
		world.setBlock(x + 10, y + 9, z + 28, Block15, 0, 3);
		world.setBlock(x + 7, y + 10, z + 11, Block11, 0, 3);
		world.setBlock(x + 8, y + 10, z + 11, Block5, 0, 3);
		world.setBlock(x + 9, y + 10, z + 11, Block11, 0, 3);
		world.setBlock(x + 7, y + 10, z + 12, Block5, 0, 3);
		world.setBlock(x + 8, y + 10, z + 12, Block5, 0, 3);
		world.setBlock(x + 9, y + 10, z + 12, Block5, 0, 3);
		world.setBlock(x + 7, y + 10, z + 13, Block11, 0, 3);
		world.setBlock(x + 8, y + 10, z + 13, Block5, 0, 3);
		world.setBlock(x + 9, y + 10, z + 13, Block11, 0, 3);
		world.setBlock(x + 23, y + 10, z + 15, Block8, 5, 3);
		world.setBlock(x + 28, y + 10, z + 15, Block8, 5, 3);
		world.setBlock(x + 6, y + 10, z + 22, Block15, 0, 3);
		world.setBlock(x + 7, y + 10, z + 22, Block15, 0, 3);
		world.setBlock(x + 8, y + 10, z + 22, Block15, 0, 3);
		world.setBlock(x + 9, y + 10, z + 22, Block15, 0, 3);
		world.setBlock(x + 10, y + 10, z + 22, Block15, 0, 3);
		world.setBlock(x + 5, y + 10, z + 23, Block15, 0, 3);
		world.setBlock(x + 11, y + 10, z + 23, Block15, 0, 3);
		world.setBlock(x + 5, y + 10, z + 24, Block15, 0, 3);
		world.setBlock(x + 11, y + 10, z + 24, Block15, 0, 3);
		world.setBlock(x + 5, y + 10, z + 25, Block15, 0, 3);
		world.setBlock(x + 11, y + 10, z + 25, Block15, 0, 3);
		world.setBlock(x + 5, y + 10, z + 26, Block15, 0, 3);
		world.setBlock(x + 11, y + 10, z + 26, Block15, 0, 3);
		world.setBlock(x + 5, y + 10, z + 27, Block15, 0, 3);
		world.setBlock(x + 11, y + 10, z + 27, Block15, 0, 3);
		world.setBlock(x + 6, y + 10, z + 28, Block15, 0, 3);
		world.setBlock(x + 7, y + 10, z + 28, Block15, 0, 3);
		world.setBlock(x + 8, y + 10, z + 28, Block15, 0, 3);
		world.setBlock(x + 9, y + 10, z + 28, Block15, 0, 3);
		world.setBlock(x + 10, y + 10, z + 28, Block15, 0, 3);
		world.setBlock(x + 8, y + 11, z + 12, Block5, 0, 3);
		world.setBlock(x + 23, y + 11, z + 15, Block8, 5, 3);
		world.setBlock(x + 28, y + 11, z + 15, Block8, 5, 3);
		world.setBlock(x + 6, y + 11, z + 21, Block15, 0, 3);
		world.setBlock(x + 7, y + 11, z + 21, Block15, 0, 3);
		world.setBlock(x + 8, y + 11, z + 21, Block15, 0, 3);
		world.setBlock(x + 9, y + 11, z + 21, Block15, 0, 3);
		world.setBlock(x + 10, y + 11, z + 21, Block15, 0, 3);
		world.setBlock(x + 5, y + 11, z + 22, Block15, 0, 3);
		world.setBlock(x + 6, y + 11, z + 22, Block7, 0, 3);
		world.setBlock(x + 7, y + 11, z + 22, Block7, 0, 3);
		world.setBlock(x + 8, y + 11, z + 22, Block7, 0, 3);
		world.setBlock(x + 9, y + 11, z + 22, Block7, 0, 3);
		world.setBlock(x + 10, y + 11, z + 22, Block7, 0, 3);
		world.setBlock(x + 11, y + 11, z + 22, Block15, 0, 3);
		world.setBlock(x + 4, y + 11, z + 23, Block15, 0, 3);
		world.setBlock(x + 5, y + 11, z + 23, Block7, 0, 3);
		world.setBlock(x + 11, y + 11, z + 23, Block7, 0, 3);
		world.setBlock(x + 12, y + 11, z + 23, Block15, 0, 3);
		world.setBlock(x + 4, y + 11, z + 24, Block15, 0, 3);
		world.setBlock(x + 5, y + 11, z + 24, Block7, 0, 3);
		world.setBlock(x + 11, y + 11, z + 24, Block7, 0, 3);
		world.setBlock(x + 12, y + 11, z + 24, Block15, 0, 3);
		world.setBlock(x + 4, y + 11, z + 25, Block15, 0, 3);
		world.setBlock(x + 5, y + 11, z + 25, Block7, 0, 3);
		world.setBlock(x + 11, y + 11, z + 25, Block7, 0, 3);
		world.setBlock(x + 12, y + 11, z + 25, Block15, 0, 3);
		world.setBlock(x + 4, y + 11, z + 26, Block15, 0, 3);
		world.setBlock(x + 5, y + 11, z + 26, Block7, 0, 3);
		world.setBlock(x + 11, y + 11, z + 26, Block7, 0, 3);
		world.setBlock(x + 12, y + 11, z + 26, Block15, 0, 3);
		world.setBlock(x + 4, y + 11, z + 27, Block15, 0, 3);
		world.setBlock(x + 5, y + 11, z + 27, Block7, 0, 3);
		world.setBlock(x + 11, y + 11, z + 27, Block7, 0, 3);
		world.setBlock(x + 12, y + 11, z + 27, Block15, 0, 3);
		world.setBlock(x + 5, y + 11, z + 28, Block15, 0, 3);
		world.setBlock(x + 6, y + 11, z + 28, Block7, 0, 3);
		world.setBlock(x + 7, y + 11, z + 28, Block7, 0, 3);
		world.setBlock(x + 8, y + 11, z + 28, Block7, 0, 3);
		world.setBlock(x + 9, y + 11, z + 28, Block7, 0, 3);
		world.setBlock(x + 10, y + 11, z + 28, Block7, 0, 3);
		world.setBlock(x + 11, y + 11, z + 28, Block15, 0, 3);
		world.setBlock(x + 6, y + 11, z + 29, Block15, 0, 3);
		world.setBlock(x + 7, y + 11, z + 29, Block15, 0, 3);
		world.setBlock(x + 8, y + 11, z + 29, Block15, 0, 3);
		world.setBlock(x + 9, y + 11, z + 29, Block15, 0, 3);
		world.setBlock(x + 10, y + 11, z + 29, Block15, 0, 3);
		world.setBlock(x + 8, y + 12, z + 12, Block27, 3, 3);
		world.setBlock(x + 23, y + 12, z + 15, Block8, 5, 3);
		world.setBlock(x + 28, y + 12, z + 15, Block8, 5, 3);
		world.setBlock(x + 6, y + 12, z + 20, Block15, 0, 3);
		world.setBlock(x + 7, y + 12, z + 20, Block15, 0, 3);
		world.setBlock(x + 8, y + 12, z + 20, Block15, 0, 3);
		world.setBlock(x + 9, y + 12, z + 20, Block15, 0, 3);
		world.setBlock(x + 10, y + 12, z + 20, Block15, 0, 3);
		world.setBlock(x + 5, y + 12, z + 21, Block15, 0, 3);
		world.setBlock(x + 6, y + 12, z + 21, Block7, 0, 3);
		world.setBlock(x + 7, y + 12, z + 21, Block7, 0, 3);
		world.setBlock(x + 8, y + 12, z + 21, Block7, 0, 3);
		world.setBlock(x + 9, y + 12, z + 21, Block7, 0, 3);
		world.setBlock(x + 10, y + 12, z + 21, Block7, 0, 3);
		world.setBlock(x + 11, y + 12, z + 21, Block15, 0, 3);
		world.setBlock(x + 4, y + 12, z + 22, Block15, 0, 3);
		world.setBlock(x + 5, y + 12, z + 22, Block7, 0, 3);
		world.setBlock(x + 11, y + 12, z + 22, Block7, 0, 3);
		world.setBlock(x + 12, y + 12, z + 22, Block15, 0, 3);
		world.setBlock(x + 3, y + 12, z + 23, Block15, 0, 3);
		world.setBlock(x + 4, y + 12, z + 23, Block7, 0, 3);
		world.setBlock(x + 12, y + 12, z + 23, Block7, 0, 3);
		world.setBlock(x + 13, y + 12, z + 23, Block15, 0, 3);
		world.setBlock(x + 3, y + 12, z + 24, Block15, 0, 3);
		world.setBlock(x + 4, y + 12, z + 24, Block7, 0, 3);
		world.setBlock(x + 12, y + 12, z + 24, Block7, 0, 3);
		world.setBlock(x + 13, y + 12, z + 24, Block15, 0, 3);
		world.setBlock(x + 3, y + 12, z + 25, Block15, 0, 3);
		world.setBlock(x + 4, y + 12, z + 25, Block7, 0, 3);
		world.setBlock(x + 12, y + 12, z + 25, Block7, 0, 3);
		world.setBlock(x + 13, y + 12, z + 25, Block15, 0, 3);
		world.setBlock(x + 3, y + 12, z + 26, Block15, 0, 3);
		world.setBlock(x + 4, y + 12, z + 26, Block7, 0, 3);
		world.setBlock(x + 12, y + 12, z + 26, Block7, 0, 3);
		world.setBlock(x + 13, y + 12, z + 26, Block15, 0, 3);
		world.setBlock(x + 3, y + 12, z + 27, Block15, 0, 3);
		world.setBlock(x + 4, y + 12, z + 27, Block7, 0, 3);
		world.setBlock(x + 12, y + 12, z + 27, Block7, 0, 3);
		world.setBlock(x + 13, y + 12, z + 27, Block15, 0, 3);
		world.setBlock(x + 4, y + 12, z + 28, Block15, 0, 3);
		world.setBlock(x + 5, y + 12, z + 28, Block7, 0, 3);
		world.setBlock(x + 11, y + 12, z + 28, Block7, 0, 3);
		world.setBlock(x + 12, y + 12, z + 28, Block15, 0, 3);
		world.setBlock(x + 5, y + 12, z + 29, Block15, 0, 3);
		world.setBlock(x + 6, y + 12, z + 29, Block7, 0, 3);
		world.setBlock(x + 7, y + 12, z + 29, Block7, 0, 3);
		world.setBlock(x + 8, y + 12, z + 29, Block7, 0, 3);
		world.setBlock(x + 9, y + 12, z + 29, Block7, 0, 3);
		world.setBlock(x + 10, y + 12, z + 29, Block7, 0, 3);
		world.setBlock(x + 11, y + 12, z + 29, Block15, 0, 3);
		world.setBlock(x + 6, y + 12, z + 30, Block15, 0, 3);
		world.setBlock(x + 7, y + 12, z + 30, Block15, 0, 3);
		world.setBlock(x + 8, y + 12, z + 30, Block15, 0, 3);
		world.setBlock(x + 9, y + 12, z + 30, Block15, 0, 3);
		world.setBlock(x + 10, y + 12, z + 30, Block15, 0, 3);
		world.setBlock(x + 23, y + 13, z + 15, Block13, 5, 3);
		world.setBlock(x + 28, y + 13, z + 15, Block13, 5, 3);
		world.setBlock(x + 23, y + 14, z + 15, Block8, 3, 3);
		world.setBlock(x + 23, y + 15, z + 15, Block13, 3, 3);
		world.setBlock(x + 23, y + 16, z + 15, Block8, 3, 3);
		world.setBlock(x + 23, y + 17, z + 15, Block8, 3, 3);
		world.setBlock(x + 23, y + 18, z + 15, Block8, 3, 3);
		world.setBlock(x + 23, y + 19, z + 15, Block27, 3, 3);

		generate_r02_last(world, rand, x, y, z);
		return true;

	}
	public boolean generate_r02_last(World world, Random rand, int x, int y, int z)
	{

		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 1, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.LADDER.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + 1, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WALL_SIGN.getStateFromMeta(5), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + 1, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WALL_SIGN.getStateFromMeta(5), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 1, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.LEVER.getStateFromMeta(14), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 1, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.LEVER.getStateFromMeta(6), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 2, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.LADDER.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 3, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.LADDER.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 4, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WALL_SIGN.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 5, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WALL_SIGN.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 5, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.LEVER.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 8, z + 21); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WALL_SIGN.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 9, z + 21); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WALL_SIGN.getStateFromMeta(2), 3); }
		if(GeneralConfig.enableDebugMode)
			System.out.print("[Debug] Successfully spawned abandoned Power Plant at " + x + " " + y +" " + z + "\n");
		return true;

	}

}