package com.hbm.render.block;

import org.lwjgl.opengl.GL11;

import com.hbm.blocks.generic.BlockDecoCRT;
import com.hbm.main.ResourceManager;
import com.hbm.render.loader.HFRWavefrontObject;
import com.hbm.render.util.ObjUtil;

import cpw.mods.fml.client.registry.ISimpleBlockRenderingHandler;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.RenderBlocks;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.util.IIcon;
import net.minecraft.world.IBlockAccess;

public class RenderCRT implements ISimpleBlockRenderingHandler {

	@Override
	public void renderInventoryBlock(Block block, int metadata, int modelId, RenderBlocks renderer) {

		GL11.glPushMatrix();
		Tessellator tessellator = Tessellator.instance;
		IIcon iicon = block.getIcon(0, metadata * 4);
		tessellator.setColorOpaque_F(1, 1, 1);

		if(renderer.hasOverrideBlockTexture()) {
			iicon = renderer.overrideBlockTexture;
		}

		GL11.glTranslated(0, -0.5, 0);
		tessellator.startDrawingQuads();
		ObjUtil.renderWithIcon((HFRWavefrontObject) ResourceManager.crt, iicon, tessellator, (float) Math.PI * -0.5F, false);
		tessellator.draw();

		GL11.glPopMatrix();
	}

	@Override
	public boolean renderWorldBlock(IBlockAccess world, int x, int y, int z, Block block, int modelId, RenderBlocks renderer) {

		Tessellator tessellator = Tessellator.instance;
		IIcon iicon = block.getIcon(0, world.getBlockMetadata(x, y, z));

		int brightness = block.getMixedBrightnessForBlock(world, x, y, z);
		tessellator.setBrightness(brightness);
		tessellator.setColorOpaque_F(1, 1, 1);

		if(renderer.hasOverrideBlockTexture()) {
			iicon = renderer.overrideBlockTexture;
		}
		
		float rotation = 0;
		int metaOrig = world.getBlockMetadata(x, y, z);
		int meta = metaOrig % 4;
		
		switch(meta) {
		default: rotation = 0.5F * (float) Math.PI; break;
		case 1: break;
		case 2: rotation = 1.5F * (float) Math.PI; break;
		case 3: rotation = (float) Math.PI; break;
		}

		tessellator.addTranslation(x + 0.5F, y, z + 0.5F);
		ObjUtil.renderPartWithIcon((HFRWavefrontObject) ResourceManager.crt, "Monitor", iicon, tessellator, rotation, true);
		if(metaOrig >= 8) tessellator.setBrightness(240);
		ObjUtil.renderPartWithIcon((HFRWavefrontObject) ResourceManager.crt, "Screen", iicon, tessellator, rotation, true);
		tessellator.setBrightness(brightness);
		tessellator.addTranslation(-x - 0.5F, -y, -z - 0.5F);

		return true;
	}

	@Override
	public boolean shouldRender3DInInventory(int modelId) {
		return true;
	}

	@Override
	public int getRenderId() {
		return BlockDecoCRT.renderID;
	}
}
