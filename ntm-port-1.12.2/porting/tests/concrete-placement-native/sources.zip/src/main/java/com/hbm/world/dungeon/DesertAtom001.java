//Schematic to java Structure by jajo_11 | inspired by "MITHION'S .SCHEMATIC TO JAVA CONVERTINGTOOL"

package com.hbm.world.dungeon;

import java.util.Random;

import com.hbm.blocks.ModBlocks;
import com.hbm.itempool.ItemPool;
import com.hbm.itempool.ItemPoolsLegacy;
import com.hbm.lib.Library;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntityChest;
import com.hbm.lib.WeightedRandomChestContent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;

public class DesertAtom001 extends WorldGenerator
{
	Block Block2 = ModBlocks.yellow_barrel;
	Block Block3 = ModBlocks.reinforced_sand;
	Block Block4 = ModBlocks.crashed_balefire;
	Block Block7 = ModBlocks.deco_tungsten;
	
	protected Block[] GetValidSpawnBlocks()
	{
		return new Block[]
		{
			Blocks.GRASS,
			Blocks.DIRT,
			Blocks.SAND,
			Blocks.SANDSTONE,
			Blocks.STONE,
			Blocks.HARDENED_CLAY,
			Blocks.STAINED_HARDENED_CLAY,
		};
	}

	public boolean LocationIsValidSpawn(World world, int x, int y, int z)
 {

		Block checkBlock = (world.isValid(new BlockPos(x, y - 1, z)) ? world.getBlockState(new BlockPos(x, y - 1, z)).getBlock() : Blocks.AIR);
		Block blockAbove = (world.isValid(new BlockPos(x, y, z)) ? world.getBlockState(new BlockPos(x, y, z)).getBlock() : Blocks.AIR);
		Block blockBelow = (world.isValid(new BlockPos(x, y - 2, z)) ? world.getBlockState(new BlockPos(x, y - 2, z)).getBlock() : Blocks.AIR);

		for (Block i : GetValidSpawnBlocks())
		{
			if (blockAbove != Blocks.AIR)
			{
				return false;
			}
			if (checkBlock == i)
			{
				return true;
			}
			else if (checkBlock == Blocks.SNOW_LAYER && blockBelow == i)
			{
				return true;
			}
			else if (checkBlock.getMaterial() == Material.plants && blockBelow == i)
			{
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean generate(World world, Random rand, int x, int y, int z)
	{
		int i = rand.nextInt(1);

		if(i == 0)
		{
		    generate_r0(world, rand, x, y, z);
		}

       return true;

	}

	public boolean generate_r0(World world, Random rand, int x, int y, int z)
	{
		if(!LocationIsValidSpawn(world, x + 20, y, z + 16))
		{
			return false;
		}

		world.setBlock(x + 6, y + -5, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -5, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -5, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -5, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 10, y + -5, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -5, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -5, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -5, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -5, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -5, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 10, y + -5, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 11, y + -5, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -5, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -5, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -5, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -5, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -5, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 10, y + -5, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 11, y + -5, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -5, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -5, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -5, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -5, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -5, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 10, y + -5, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 11, y + -5, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -5, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -5, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -5, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -5, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -5, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 10, y + -5, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 11, y + -5, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -5, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -5, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -5, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -5, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -5, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 10, y + -5, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 11, y + -5, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -5, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -5, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -5, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -5, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 10, y + -5, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -5, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -5, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -5, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -5, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -5, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -5, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -5, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -5, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -5, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -5, z + 19, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -5, z + 19, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -5, z + 19, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -5, z + 20, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -5, z + 20, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -5, z + 20, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -5, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -5, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -5, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -4, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -4, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -4, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -4, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 10, y + -4, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -4, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -4, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -4, z + 10, Block2, 0, 3);
		world.setBlock(x + 8, y + -4, z + 10, Block2, 0, 3);
		world.setBlock(x + 9, y + -4, z + 10, Block2, 0, 3);
		world.setBlock(x + 10, y + -4, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 11, y + -4, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -4, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -4, z + 11, Block2, 0, 3);
		world.setBlock(x + 7, y + -4, z + 11, Block2, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -4, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -4, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 10, y + -4, z + 11, Block2, 0, 3);
		world.setBlock(x + 11, y + -4, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -4, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -4, z + 12, Block2, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -4, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -4, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -4, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -4, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + -4, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -4, z + 13, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -4, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -4, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -4, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -4, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -4, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + -4, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -4, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -4, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -4, z + 14, Block2, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -4, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -4, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.CHEST.getStateFromMeta(2), 3); }
		if((world.isValid(new BlockPos(x + 9, y + -4, z + 14)) ? world.getBlockState(new BlockPos(x + 9, y + -4, z + 14)).getBlock() : Blocks.AIR) == Blocks.CHEST)
		{
			WeightedRandomChestContent.generateChestContents(rand, ItemPool.getPool(ItemPoolsLegacy.POOL_NUKE_MISC), (TileEntityChest)world.getTileEntity(new BlockPos(x + 9, y + -4, z + 14)), 10);
		}
        world.setBlock(x + 10, y + -4, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 11, y + -4, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -4, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -4, z + 15, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -4, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(8), 3); }
		world.setBlock(x + 9, y + -4, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 10, y + -4, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -4, z + 16, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -4, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(8), 3); }
		world.setBlock(x + 9, y + -4, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -4, z + 17, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -4, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(8), 3); }
		world.setBlock(x + 9, y + -4, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -4, z + 18, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -4, z + 18); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(8), 3); }
		world.setBlock(x + 9, y + -4, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -4, z + 19, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -4, z + 19); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(8), 3); }
		world.setBlock(x + 9, y + -4, z + 19, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -4, z + 20, Block3, 0, 3);
		world.setBlock(x + 7, y + -4, z + 20, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -4, z + 20); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 9, y + -4, z + 20, Block3, 0, 3);
		world.setBlock(x + 10, y + -4, z + 20, Block3, 0, 3);
		world.setBlock(x + 4, y + -4, z + 21, Block3, 0, 3);
		world.setBlock(x + 5, y + -4, z + 21, Block3, 0, 3);
		world.setBlock(x + 6, y + -4, z + 21, Block3, 0, 3);
		world.setBlock(x + 7, y + -4, z + 21, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -4, z + 21); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(8), 3); }
		world.setBlock(x + 9, y + -4, z + 21, Block3, 0, 3);
		world.setBlock(x + 10, y + -4, z + 21, Block3, 0, 3);
		world.setBlock(x + 11, y + -4, z + 21, Block3, 0, 3);
		world.setBlock(x + 12, y + -4, z + 21, Block3, 0, 3);
		world.setBlock(x + 4, y + -4, z + 22, Block3, 0, 3);
		world.setBlock(x + 5, y + -4, z + 22, Block3, 0, 3);
		world.setBlock(x + 6, y + -4, z + 22, Block3, 0, 3);
		world.setBlock(x + 7, y + -4, z + 22, Block3, 0, 3);
		world.setBlock(x + 8, y + -4, z + 22, Block3, 0, 3);
		world.setBlock(x + 9, y + -4, z + 22, Block3, 0, 3);
		world.setBlock(x + 10, y + -4, z + 22, Block3, 0, 3);
		world.setBlock(x + 11, y + -4, z + 22, Block3, 0, 3);
		world.setBlock(x + 12, y + -4, z + 22, Block3, 0, 3);
		world.setBlock(x + 3, y + -4, z + 23, Block3, 0, 3);
		world.setBlock(x + 4, y + -4, z + 23, Block3, 0, 3);
		world.setBlock(x + 5, y + -4, z + 23, Block3, 0, 3);
		world.setBlock(x + 6, y + -4, z + 23, Block3, 0, 3);
		world.setBlock(x + 7, y + -4, z + 23, Block3, 0, 3);
		world.setBlock(x + 8, y + -4, z + 23, Block3, 0, 3);
		world.setBlock(x + 9, y + -4, z + 23, Block3, 0, 3);
		world.setBlock(x + 10, y + -4, z + 23, Block3, 0, 3);
		world.setBlock(x + 11, y + -4, z + 23, Block3, 0, 3);
		world.setBlock(x + 12, y + -4, z + 23, Block3, 0, 3);
		world.setBlock(x + 13, y + -4, z + 23, Block3, 0, 3);
		world.setBlock(x + 3, y + -4, z + 24, Block3, 0, 3);
		world.setBlock(x + 4, y + -4, z + 24, Block3, 0, 3);
		world.setBlock(x + 5, y + -4, z + 24, Block3, 0, 3);
		world.setBlock(x + 6, y + -4, z + 24, Block3, 0, 3);
		world.setBlock(x + 7, y + -4, z + 24, Block3, 0, 3);
		world.setBlock(x + 8, y + -4, z + 24, Block3, 0, 3);
		world.setBlock(x + 9, y + -4, z + 24, Block3, 0, 3);
		world.setBlock(x + 10, y + -4, z + 24, Block3, 0, 3);
		world.setBlock(x + 11, y + -4, z + 24, Block3, 0, 3);
		world.setBlock(x + 12, y + -4, z + 24, Block3, 0, 3);
		world.setBlock(x + 13, y + -4, z + 24, Block3, 0, 3);
		world.setBlock(x + 3, y + -4, z + 25, Block3, 0, 3);
		world.setBlock(x + 4, y + -4, z + 25, Block3, 0, 3);
		world.setBlock(x + 5, y + -4, z + 25, Block3, 0, 3);
		world.setBlock(x + 6, y + -4, z + 25, Block3, 0, 3);
		world.setBlock(x + 7, y + -4, z + 25, Block3, 0, 3);
		world.setBlock(x + 8, y + -4, z + 25, Block3, 0, 3);
		world.setBlock(x + 9, y + -4, z + 25, Block3, 0, 3);
		world.setBlock(x + 10, y + -4, z + 25, Block3, 0, 3);
		world.setBlock(x + 11, y + -4, z + 25, Block3, 0, 3);
		world.setBlock(x + 12, y + -4, z + 25, Block3, 0, 3);
		world.setBlock(x + 13, y + -4, z + 25, Block3, 0, 3);
		world.setBlock(x + 3, y + -4, z + 26, Block3, 0, 3);
		world.setBlock(x + 4, y + -4, z + 26, Block3, 0, 3);
		world.setBlock(x + 5, y + -4, z + 26, Block3, 0, 3);
		world.setBlock(x + 6, y + -4, z + 26, Block3, 0, 3);
		world.setBlock(x + 7, y + -4, z + 26, Block3, 0, 3);
		world.setBlock(x + 8, y + -4, z + 26, Block3, 0, 3);
		world.setBlock(x + 9, y + -4, z + 26, Block3, 0, 3);
		world.setBlock(x + 10, y + -4, z + 26, Block3, 0, 3);
		world.setBlock(x + 11, y + -4, z + 26, Block3, 0, 3);
		world.setBlock(x + 12, y + -4, z + 26, Block3, 0, 3);
		world.setBlock(x + 13, y + -4, z + 26, Block3, 0, 3);
		world.setBlock(x + 3, y + -4, z + 27, Block3, 0, 3);
		world.setBlock(x + 4, y + -4, z + 27, Block3, 0, 3);
		world.setBlock(x + 5, y + -4, z + 27, Block3, 0, 3);
		world.setBlock(x + 6, y + -4, z + 27, Block3, 0, 3);
		world.setBlock(x + 7, y + -4, z + 27, Block3, 0, 3);
		world.setBlock(x + 8, y + -4, z + 27, Block3, 0, 3);
		world.setBlock(x + 9, y + -4, z + 27, Block3, 0, 3);
		world.setBlock(x + 10, y + -4, z + 27, Block3, 0, 3);
		world.setBlock(x + 11, y + -4, z + 27, Block3, 0, 3);
		world.setBlock(x + 12, y + -4, z + 27, Block3, 0, 3);
		world.setBlock(x + 13, y + -4, z + 27, Block3, 0, 3);
		world.setBlock(x + 4, y + -4, z + 28, Block3, 0, 3);
		world.setBlock(x + 5, y + -4, z + 28, Block3, 0, 3);
		world.setBlock(x + 6, y + -4, z + 28, Block3, 0, 3);
		world.setBlock(x + 7, y + -4, z + 28, Block3, 0, 3);
		world.setBlock(x + 8, y + -4, z + 28, Block3, 0, 3);
		world.setBlock(x + 9, y + -4, z + 28, Block3, 0, 3);
		world.setBlock(x + 10, y + -4, z + 28, Block3, 0, 3);
		world.setBlock(x + 11, y + -4, z + 28, Block3, 0, 3);
		world.setBlock(x + 12, y + -4, z + 28, Block3, 0, 3);
		world.setBlock(x + 4, y + -4, z + 29, Block3, 0, 3);
		world.setBlock(x + 5, y + -4, z + 29, Block3, 0, 3);
		world.setBlock(x + 6, y + -4, z + 29, Block3, 0, 3);
		world.setBlock(x + 7, y + -4, z + 29, Block3, 0, 3);
		world.setBlock(x + 8, y + -4, z + 29, Block3, 0, 3);
		world.setBlock(x + 9, y + -4, z + 29, Block3, 0, 3);
		world.setBlock(x + 10, y + -4, z + 29, Block3, 0, 3);
		world.setBlock(x + 11, y + -4, z + 29, Block3, 0, 3);
		world.setBlock(x + 12, y + -4, z + 29, Block3, 0, 3);
		world.setBlock(x + 6, y + -4, z + 30, Block3, 0, 3);
		world.setBlock(x + 7, y + -4, z + 30, Block3, 0, 3);
		world.setBlock(x + 8, y + -4, z + 30, Block3, 0, 3);
		world.setBlock(x + 9, y + -4, z + 30, Block3, 0, 3);
		world.setBlock(x + 10, y + -4, z + 30, Block3, 0, 3);
		world.setBlock(x + 6, y + -3, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -3, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -3, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -3, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 10, y + -3, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -3, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -3, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -3, z + 10, Block2, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -3, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 10, y + -3, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 11, y + -3, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -3, z + 11, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -3, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -3, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -3, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -3, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + -3, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -3, z + 12, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -3, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -3, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -3, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -3, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + -3, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -3, z + 13, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -3, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -3, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -3, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -3, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + -3, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -3, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -3, z + 14, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -3, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -3, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 10, y + -3, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 11, y + -3, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -3, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -3, z + 15, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 9, y + -3, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 10, y + -3, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -3, z + 16, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 9, y + -3, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -3, z + 17, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 9, y + -3, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -3, z + 18, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 18); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 9, y + -3, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -3, z + 19, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 19); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 9, y + -3, z + 19, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -3, z + 20, Block3, 0, 3);
		world.setBlock(x + 7, y + -3, z + 20, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 20); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 9, y + -3, z + 20, Block3, 0, 3);
		world.setBlock(x + 10, y + -3, z + 20, Block3, 0, 3);
		world.setBlock(x + 4, y + -3, z + 21, Block3, 0, 3);
		world.setBlock(x + 5, y + -3, z + 21, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -3, z + 21); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -3, z + 21); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 21); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -3, z + 21); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -3, z + 21); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + -3, z + 21, Block3, 0, 3);
		world.setBlock(x + 12, y + -3, z + 21, Block3, 0, 3);
		world.setBlock(x + 4, y + -3, z + 22, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -3, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -3, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -3, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -3, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -3, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -3, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + -3, z + 22, Block3, 0, 3);
		world.setBlock(x + 3, y + -3, z + 23, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + -3, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -3, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -3, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -3, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -3, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -3, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -3, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + -3, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 13, y + -3, z + 23, Block3, 0, 3);
		world.setBlock(x + 3, y + -3, z + 24, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + -3, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -3, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -3, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -3, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -3, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -3, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -3, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + -3, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 13, y + -3, z + 24, Block3, 0, 3);
		world.setBlock(x + 3, y + -3, z + 25, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + -3, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -3, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -3, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -3, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 8, y + -3, z + 25, Block4, 2, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -3, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -3, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -3, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + -3, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 13, y + -3, z + 25, Block3, 0, 3);
		world.setBlock(x + 3, y + -3, z + 26, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + -3, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -3, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -3, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -3, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -3, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -3, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -3, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + -3, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 13, y + -3, z + 26, Block3, 0, 3);
		world.setBlock(x + 3, y + -3, z + 27, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + -3, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -3, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -3, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -3, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -3, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -3, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -3, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + -3, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 13, y + -3, z + 27, Block3, 0, 3);
		world.setBlock(x + 4, y + -3, z + 28, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -3, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -3, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -3, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -3, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -3, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -3, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + -3, z + 28, Block3, 0, 3);
		world.setBlock(x + 4, y + -3, z + 29, Block3, 0, 3);
		world.setBlock(x + 5, y + -3, z + 29, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -3, z + 29); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -3, z + 29); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -3, z + 29); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -3, z + 29); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -3, z + 29); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + -3, z + 29, Block3, 0, 3);
		world.setBlock(x + 12, y + -3, z + 29, Block3, 0, 3);
		world.setBlock(x + 6, y + -3, z + 30, Block3, 0, 3);
		world.setBlock(x + 7, y + -3, z + 30, Block3, 0, 3);
		world.setBlock(x + 8, y + -3, z + 30, Block3, 0, 3);
		world.setBlock(x + 9, y + -3, z + 30, Block3, 0, 3);
		world.setBlock(x + 10, y + -3, z + 30, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 1, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 2, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 3, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 4, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 5, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 6, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 7, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 8, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 9, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 10, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 11, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 12, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 13, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 14, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 15, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 16, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 17, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 18, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 19, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 20, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 21, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 22, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 23, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 24, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 25, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 26, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 27, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 28, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 29, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 30, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 31, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 32, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 33, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 34, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 35, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 36, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 37, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 38, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 0, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 1, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 1, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 2, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 2, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 8, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 9, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 10, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 11, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 12, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 13, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 14, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 15, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 16, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 17, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 18, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 19, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 20, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 21, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 22, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 23, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 24, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 25, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 26, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 27, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 28, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 29, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 30, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 31, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 32, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 33, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 34, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 35, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 36, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 37, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 38, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 3, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 8, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 9, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 10, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 11, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 12, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 13, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 14, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 15, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 16, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 17, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 18, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 19, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 20, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 21, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 22, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 23, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 24, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 25, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 26, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 27, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 28, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 29, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 30, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 31, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 32, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 33, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 34, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 35, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 36, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 37, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 38, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 4, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 5, Block3, 0, 3);
		world.setBlock(x + 8, y + -2, z + 5, Block3, 0, 3);
		world.setBlock(x + 38, y + -2, z + 5, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 5, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 5, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 6, Block3, 0, 3);
		world.setBlock(x + 38, y + -2, z + 6, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 6, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 6, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 7, Block3, 0, 3);
		world.setBlock(x + 38, y + -2, z + 7, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 7, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 7, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 8, Block3, 0, 3);
		world.setBlock(x + 6, y + -2, z + 8, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -2, z + 8, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -2, z + 8, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -2, z + 8, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 10, y + -2, z + 8, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 38, y + -2, z + 8, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 8, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 8, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 9, Block3, 0, 3);
		world.setBlock(x + 5, y + -2, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -2, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -2, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -2, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -2, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 10, y + -2, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 11, y + -2, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 38, y + -2, z + 9, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 9, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 9, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 10, Block3, 0, 3);
		world.setBlock(x + 4, y + -2, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -2, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -2, z + 10, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 10, y + -2, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 11, y + -2, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 12, y + -2, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 38, y + -2, z + 10, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 10, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 10, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 11, Block3, 0, 3);
		world.setBlock(x + 4, y + -2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -2, z + 11, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -2, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -2, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -2, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -2, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -2, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + -2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 12, y + -2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 38, y + -2, z + 11, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 11, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 11, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 12, Block3, 0, 3);
		world.setBlock(x + 4, y + -2, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -2, z + 12, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + -2, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 12, y + -2, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 38, y + -2, z + 12, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 12, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 12, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 13, Block3, 0, 3);
		world.setBlock(x + 4, y + -2, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -2, z + 13, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -2, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -2, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -2, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -2, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -2, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + -2, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 12, y + -2, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 38, y + -2, z + 13, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 13, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 13, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 14, Block3, 0, 3);
		world.setBlock(x + 4, y + -2, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 5, y + -2, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -2, z + 14, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -2, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -2, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -2, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 10, y + -2, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 11, y + -2, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 12, y + -2, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 38, y + -2, z + 14, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 14, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 14, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 15, Block3, 0, 3);
		world.setBlock(x + 5, y + -2, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 6, y + -2, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -2, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -2, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -2, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 10, y + -2, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 11, y + -2, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 38, y + -2, z + 15, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 15, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 15, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 16, Block3, 0, 3);
		world.setBlock(x + 6, y + -2, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 7, y + -2, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -2, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -2, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 10, y + -2, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 38, y + -2, z + 16, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 16, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 16, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 17, Block3, 0, 3);
		world.setBlock(x + 7, y + -2, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -2, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -2, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 38, y + -2, z + 17, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 17, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 17, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 18, Block3, 0, 3);
		world.setBlock(x + 7, y + -2, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -2, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -2, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 38, y + -2, z + 18, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 18, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 18, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 19, Block3, 0, 3);
		world.setBlock(x + 7, y + -2, z + 19, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 8, y + -2, z + 19, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 9, y + -2, z + 19, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 38, y + -2, z + 19, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 19, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 19, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 20, Block3, 0, 3);
		world.setBlock(x + 6, y + -2, z + 20, Block3, 0, 3);
		world.setBlock(x + 7, y + -2, z + 20, Block3, 0, 3);
		world.setBlock(x + 8, y + -2, z + 20, Block3, 0, 3);
		world.setBlock(x + 9, y + -2, z + 20, Block3, 0, 3);
		world.setBlock(x + 10, y + -2, z + 20, Block3, 0, 3);
		world.setBlock(x + 38, y + -2, z + 20, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 20, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 20, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 4, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 5, y + -2, z + 21, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -2, z + 21); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -2, z + 21); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -2, z + 21); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -2, z + 21); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -2, z + 21); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 12, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 16, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 17, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 18, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 19, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 20, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 21, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 22, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 23, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 24, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 25, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 26, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 27, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 28, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 29, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 30, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 31, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 32, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 33, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 34, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 35, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 36, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 37, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 38, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 21, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 4, y + -2, z + 22, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -2, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -2, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -2, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -2, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -2, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -2, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -2, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 16, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 17, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 18, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 19, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 20, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 21, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 22, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 23, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 24, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 25, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 26, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 27, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 28, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 29, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 30, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 31, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 32, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 33, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 34, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 35, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 36, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 37, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 38, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 22, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 3, y + -2, z + 23, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + -2, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -2, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -2, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -2, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -2, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -2, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -2, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -2, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + -2, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 13, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 16, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 17, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 18, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 19, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 20, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 21, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 22, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 23, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 24, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 25, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 26, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 27, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 28, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 29, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 30, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 31, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 32, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 33, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 34, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 35, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 36, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 37, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 38, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 23, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 3, y + -2, z + 24, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + -2, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -2, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -2, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -2, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -2, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -2, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -2, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -2, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + -2, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 13, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 16, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 17, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 18, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 19, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 20, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 21, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 22, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 23, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 24, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 25, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 26, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 27, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 28, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 29, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 30, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 31, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 32, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 33, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 34, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 35, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 36, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 37, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 38, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 24, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 3, y + -2, z + 25, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + -2, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -2, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -2, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -2, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -2, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -2, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -2, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -2, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + -2, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 13, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 16, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 17, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 18, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 19, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 20, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 21, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 22, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 23, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 24, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 25, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 26, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 27, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 28, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 29, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 30, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 31, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 32, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 33, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 34, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 35, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 36, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 37, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 38, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 25, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 3, y + -2, z + 26, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + -2, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -2, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -2, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -2, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -2, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -2, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -2, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -2, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + -2, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 13, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 16, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 17, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 18, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 19, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 20, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 21, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 22, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 23, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 24, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 25, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 26, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 27, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 28, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 29, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 30, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 31, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 32, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 33, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 34, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 35, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 36, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 37, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 38, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 26, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 3, y + -2, z + 27, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + -2, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -2, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -2, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -2, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -2, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -2, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -2, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -2, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + -2, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 13, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 16, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 17, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 18, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 19, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 20, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 21, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 22, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 23, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 24, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 25, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 26, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 27, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 28, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 29, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 30, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 31, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 32, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 33, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 34, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 35, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 36, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 37, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 38, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 27, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 4, y + -2, z + 28, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -2, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -2, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -2, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -2, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -2, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -2, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -2, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 16, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 17, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 18, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 19, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 20, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 21, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 22, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 23, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 24, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 25, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 26, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 27, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 28, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 29, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 30, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 31, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 32, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 33, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 34, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 35, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 36, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 37, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 38, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 28, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 29, Block3, 0, 3);
		world.setBlock(x + 4, y + -2, z + 29, Block3, 0, 3);
		world.setBlock(x + 5, y + -2, z + 29, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -2, z + 29); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -2, z + 29); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -2, z + 29); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -2, z + 29); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -2, z + 29); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + -2, z + 29, Block3, 0, 3);
		world.setBlock(x + 12, y + -2, z + 29, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 29, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 30, Block3, 0, 3);
		world.setBlock(x + 6, y + -2, z + 30, Block3, 0, 3);
		world.setBlock(x + 7, y + -2, z + 30, Block3, 0, 3);
		world.setBlock(x + 8, y + -2, z + 30, Block3, 0, 3);
		world.setBlock(x + 9, y + -2, z + 30, Block3, 0, 3);
		world.setBlock(x + 10, y + -2, z + 30, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 30, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 16, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 17, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 18, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 19, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 20, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 21, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 22, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 23, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 24, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 25, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 26, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 27, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 28, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 29, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 30, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 31, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 32, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 33, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 34, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 35, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 36, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 37, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 38, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 39, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 40, y + -2, z + 31, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 32, Block3, 0, 3);
		world.setBlock(x + 16, y + -2, z + 32, Block3, 0, 3);
		world.setBlock(x + 0, y + -2, z + 33, Block3, 0, 3);
		world.setBlock(x + 1, y + -2, z + 33, Block3, 0, 3);
		world.setBlock(x + 2, y + -2, z + 33, Block3, 0, 3);
		world.setBlock(x + 3, y + -2, z + 33, Block3, 0, 3);
		world.setBlock(x + 4, y + -2, z + 33, Block3, 0, 3);
		world.setBlock(x + 5, y + -2, z + 33, Block3, 0, 3);
		world.setBlock(x + 6, y + -2, z + 33, Block3, 0, 3);
		world.setBlock(x + 7, y + -2, z + 33, Block3, 0, 3);
		world.setBlock(x + 8, y + -2, z + 33, Block3, 0, 3);
		world.setBlock(x + 9, y + -2, z + 33, Block3, 0, 3);
		world.setBlock(x + 10, y + -2, z + 33, Block3, 0, 3);
		world.setBlock(x + 11, y + -2, z + 33, Block3, 0, 3);
		world.setBlock(x + 12, y + -2, z + 33, Block3, 0, 3);
		world.setBlock(x + 13, y + -2, z + 33, Block3, 0, 3);
		world.setBlock(x + 14, y + -2, z + 33, Block3, 0, 3);
		world.setBlock(x + 15, y + -2, z + 33, Block3, 0, 3);
		world.setBlock(x + 16, y + -2, z + 33, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 1, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 2, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 3, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 4, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 5, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 6, y + -1, z + 0, Block3, 0, 3);

		new DesertAtom002().generate_r00(world, rand, x, y, z);
		return true;

	}
}