//Schematic to java Structure by jajo_11 | inspired by "MITHION'S.SCHEMATIC TO JAVA CONVERTINGTOOL"

package com.hbm.world.dungeon;

import java.util.Random;

import com.hbm.blocks.ModBlocks;
import com.hbm.itempool.ItemPool;
import com.hbm.itempool.ItemPoolsLegacy;
import com.hbm.lib.Library;
import com.hbm.tileentity.machine.storage.TileEntityCrateSteel;

import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemDoor;
import net.minecraft.tileentity.TileEntityChest;
import com.hbm.lib.WeightedRandomChestContent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class DesertAtom002
{
	Block Block2 = ModBlocks.yellow_barrel;
	Block Block3 = ModBlocks.reinforced_sand;
	Block Block5 = ModBlocks.deco_steel;
	Block Block6 = ModBlocks.brick_light;
	Block Block7 = ModBlocks.deco_tungsten;
	Block Block8 = ModBlocks.steel_poles;
	Block Block9 = ModBlocks.tape_recorder;
	Block Block10 = ModBlocks.machine_rtg_furnace_off;
	Block Block11 = ModBlocks.reinforced_glass;
	Block Block12 = ModBlocks.reinforced_lamp_off;
	Block Block13 = ModBlocks.pole_satellite_receiver;
	Block Block14 = ModBlocks.pwr_fuel;
	Block Block15 = ModBlocks.deco_titanium;
	Block Block16 = ModBlocks.block_lead;
	Block Block17 = ModBlocks.ore_nether_plutonium;
	
	public boolean generate_r00(World world, Random rand, int x, int y, int z)
    {
		world.setBlock(x + 7, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 8, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 9, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 10, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 11, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 12, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 13, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 14, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 15, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 16, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 17, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 18, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 19, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 20, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 21, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 22, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 23, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 24, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 25, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 26, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 27, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 28, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 29, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 30, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 31, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 32, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 33, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 34, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 35, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 36, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 37, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 38, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 39, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 40, y + -1, z + 0, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 1, Block3, 0, 3);
		world.setBlock(x + 40, y + -1, z + 1, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 2, Block3, 0, 3);
		world.setBlock(x + 40, y + -1, z + 2, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 3, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 13, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 14, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 15, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 16, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 19, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 23, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 25, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 26, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 28, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 30, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 32, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 33, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 34, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 37, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 3, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 4, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 13, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 14, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 15, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 16, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 19, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 23, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 25, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 26, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 28, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 30, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 32, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 33, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 34, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 37, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 4, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 5, Block3, 0, 3);
		world.setBlock(x + 5, y + -1, z + 5, Block5, 0, 3);
		world.setBlock(x + 6, y + -1, z + 5, Block5, 0, 3);
		world.setBlock(x + 7, y + -1, z + 5, Block5, 0, 3);
		world.setBlock(x + 8, y + -1, z + 5, Block5, 0, 3);
		world.setBlock(x + 9, y + -1, z + 5, Block5, 0, 3);
		world.setBlock(x + 10, y + -1, z + 5, Block5, 0, 3);
		world.setBlock(x + 11, y + -1, z + 5, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 5, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 6, Block3, 0, 3);
		world.setBlock(x + 5, y + -1, z + 6, Block5, 0, 3);
		world.setBlock(x + 6, y + -1, z + 6, Block5, 0, 3);
		world.setBlock(x + 7, y + -1, z + 6, Block5, 0, 3);
		world.setBlock(x + 8, y + -1, z + 6, Block5, 0, 3);
		world.setBlock(x + 9, y + -1, z + 6, Block5, 0, 3);
		world.setBlock(x + 10, y + -1, z + 6, Block5, 0, 3);
		world.setBlock(x + 11, y + -1, z + 6, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 21, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 22, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 26, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 27, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 28, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 29, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 33, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 34, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 35, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 36, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 37, y + -1, z + 6, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 40, y + -1, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 0, y + -1, z + 7, Block3, 0, 3);
		world.setBlock(x + 5, y + -1, z + 7, Block5, 0, 3);
		world.setBlock(x + 6, y + -1, z + 7, Block5, 0, 3);
		world.setBlock(x + 7, y + -1, z + 7, Block5, 0, 3);
		world.setBlock(x + 8, y + -1, z + 7, Block5, 0, 3);
		world.setBlock(x + 9, y + -1, z + 7, Block5, 0, 3);
		world.setBlock(x + 10, y + -1, z + 7, Block5, 0, 3);
		world.setBlock(x + 11, y + -1, z + 7, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 7, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 18, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 19, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 20, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 21, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 22, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 23, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 24, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 25, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 26, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 27, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 28, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 29, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 30, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 31, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 32, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 33, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 34, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 35, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 36, y + -1, z + 7, Block6, 0, 3);
		world.setBlock(x + 37, y + -1, z + 7, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 40, y + -1, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 0, y + -1, z + 8, Block3, 0, 3);
		world.setBlock(x + 5, y + -1, z + 8, Block5, 0, 3);
		world.setBlock(x + 6, y + -1, z + 8, Block5, 0, 3);
		world.setBlock(x + 7, y + -1, z + 8, Block5, 0, 3);
		world.setBlock(x + 8, y + -1, z + 8, Block5, 0, 3);
		world.setBlock(x + 9, y + -1, z + 8, Block5, 0, 3);
		world.setBlock(x + 10, y + -1, z + 8, Block5, 0, 3);
		world.setBlock(x + 11, y + -1, z + 8, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 8, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 18, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 19, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 20, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 21, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 22, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 23, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 24, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 25, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 26, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 27, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 28, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 29, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 30, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 31, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 32, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 33, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 34, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 35, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 36, y + -1, z + 8, Block6, 0, 3);
		world.setBlock(x + 37, y + -1, z + 8, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 40, y + -1, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 0, y + -1, z + 9, Block3, 0, 3);
		world.setBlock(x + 5, y + -1, z + 9, Block5, 0, 3);
		world.setBlock(x + 6, y + -1, z + 9, Block5, 0, 3);
		world.setBlock(x + 7, y + -1, z + 9, Block5, 0, 3);
		world.setBlock(x + 8, y + -1, z + 9, Block5, 0, 3);
		world.setBlock(x + 9, y + -1, z + 9, Block5, 0, 3);
		world.setBlock(x + 10, y + -1, z + 9, Block5, 0, 3);
		world.setBlock(x + 11, y + -1, z + 9, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 18, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 19, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 20, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 21, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 22, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 23, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 24, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 25, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 26, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 27, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 28, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 29, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 30, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 31, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 32, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 33, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 34, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 35, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 36, y + -1, z + 9, Block6, 0, 3);
		world.setBlock(x + 37, y + -1, z + 9, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 40, y + -1, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 0, y + -1, z + 10, Block3, 0, 3);
		world.setBlock(x + 4, y + -1, z + 10, Block5, 0, 3);
		world.setBlock(x + 5, y + -1, z + 10, Block5, 0, 3);
		world.setBlock(x + 6, y + -1, z + 10, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 10, y + -1, z + 10, Block5, 0, 3);
		world.setBlock(x + 11, y + -1, z + 10, Block5, 0, 3);
		world.setBlock(x + 12, y + -1, z + 10, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 18, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 19, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 20, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 21, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 22, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 23, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 24, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 25, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 26, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 27, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 28, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 29, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 30, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 31, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 32, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 33, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 34, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 35, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 36, y + -1, z + 10, Block6, 0, 3);
		world.setBlock(x + 37, y + -1, z + 10, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 10, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 11, Block3, 0, 3);
		world.setBlock(x + 4, y + -1, z + 11, Block5, 0, 3);
		world.setBlock(x + 5, y + -1, z + 11, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -1, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -1, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -1, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -1, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -1, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + -1, z + 11, Block5, 0, 3);
		world.setBlock(x + 12, y + -1, z + 11, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 18, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 19, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 20, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 21, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 22, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 23, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 24, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 25, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 26, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 27, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 28, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 29, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 30, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 31, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 32, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 33, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 34, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 35, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 36, y + -1, z + 11, Block6, 0, 3);
		world.setBlock(x + 37, y + -1, z + 11, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 11, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 12, Block3, 0, 3);
		world.setBlock(x + 4, y + -1, z + 12, Block5, 0, 3);
		world.setBlock(x + 5, y + -1, z + 12, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + -1, z + 12, Block5, 0, 3);
		world.setBlock(x + 12, y + -1, z + 12, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 18, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 19, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 20, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 21, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 22, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 23, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 24, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 25, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 26, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 27, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 28, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 29, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 30, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 31, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 32, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 33, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 34, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 35, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 36, y + -1, z + 12, Block6, 0, 3);
		world.setBlock(x + 37, y + -1, z + 12, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 12, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 13, Block3, 0, 3);
		world.setBlock(x + 4, y + -1, z + 13, Block5, 0, 3);
		world.setBlock(x + 5, y + -1, z + 13, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + -1, z + 13, Block5, 0, 3);
		world.setBlock(x + 12, y + -1, z + 13, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 18, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 19, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 20, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 21, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 22, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 23, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 24, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 25, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 26, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 27, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 28, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 29, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 30, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 31, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 32, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 33, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 34, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 35, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 36, y + -1, z + 13, Block6, 0, 3);
		world.setBlock(x + 37, y + -1, z + 13, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 13, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 14, Block3, 0, 3);
		world.setBlock(x + 4, y + -1, z + 14, Block5, 0, 3);
		world.setBlock(x + 5, y + -1, z + 14, Block5, 0, 3);
		world.setBlock(x + 6, y + -1, z + 14, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -1, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -1, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -1, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 10, y + -1, z + 14, Block5, 0, 3);
		world.setBlock(x + 11, y + -1, z + 14, Block5, 0, 3);
		world.setBlock(x + 12, y + -1, z + 14, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 18, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 19, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 20, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 21, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 22, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 23, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 24, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 25, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 26, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 27, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 28, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 29, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 30, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 31, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 32, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 33, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 34, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 35, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 36, y + -1, z + 14, Block6, 0, 3);
		world.setBlock(x + 37, y + -1, z + 14, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 14, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 15, Block3, 0, 3);
		world.setBlock(x + 5, y + -1, z + 15, Block5, 0, 3);
		world.setBlock(x + 6, y + -1, z + 15, Block5, 0, 3);
		world.setBlock(x + 7, y + -1, z + 15, Block5, 0, 3);
		world.setBlock(x + 8, y + -1, z + 15, Block5, 0, 3);
		world.setBlock(x + 9, y + -1, z + 15, Block5, 0, 3);
		world.setBlock(x + 10, y + -1, z + 15, Block5, 0, 3);
		world.setBlock(x + 11, y + -1, z + 15, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 18, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 19, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 20, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 21, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 22, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 23, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 24, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 25, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 26, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 27, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 28, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 29, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 30, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 31, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 32, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 33, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 34, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 35, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 36, y + -1, z + 15, Block6, 0, 3);
		world.setBlock(x + 37, y + -1, z + 15, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 15, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 16, Block3, 0, 3);
		world.setBlock(x + 6, y + -1, z + 16, Block5, 0, 3);
		world.setBlock(x + 7, y + -1, z + 16, Block5, 0, 3);
		world.setBlock(x + 8, y + -1, z + 16, Block5, 0, 3);
		world.setBlock(x + 9, y + -1, z + 16, Block5, 0, 3);
		world.setBlock(x + 10, y + -1, z + 16, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 18, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 19, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 20, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 21, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 22, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 23, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 24, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 25, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 26, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 27, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 28, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 29, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 30, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 31, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 32, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 33, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 34, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 35, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 36, y + -1, z + 16, Block6, 0, 3);
		world.setBlock(x + 37, y + -1, z + 16, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 16, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 17, Block3, 0, 3);
		world.setBlock(x + 16, y + -1, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 18, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 19, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 20, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 21, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 22, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 23, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 24, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 25, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 26, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 27, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 28, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 29, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 30, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 31, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 32, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 33, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 34, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 35, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 36, y + -1, z + 17, Block6, 0, 3);
		world.setBlock(x + 37, y + -1, z + 17, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 17, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 18, Block3, 0, 3);
		world.setBlock(x + 16, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 21, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 22, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 26, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 27, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 28, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 29, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 33, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 34, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 35, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 36, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 37, y + -1, z + 18, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 18); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 18); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 18, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 19, Block3, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 19); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 19); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 19, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 20, Block3, 0, 3);
		world.setBlock(x + 6, y + -1, z + 20, Block5, 0, 3);
		world.setBlock(x + 7, y + -1, z + 20, Block5, 0, 3);
		world.setBlock(x + 8, y + -1, z + 20, Block5, 0, 3);
		world.setBlock(x + 9, y + -1, z + 20, Block5, 0, 3);
		world.setBlock(x + 10, y + -1, z + 20, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 20); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 20); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 20, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 21, Block3, 0, 3);
		world.setBlock(x + 4, y + -1, z + 21, Block5, 0, 3);
		world.setBlock(x + 5, y + -1, z + 21, Block5, 0, 3);
		world.setBlock(x + 6, y + -1, z + 21, Block5, 0, 3);
		world.setBlock(x + 7, y + -1, z + 21, Block5, 0, 3);
		world.setBlock(x + 8, y + -1, z + 21, Block5, 0, 3);
		world.setBlock(x + 9, y + -1, z + 21, Block5, 0, 3);
		world.setBlock(x + 10, y + -1, z + 21, Block5, 0, 3);
		world.setBlock(x + 11, y + -1, z + 21, Block5, 0, 3);
		world.setBlock(x + 12, y + -1, z + 21, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 21, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 22, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 26, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 27, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 28, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 29, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 33, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 34, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 35, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 36, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 37, y + -1, z + 21, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 21); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 21); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 21, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 22, Block3, 0, 3);
		world.setBlock(x + 4, y + -1, z + 22, Block5, 0, 3);
		world.setBlock(x + 5, y + -1, z + 22, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -1, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -1, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -1, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -1, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -1, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + -1, z + 22, Block5, 0, 3);
		world.setBlock(x + 12, y + -1, z + 22, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 21, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 22, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 26, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 27, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 28, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 29, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 33, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 34, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 35, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 36, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 37, y + -1, z + 22, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 22); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 22, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 23, Block3, 0, 3);
		world.setBlock(x + 3, y + -1, z + 23, Block5, 0, 3);
		world.setBlock(x + 4, y + -1, z + 23, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -1, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -1, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -1, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -1, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -1, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -1, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -1, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + -1, z + 23, Block5, 0, 3);
		world.setBlock(x + 13, y + -1, z + 23, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 21, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 22, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 26, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 27, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 28, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 29, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 33, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 34, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 35, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 36, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 37, y + -1, z + 23, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 23); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 23, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 24, Block3, 0, 3);
		world.setBlock(x + 3, y + -1, z + 24, Block5, 0, 3);
		world.setBlock(x + 4, y + -1, z + 24, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -1, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -1, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -1, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -1, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -1, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -1, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -1, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + -1, z + 24, Block5, 0, 3);
		world.setBlock(x + 13, y + -1, z + 24, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 21, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 22, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 26, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 27, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 28, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 29, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 33, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 34, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 35, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 36, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 37, y + -1, z + 24, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 24); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 24, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 25, Block3, 0, 3);
		world.setBlock(x + 3, y + -1, z + 25, Block5, 0, 3);
		world.setBlock(x + 4, y + -1, z + 25, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -1, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -1, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -1, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -1, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -1, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -1, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -1, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + -1, z + 25, Block5, 0, 3);
		world.setBlock(x + 13, y + -1, z + 25, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 21, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 22, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 26, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 27, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 28, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 29, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 33, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 34, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 35, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 36, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 37, y + -1, z + 25, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 25, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 26, Block3, 0, 3);
		world.setBlock(x + 3, y + -1, z + 26, Block5, 0, 3);
		world.setBlock(x + 4, y + -1, z + 26, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -1, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -1, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -1, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -1, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -1, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -1, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -1, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + -1, z + 26, Block5, 0, 3);
		world.setBlock(x + 13, y + -1, z + 26, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 21, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 22, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 26, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 27, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 28, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 29, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 33, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 34, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 35, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 36, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 37, y + -1, z + 26, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 26, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 27, Block3, 0, 3);
		world.setBlock(x + 3, y + -1, z + 27, Block5, 0, 3);
		world.setBlock(x + 4, y + -1, z + 27, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + -1, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -1, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -1, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -1, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -1, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -1, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + -1, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + -1, z + 27, Block5, 0, 3);
		world.setBlock(x + 13, y + -1, z + 27, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 21, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 22, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 26, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 27, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 28, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 29, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 33, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 34, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 35, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 36, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 37, y + -1, z + 27, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 27); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 27, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 28, Block3, 0, 3);
		world.setBlock(x + 4, y + -1, z + 28, Block5, 0, 3);
		world.setBlock(x + 5, y + -1, z + 28, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + -1, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + -1, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + -1, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + -1, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + -1, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + -1, z + 28, Block5, 0, 3);
		world.setBlock(x + 12, y + -1, z + 28, Block5, 0, 3);
		world.setBlock(x + 16, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 21, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 22, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 26, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 27, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 28, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 29, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 33, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 34, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 35, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 36, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 37, y + -1, z + 28, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 38, y + -1, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 39, y + -1, z + 28); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + -1, z + 28, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 29, Block3, 0, 3);
		world.setBlock(x + 4, y + -1, z + 29, Block5, 0, 3);
		world.setBlock(x + 5, y + -1, z + 29, Block5, 0, 3);
		world.setBlock(x + 6, y + -1, z + 29, Block5, 0, 3);
		world.setBlock(x + 7, y + -1, z + 29, Block5, 0, 3);
		world.setBlock(x + 8, y + -1, z + 29, Block5, 0, 3);
		world.setBlock(x + 9, y + -1, z + 29, Block5, 0, 3);
		world.setBlock(x + 10, y + -1, z + 29, Block5, 0, 3);
		world.setBlock(x + 11, y + -1, z + 29, Block5, 0, 3);
		world.setBlock(x + 12, y + -1, z + 29, Block5, 0, 3);
		world.setBlock(x + 40, y + -1, z + 29, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 30, Block3, 0, 3);
		world.setBlock(x + 6, y + -1, z + 30, Block5, 0, 3);
		world.setBlock(x + 7, y + -1, z + 30, Block5, 0, 3);
		world.setBlock(x + 8, y + -1, z + 30, Block5, 0, 3);
		world.setBlock(x + 9, y + -1, z + 30, Block5, 0, 3);
		world.setBlock(x + 10, y + -1, z + 30, Block5, 0, 3);
		world.setBlock(x + 40, y + -1, z + 30, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 16, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 17, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 18, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 19, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 20, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 21, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 22, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 23, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 24, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 25, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 26, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 27, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 28, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 29, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 30, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 31, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 32, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 33, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 34, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 35, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 36, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 37, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 38, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 39, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 40, y + -1, z + 31, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 32, Block3, 0, 3);
		world.setBlock(x + 16, y + -1, z + 32, Block3, 0, 3);
		world.setBlock(x + 0, y + -1, z + 33, Block3, 0, 3);
		world.setBlock(x + 1, y + -1, z + 33, Block3, 0, 3);
		world.setBlock(x + 2, y + -1, z + 33, Block3, 0, 3);
		world.setBlock(x + 3, y + -1, z + 33, Block3, 0, 3);
		world.setBlock(x + 4, y + -1, z + 33, Block3, 0, 3);
		world.setBlock(x + 5, y + -1, z + 33, Block3, 0, 3);
		world.setBlock(x + 6, y + -1, z + 33, Block3, 0, 3);
		world.setBlock(x + 7, y + -1, z + 33, Block3, 0, 3);
		world.setBlock(x + 8, y + -1, z + 33, Block3, 0, 3);
		world.setBlock(x + 9, y + -1, z + 33, Block3, 0, 3);
		world.setBlock(x + 10, y + -1, z + 33, Block3, 0, 3);
		world.setBlock(x + 11, y + -1, z + 33, Block3, 0, 3);
		world.setBlock(x + 12, y + -1, z + 33, Block3, 0, 3);
		world.setBlock(x + 13, y + -1, z + 33, Block3, 0, 3);
		world.setBlock(x + 14, y + -1, z + 33, Block3, 0, 3);
		world.setBlock(x + 15, y + -1, z + 33, Block3, 0, 3);
		world.setBlock(x + 16, y + -1, z + 33, Block3, 0, 3);
		world.setBlock(x + 0, y + 0, z + 0, Block5, 0, 3);
		world.setBlock(x + 1, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 2, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 5, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 7, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 8, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 9, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 10, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 11, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 12, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 13, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 14, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 15, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 17, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 18, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 19, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 20, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 21, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 22, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 23, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 24, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 25, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 26, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 27, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 28, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 29, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 30, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 31, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 32, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 33, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 34, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 35, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 36, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 37, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 38, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 39, y + 0, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 0, z + 0, Block5, 0, 3);
		world.setBlock(x + 0, y + 0, z + 1, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 0, z + 1, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 2, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 0, z + 2, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 3, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 0, z + 3, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 4, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 0, z + 4, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 5, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 0, z + 5, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 6, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 0, z + 6, Block5, 0, 3);
		world.setBlock(x + 7, y + 0, z + 6, Block5, 0, 3);
		world.setBlock(x + 8, y + 0, z + 6, Block5, 0, 3);
		world.setBlock(x + 9, y + 0, z + 6, Block5, 0, 3);
		world.setBlock(x + 10, y + 0, z + 6, Block5, 0, 3);
		world.setBlock(x + 16, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 21, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 22, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 26, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 27, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 28, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 29, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 33, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 34, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 35, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 36, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 37, y + 0, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 0, z + 6, Block5, 0, 3);
		world.setBlock(x + 0, y + 0, z + 7, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 0, z + 7, Block5, 0, 3);
		world.setBlock(x + 7, y + 0, z + 7, Block5, 0, 3);
		world.setBlock(x + 8, y + 0, z + 7, Block5, 0, 3);
		world.setBlock(x + 9, y + 0, z + 7, Block5, 0, 3);
		world.setBlock(x + 10, y + 0, z + 7, Block5, 0, 3);
		world.setBlock(x + 16, y + 0, z + 7, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 0, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + 0, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 19, y + 0, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 0, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + 0, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 0, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 0, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 0, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 32, y + 0, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 33, y + 0, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 37, y + 0, z + 7, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 40, y + 0, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		world.setBlock(x + 0, y + 0, z + 8, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 0, z + 8, Block5, 0, 3);
		world.setBlock(x + 7, y + 0, z + 8, Block5, 0, 3);
		world.setBlock(x + 8, y + 0, z + 8, Block5, 0, 3);
		world.setBlock(x + 9, y + 0, z + 8, Block5, 0, 3);
		world.setBlock(x + 10, y + 0, z + 8, Block5, 0, 3);
		world.setBlock(x + 16, y + 0, z + 8, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 0, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		//world.setBlock(x + 37, y + 0, z + 8, Blocks.iron_door, 2, 3);
        ItemDoor.placeDoorBlock(world, x + 37, y + 0, z + 8, 2, Blocks.IRON_DOOR);
		{ BlockPos dungeonPos = new BlockPos(x + 40, y + 0, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		world.setBlock(x + 0, y + 0, z + 9, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 5, y + 0, z + 9, Block5, 0, 3);
		world.setBlock(x + 6, y + 0, z + 9, Block2, 0, 3);
		world.setBlock(x + 7, y + 0, z + 9, Block2, 0, 3);
		world.setBlock(x + 8, y + 0, z + 9, Block2, 0, 3);
		world.setBlock(x + 9, y + 0, z + 9, Block2, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 0, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + 0, z + 9, Block5, 0, 3);
		world.setBlock(x + 16, y + 0, z + 9, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 0, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		//world.setBlock(x + 37, y + 0, z + 9, Blocks.iron_door, 2, 3);
        ItemDoor.placeDoorBlock(world, x + 37, y + 0, z + 9, 2, Blocks.IRON_DOOR);
		{ BlockPos dungeonPos = new BlockPos(x + 40, y + 0, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		world.setBlock(x + 0, y + 0, z + 10, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 0, z + 10, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 0, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 0, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 0, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 0, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 0, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 0, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 0, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 0, z + 10, Block5, 0, 3);
		world.setBlock(x + 16, y + 0, z + 10, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + 0, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 23, y + 0, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 0, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 0, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 28, y + 0, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 0, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 0, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 0, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		world.setBlock(x + 37, y + 0, z + 10, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 40, y + 0, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		world.setBlock(x + 0, y + 0, z + 11, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 0, z + 11, Block5, 0, 3);
		world.setBlock(x + 5, y + 0, z + 11, Block2, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 0, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 0, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 0, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 0, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 0, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + 0, z + 11, Block2, 0, 3);
		world.setBlock(x + 12, y + 0, z + 11, Block5, 0, 3);
		world.setBlock(x + 16, y + 0, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 0, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + 0, z + 11, Library.getRandomConcrete(), 0, 3);
		//world.setBlock(x + 21, y + 0, z + 11, Blocks.iron_door, 0, 3);
        ItemDoor.placeDoorBlock(world, x + 21, y + 0, z + 11, 0, Blocks.IRON_DOOR);
		world.setBlock(x + 22, y + 0, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + 0, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 0, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + 0, z + 11, Library.getRandomConcrete(), 0, 3);
		//world.setBlock(x + 26, y + 0, z + 11, Blocks.wooden_door, 1, 3);
        ItemDoor.placeDoorBlock(world, x + 26, y + 0, z + 11, 1, Blocks.OAK_DOOR);
		world.setBlock(x + 27, y + 0, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 28, y + 0, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 29, y + 0, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + 0, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + 0, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + 0, z + 11, Library.getRandomConcrete(), 0, 3);
		//world.setBlock(x + 33, y + 0, z + 11, Blocks.wooden_door, 0, 3);
        ItemDoor.placeDoorBlock(world, x + 33, y + 0, z + 11, 0, Blocks.OAK_DOOR);
		world.setBlock(x + 34, y + 0, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 35, y + 0, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 36, y + 0, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 37, y + 0, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 0, z + 11, Block5, 0, 3);
		world.setBlock(x + 0, y + 0, z + 12, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 0, z + 12, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 0, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 0, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 0, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 0, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 0, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 0, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + 0, z + 12, Block2, 0, 3);
		world.setBlock(x + 12, y + 0, z + 12, Block5, 0, 3);
		world.setBlock(x + 16, y + 0, z + 12, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 0, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + 0, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		world.setBlock(x + 19, y + 0, z + 12, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 0, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + 0, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		world.setBlock(x + 22, y + 0, z + 12, Block7, 0, 3);
		world.setBlock(x + 23, y + 0, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 0, z + 12, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 25, y + 0, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 0, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		world.setBlock(x + 28, y + 0, z + 12, Block8, 3, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 0, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 30, y + 0, z + 12, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 0, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 33, y + 0, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 0, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.CHEST.getStateFromMeta(3), 3); }
		if((world.isValid(new BlockPos(x + 36, y + 0, z + 12)) ? world.getBlockState(new BlockPos(x + 36, y + 0, z + 12)).getBlock() : Blocks.AIR) == Blocks.CHEST)
		{
			WeightedRandomChestContent.generateChestContents(rand, ItemPool.getPool(ItemPoolsLegacy.POOL_GENERIC), (TileEntityChest)world.getTileEntity(new BlockPos(x + 36, y + 0, z + 12)), 8);
		}
        world.setBlock(x + 37, y + 0, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 0, z + 12, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 13, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 0, z + 13, Block5, 0, 3);
		world.setBlock(x + 5, y + 0, z + 13, Block2, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 0, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 0, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 0, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 0, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 0, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + 0, z + 13, Block2, 0, 3);
		world.setBlock(x + 12, y + 0, z + 13, Block5, 0, 3);
		world.setBlock(x + 16, y + 0, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 0, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + 0, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 0, z + 13, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 0, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.CHEST.getStateFromMeta(4), 3); }
		if((world.isValid(new BlockPos(x + 22, y + 0, z + 13)) ? world.getBlockState(new BlockPos(x + 22, y + 0, z + 13)).getBlock() : Blocks.AIR) == Blocks.CHEST)
		{
			WeightedRandomChestContent.generateChestContents(rand, ItemPool.getPool(ItemPoolsLegacy.POOL_GENERIC), (TileEntityChest)world.getTileEntity(new BlockPos(x + 22, y + 0, z + 13)), 8);
		}
		world.setBlock(x + 23, y + 0, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 0, z + 13, Block9, 5, 3);
		world.setBlock(x + 30, y + 0, z + 13, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 0, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 37, y + 0, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 0, z + 13, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 14, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 0, z + 14, Block5, 0, 3);
		world.setBlock(x + 5, y + 0, z + 14, Block2, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 0, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 0, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 0, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 0, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 0, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + 0, z + 14, Block2, 0, 3);
		world.setBlock(x + 12, y + 0, z + 14, Block5, 0, 3);
		world.setBlock(x + 16, y + 0, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 0, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + 0, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 0, z + 14, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 0, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		world.setBlock(x + 22, y + 0, z + 14, Block7, 0, 3);
		world.setBlock(x + 23, y + 0, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 0, z + 14, Block9, 5, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 0, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_STAIRS.getStateFromMeta(7), 3); }
		world.setBlock(x + 30, y + 0, z + 14, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 0, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 0, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_BRICK_STAIRS.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 0, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONEBRICK.getStateFromMeta(0), 3); }
		world.setBlock(x + 37, y + 0, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 0, z + 14, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 15, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 5, y + 0, z + 15, Block5, 0, 3);
		world.setBlock(x + 6, y + 0, z + 15, Block2, 0, 3);
		world.setBlock(x + 7, y + 0, z + 15, Block2, 0, 3);
		world.setBlock(x + 8, y + 0, z + 15, Block2, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 0, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 10, y + 0, z + 15, Block2, 0, 3);
		world.setBlock(x + 11, y + 0, z + 15, Block5, 0, 3);
		world.setBlock(x + 16, y + 0, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 0, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + 0, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 0, z + 15, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 0, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + 0, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		world.setBlock(x + 22, y + 0, z + 15, Block8, 4, 3);
		world.setBlock(x + 23, y + 0, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 0, z + 15, Block9, 5, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 25, y + 0, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 0, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_STAIRS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 0, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(8), 3); }
		world.setBlock(x + 30, y + 0, z + 15, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 0, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 0, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_BRICK_STAIRS.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 0, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONEBRICK.getStateFromMeta(0), 3); }
		world.setBlock(x + 37, y + 0, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 0, z + 15, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 16, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 0, z + 16, Block5, 0, 3);
		world.setBlock(x + 7, y + 0, z + 16, Block5, 0, 3);
		world.setBlock(x + 8, y + 0, z + 16, Block5, 0, 3);
		world.setBlock(x + 9, y + 0, z + 16, Block5, 0, 3);
		world.setBlock(x + 10, y + 0, z + 16, Block5, 0, 3);
		world.setBlock(x + 16, y + 0, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 0, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + 0, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 0, z + 16, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 0, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + 0, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 22, y + 0, z + 16, Block10, 4, 3);
		world.setBlock(x + 23, y + 0, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 0, z + 16, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 0, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(8), 3); }
		world.setBlock(x + 30, y + 0, z + 16, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 0, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_BRICK_STAIRS.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 0, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONEBRICK.getStateFromMeta(0), 3); }
		world.setBlock(x + 37, y + 0, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 0, z + 16, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 17, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 0, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 0, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + 0, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 0, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + 0, z + 17, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 21, y + 0, z + 17, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 22, y + 0, z + 17, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 23, y + 0, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 0, z + 17, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 0, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_STAIRS.getStateFromMeta(5), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 28, y + 0, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(8), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 0, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(8), 3); }
		world.setBlock(x + 30, y + 0, z + 17, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 0, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 0, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_BRICK_STAIRS.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 0, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONEBRICK.getStateFromMeta(0), 3); }
		world.setBlock(x + 37, y + 0, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 0, z + 17, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 18, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 21, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 22, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 26, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 27, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 28, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 29, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 33, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 34, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 35, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 36, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 37, y + 0, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 0, z + 18, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 19, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 0, z + 19, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 20, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 0, z + 20, Block8, 2, 3);
		world.setBlock(x + 7, y + 0, z + 20, Block8, 2, 3);
		world.setBlock(x + 8, y + 0, z + 20, Block8, 2, 3);
		world.setBlock(x + 9, y + 0, z + 20, Block8, 2, 3);
		world.setBlock(x + 10, y + 0, z + 20, Block8, 2, 3);
		world.setBlock(x + 40, y + 0, z + 20, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 21, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 0, z + 21, Block5, 0, 3);
		world.setBlock(x + 5, y + 0, z + 21, Block8, 2, 3);
		world.setBlock(x + 11, y + 0, z + 21, Block8, 2, 3);
		world.setBlock(x + 12, y + 0, z + 21, Block5, 0, 3);
		world.setBlock(x + 29, y + 0, z + 21, Block2, 0, 3);
		world.setBlock(x + 40, y + 0, z + 21, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 22, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 0, z + 22, Block8, 4, 3);
		world.setBlock(x + 12, y + 0, z + 22, Block8, 5, 3);
		world.setBlock(x + 17, y + 0, z + 22, Block2, 0, 3);
		world.setBlock(x + 19, y + 0, z + 22, Block2, 0, 3);
		world.setBlock(x + 22, y + 0, z + 22, Block2, 0, 3);
		world.setBlock(x + 25, y + 0, z + 22, Block2, 0, 3);
		world.setBlock(x + 26, y + 0, z + 22, Block2, 0, 3);
		world.setBlock(x + 28, y + 0, z + 22, Block2, 0, 3);
		world.setBlock(x + 29, y + 0, z + 22, Block2, 0, 3);
		world.setBlock(x + 30, y + 0, z + 22, Block2, 0, 3);
		world.setBlock(x + 35, y + 0, z + 22, Block2, 0, 3);
		world.setBlock(x + 40, y + 0, z + 22, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 23, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 0, z + 23, Block8, 4, 3);
		world.setBlock(x + 13, y + 0, z + 23, Block8, 5, 3);
		world.setBlock(x + 17, y + 0, z + 23, Block2, 0, 3);
		world.setBlock(x + 18, y + 0, z + 23, Block2, 0, 3);
		world.setBlock(x + 19, y + 0, z + 23, Block2, 0, 3);
		world.setBlock(x + 23, y + 0, z + 23, Block2, 0, 3);
		world.setBlock(x + 25, y + 0, z + 23, Block2, 0, 3);
		world.setBlock(x + 29, y + 0, z + 23, Block2, 0, 3);
		world.setBlock(x + 30, y + 0, z + 23, Block2, 0, 3);
		world.setBlock(x + 34, y + 0, z + 23, Block2, 0, 3);
		world.setBlock(x + 35, y + 0, z + 23, Block2, 0, 3);
		world.setBlock(x + 36, y + 0, z + 23, Block2, 0, 3);
		world.setBlock(x + 40, y + 0, z + 23, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 24, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 0, z + 24, Block8, 4, 3);
		world.setBlock(x + 13, y + 0, z + 24, Block8, 5, 3);
		world.setBlock(x + 21, y + 0, z + 24, Block2, 0, 3);
		world.setBlock(x + 22, y + 0, z + 24, Block2, 0, 3);
		world.setBlock(x + 23, y + 0, z + 24, Block2, 0, 3);
		world.setBlock(x + 26, y + 0, z + 24, Block2, 0, 3);
		world.setBlock(x + 33, y + 0, z + 24, Block2, 0, 3);
		world.setBlock(x + 34, y + 0, z + 24, Block2, 0, 3);
		world.setBlock(x + 35, y + 0, z + 24, Block2, 0, 3);
		world.setBlock(x + 40, y + 0, z + 24, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 25, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 0, z + 25, Block8, 4, 3);
		world.setBlock(x + 13, y + 0, z + 25, Block8, 5, 3);
		world.setBlock(x + 17, y + 0, z + 25, Block2, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 0, z + 25); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.FLOWER_POT.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + 0, z + 25, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 26, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 0, z + 26, Block8, 4, 3);
		world.setBlock(x + 13, y + 0, z + 26, Block8, 5, 3);
		world.setBlock(x + 19, y + 0, z + 26, Block2, 0, 3);
		world.setBlock(x + 20, y + 0, z + 26, Block2, 0, 3);
		world.setBlock(x + 21, y + 0, z + 26, Block2, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 0, z + 26); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.CHEST.getStateFromMeta(2), 3); }
		if((world.isValid(new BlockPos(x + 24, y + 0, z + 26)) ? world.getBlockState(new BlockPos(x + 24, y + 0, z + 26)).getBlock() : Blocks.AIR) == Blocks.CHEST)
		{
			WeightedRandomChestContent.generateChestContents(rand, ItemPool.getPool(ItemPoolsLegacy.POOL_NUKE_TRASH), (TileEntityChest)world.getTileEntity(new BlockPos(x + 24, y + 0, z + 26)), 8);
		}
		world.setBlock(x + 25, y + 0, z + 26, Block2, 0, 3);
		world.setBlock(x + 30, y + 0, z + 26, Block2, 0, 3);
		world.setBlock(x + 35, y + 0, z + 26, Block2, 0, 3);
		world.setBlock(x + 40, y + 0, z + 26, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 27, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 0, z + 27, Block8, 4, 3);
		world.setBlock(x + 13, y + 0, z + 27, Block8, 5, 3);
		world.setBlock(x + 18, y + 0, z + 27, Block2, 0, 3);
		world.setBlock(x + 19, y + 0, z + 27, Block2, 0, 3);
		world.setBlock(x + 20, y + 0, z + 27, Block2, 0, 3);
		world.setBlock(x + 21, y + 0, z + 27, Block2, 0, 3);
		world.setBlock(x + 23, y + 0, z + 27, Block2, 0, 3);
		world.setBlock(x + 24, y + 0, z + 27, Block2, 0, 3);
		world.setBlock(x + 25, y + 0, z + 27, Block2, 0, 3);
		world.setBlock(x + 26, y + 0, z + 27, Block2, 0, 3);
		world.setBlock(x + 29, y + 0, z + 27, Block2, 0, 3);
		world.setBlock(x + 30, y + 0, z + 27, Block2, 0, 3);
		world.setBlock(x + 31, y + 0, z + 27, Block2, 0, 3);
		world.setBlock(x + 35, y + 0, z + 27, Block2, 0, 3);
		world.setBlock(x + 36, y + 0, z + 27, Block2, 0, 3);
		world.setBlock(x + 40, y + 0, z + 27, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 28, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 0, z + 28, Block8, 4, 3);
		world.setBlock(x + 12, y + 0, z + 28, Block8, 5, 3);
		world.setBlock(x + 24, y + 0, z + 28, Block2, 0, 3);
		world.setBlock(x + 25, y + 0, z + 28, Block2, 0, 3);
		world.setBlock(x + 26, y + 0, z + 28, Block2, 0, 3);
		world.setBlock(x + 29, y + 0, z + 28, Block2, 0, 3);
		world.setBlock(x + 30, y + 0, z + 28, Block2, 0, 3);
		world.setBlock(x + 40, y + 0, z + 28, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 29, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 0, z + 29, Block5, 0, 3);
		world.setBlock(x + 5, y + 0, z + 29, Block8, 3, 3);
		world.setBlock(x + 11, y + 0, z + 29, Block8, 3, 3);
		world.setBlock(x + 12, y + 0, z + 29, Block5, 0, 3);
		world.setBlock(x + 40, y + 0, z + 29, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 30, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 0, z + 30, Block8, 3, 3);
		world.setBlock(x + 7, y + 0, z + 30, Block8, 3, 3);
		world.setBlock(x + 8, y + 0, z + 30, Block8, 3, 3);
		world.setBlock(x + 9, y + 0, z + 30, Block8, 3, 3);
		world.setBlock(x + 10, y + 0, z + 30, Block8, 3, 3);
		world.setBlock(x + 40, y + 0, z + 30, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 0, z + 31, Block5, 0, 3);
		world.setBlock(x + 17, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 18, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 19, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 20, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 21, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 22, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 23, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 24, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 25, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 26, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 27, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 28, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 29, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 30, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 31, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 32, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 33, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 34, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 35, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 36, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 37, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 38, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 39, y + 0, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 0, z + 31, Block5, 0, 3);
		world.setBlock(x + 0, y + 0, z + 32, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 0, z + 32, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 0, z + 33, Block5, 0, 3);
		world.setBlock(x + 1, y + 0, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 2, y + 0, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 0, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 0, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 5, y + 0, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 0, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 7, y + 0, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 8, y + 0, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 9, y + 0, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 10, y + 0, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 11, y + 0, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 12, y + 0, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 13, y + 0, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 14, y + 0, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 15, y + 0, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 0, z + 33, Block5, 0, 3);
		world.setBlock(x + 0, y + 1, z + 0, Block5, 0, 3);
		world.setBlock(x + 1, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 2, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 5, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 7, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 8, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 9, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 10, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 11, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 12, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 13, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 14, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 15, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 17, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 18, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 19, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 20, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 21, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 22, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 23, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 24, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 25, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 26, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 27, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 28, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 29, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 30, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 31, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 32, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 33, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 34, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 35, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 36, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 37, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 38, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 39, y + 1, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 1, z + 0, Block5, 0, 3);
		world.setBlock(x + 0, y + 1, z + 1, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 1, z + 1, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 2, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 1, z + 2, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 3, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 1, z + 3, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 4, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 1, z + 4, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 5, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 1, z + 5, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 6, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + 1, z + 6, Block11, 0, 3);
		world.setBlock(x + 19, y + 1, z + 6, Block11, 0, 3);
		world.setBlock(x + 20, y + 1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 21, y + 1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 22, y + 1, z + 6, Block11, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 23, y + 1, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		world.setBlock(x + 24, y + 1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + 1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 26, y + 1, z + 6, Block11, 0, 3);
		world.setBlock(x + 27, y + 1, z + 6, Block11, 0, 3);
		world.setBlock(x + 28, y + 1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 29, y + 1, z + 6, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 1, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 32, y + 1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 33, y + 1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 35, y + 1, z + 6, Block11, 0, 3);
		world.setBlock(x + 36, y + 1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 37, y + 1, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 1, z + 6, Block5, 0, 3);
		world.setBlock(x + 0, y + 1, z + 7, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 7, y + 1, z + 7, Block8, 2, 3);
		world.setBlock(x + 9, y + 1, z + 7, Block8, 2, 3);
		world.setBlock(x + 16, y + 1, z + 7, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 1, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 1, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + 1, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 1, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 1, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 1, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 33, y + 1, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 1, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 37, y + 1, z + 7, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 40, y + 1, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		world.setBlock(x + 0, y + 1, z + 8, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 1, z + 8, Block5, 0, 3);
		world.setBlock(x + 7, y + 1, z + 8, Block5, 0, 3);
		world.setBlock(x + 8, y + 1, z + 8, Block5, 0, 3);
		world.setBlock(x + 9, y + 1, z + 8, Block5, 0, 3);
		world.setBlock(x + 10, y + 1, z + 8, Block5, 0, 3);
		world.setBlock(x + 16, y + 1, z + 8, Library.getRandomConcrete(), 0, 3);
		//world.setBlock(x + 37, y + 1, z + 8, Blocks.iron_door, 9, 3);
        //ItemDoor.placeDoorBlock(world, x + 37, y + 1, z + 8, 9, Blocks.iron_door);
		{ BlockPos dungeonPos = new BlockPos(x + 40, y + 1, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		world.setBlock(x + 0, y + 1, z + 9, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 5, y + 1, z + 9, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 1, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }

		generate_r01(world, rand, x, y, z);
		return true;

	}
	public boolean generate_r01(World world, Random rand, int x, int y, int z)
	{

		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 1, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 1, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 1, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 1, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + 1, z + 9, Block5, 0, 3);
		world.setBlock(x + 16, y + 1, z + 9, Library.getRandomConcrete(), 0, 3);
		//world.setBlock(x + 37, y + 1, z + 9, Blocks.iron_door, 8, 3);
        //ItemDoor.placeDoorBlock(world, x + 37, y + 1, z + 9, 8, Blocks.iron_door);
		{ BlockPos dungeonPos = new BlockPos(x + 40, y + 1, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		world.setBlock(x + 0, y + 1, z + 10, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 1, z + 10, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 1, z + 10, Block5, 0, 3);
		world.setBlock(x + 16, y + 1, z + 10, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + 1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 23, y + 1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		world.setBlock(x + 37, y + 1, z + 10, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 40, y + 1, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		world.setBlock(x + 0, y + 1, z + 11, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 1, z + 11, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 1, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 1, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 1, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 1, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 1, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 1, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 1, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 1, z + 11, Block5, 0, 3);
		world.setBlock(x + 16, y + 1, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 1, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + 1, z + 11, Library.getRandomConcrete(), 0, 3);
		//world.setBlock(x + 21, y + 1, z + 11, Blocks.iron_door, 8, 3);
        //ItemDoor.placeDoorBlock(world, x + 21, y + 1, z + 11, 8, Blocks.iron_door);
		world.setBlock(x + 22, y + 1, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + 1, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 1, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + 1, z + 11, Library.getRandomConcrete(), 0, 3);
		//world.setBlock(x + 26, y + 1, z + 11, Blocks.wooden_door, 8, 3);
        //ItemDoor.placeDoorBlock(world, x + 26, y + 1, z + 11, 8, Blocks.wooden_door);
		world.setBlock(x + 27, y + 1, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 28, y + 1, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 29, y + 1, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + 1, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + 1, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + 1, z + 11, Library.getRandomConcrete(), 0, 3);
		//world.setBlock(x + 33, y + 1, z + 11, Blocks.wooden_door, 8, 3);
        //ItemDoor.placeDoorBlock(world, x + 33, y + 1, z + 11, 8, Blocks.wooden_door);
		world.setBlock(x + 34, y + 1, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 35, y + 1, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 36, y + 1, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 37, y + 1, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 1, z + 11, Block5, 0, 3);
		world.setBlock(x + 0, y + 1, z + 12, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 1, z + 12, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 1, z + 12, Block5, 0, 3);
		world.setBlock(x + 16, y + 1, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 1, z + 12, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + 1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_BRICK_STAIRS.getStateFromMeta(4), 3); }
		world.setBlock(x + 23, y + 1, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 1, z + 12, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 25, y + 1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		world.setBlock(x + 28, y + 1, z + 12, Block8, 3, 3);
		world.setBlock(x + 30, y + 1, z + 12, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 33, y + 1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 1, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		world.setBlock(x + 37, y + 1, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 1, z + 12, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 13, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 1, z + 13, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 1, z + 13, Block5, 0, 3);
		world.setBlock(x + 16, y + 1, z + 13, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + 1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		world.setBlock(x + 19, y + 1, z + 13, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_BRICK_STAIRS.getStateFromMeta(4), 3); }
		world.setBlock(x + 23, y + 1, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 1, z + 13, Block9, 5, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 25, y + 1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		world.setBlock(x + 30, y + 1, z + 13, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 1, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 37, y + 1, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 1, z + 13, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 14, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 1, z + 14, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 1, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 1, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 1, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 1, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 1, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 1, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 1, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 1, z + 14, Block5, 0, 3);
		world.setBlock(x + 16, y + 1, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 1, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + 1, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 1, z + 14, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 1, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 1, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_BRICK_STAIRS.getStateFromMeta(4), 3); }
		world.setBlock(x + 23, y + 1, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 1, z + 14, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 1, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 30, y + 1, z + 14, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 1, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		world.setBlock(x + 36, y + 1, z + 14, Block9, 4, 3);
		world.setBlock(x + 37, y + 1, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 1, z + 14, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 15, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 5, y + 1, z + 15, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 1, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 1, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 1, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 1, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 1, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + 1, z + 15, Block5, 0, 3);
		world.setBlock(x + 16, y + 1, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 1, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + 1, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 1, z + 15, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 1, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + 1, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		world.setBlock(x + 22, y + 1, z + 15, Block8, 4, 3);
		world.setBlock(x + 23, y + 1, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 1, z + 15, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 25, y + 1, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		world.setBlock(x + 29, y + 1, z + 15, Block12, 0, 3);
		world.setBlock(x + 30, y + 1, z + 15, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 1, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 1, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.FLOWER_POT.getStateFromMeta(0), 3); }
		world.setBlock(x + 36, y + 1, z + 15, Block9, 4, 3);
		world.setBlock(x + 37, y + 1, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 1, z + 15, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 16, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 1, z + 16, Block5, 0, 3);
		world.setBlock(x + 7, y + 1, z + 16, Block5, 0, 3);
		world.setBlock(x + 8, y + 1, z + 16, Block5, 0, 3);
		world.setBlock(x + 9, y + 1, z + 16, Block5, 0, 3);
		world.setBlock(x + 10, y + 1, z + 16, Block5, 0, 3);
		world.setBlock(x + 16, y + 1, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 1, z + 16, Library.getRandomConcrete(), 0, 3);
		
		
		//world.setBlock(x + 18, y + 1, z + 16, Blocks.chest, 2, 3);
		
		/*
		if(world.getBlock(x + 18, y + 1, z + 16) == Blocks.chest)
		{
			WeightedRandomChestContent.generateChestContents(rand, HbmChestContents.getLoot(3), (TileEntityChest)world.getTileEntity(x + 18, y + 1, z + 16), 8);
		}
		*/

		world.setBlock(x + 18, y + 1, z + 16, ModBlocks.crate_steel, 0, 3);
		if((world.isValid(new BlockPos(x + 18, y + 1, z + 16)) ? world.getBlockState(new BlockPos(x + 18, y + 1, z + 16)).getBlock() : Blocks.AIR) == ModBlocks.crate_steel)
		{
			WeightedRandomChestContent.generateChestContents(rand, ItemPool.getPool(ItemPoolsLegacy.POOL_EXPENSIVE), (TileEntityCrateSteel)world.getTileEntity(new BlockPos(x + 18, y + 1, z + 16)), 12);
		}
		
		world.setBlock(x + 19, y + 1, z + 16, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 1, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 1, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_BRICK_STAIRS.getStateFromMeta(4), 3); }
		world.setBlock(x + 23, y + 1, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 1, z + 16, Block9, 5, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 1, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 30, y + 1, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 36, y + 1, z + 16, Block9, 4, 3);
		world.setBlock(x + 37, y + 1, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 1, z + 16, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 17, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 1, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 1, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + 1, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 1, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + 1, z + 17, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 21, y + 1, z + 17, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 22, y + 1, z + 17, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 23, y + 1, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 1, z + 17, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 28, y + 1, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.FLOWER_POT.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 1, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 30, y + 1, z + 17, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 1, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(3), 3); }
		world.setBlock(x + 36, y + 1, z + 17, Block9, 4, 3);
		world.setBlock(x + 37, y + 1, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 1, z + 17, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 18, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + 1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + 1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 21, y + 1, z + 18, Block11, 0, 3);
		world.setBlock(x + 22, y + 1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + 1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + 1, z + 18, Block11, 0, 3);
		world.setBlock(x + 27, y + 1, z + 18, Block13, 4, 3);
		world.setBlock(x + 28, y + 1, z + 18, Block11, 0, 3);
		world.setBlock(x + 29, y + 1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + 1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + 1, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + 1, z + 18, Block11, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 33, y + 1, z + 18); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.FLOWER_POT.getStateFromMeta(0), 3); }
		world.setBlock(x + 35, y + 1, z + 18, Block11, 0, 3);
		world.setBlock(x + 36, y + 1, z + 18, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 37, y + 1, z + 18); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + 1, z + 18, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 19, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 1, z + 19, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 20, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 1, z + 20, Block5, 0, 3);
		world.setBlock(x + 7, y + 1, z + 20, Block5, 0, 3);
		world.setBlock(x + 8, y + 1, z + 20, Block5, 0, 3);
		world.setBlock(x + 9, y + 1, z + 20, Block5, 0, 3);
		world.setBlock(x + 10, y + 1, z + 20, Block5, 0, 3);
		world.setBlock(x + 40, y + 1, z + 20, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 21, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 1, z + 21, Block5, 0, 3);
		world.setBlock(x + 5, y + 1, z + 21, Block5, 0, 3);
		world.setBlock(x + 11, y + 1, z + 21, Block5, 0, 3);
		world.setBlock(x + 12, y + 1, z + 21, Block5, 0, 3);
		world.setBlock(x + 40, y + 1, z + 21, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 22, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 1, z + 22, Block5, 0, 3);
		world.setBlock(x + 12, y + 1, z + 22, Block5, 0, 3);
		world.setBlock(x + 29, y + 1, z + 22, Block2, 0, 3);
		world.setBlock(x + 40, y + 1, z + 22, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 23, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 1, z + 23, Block5, 0, 3);
		world.setBlock(x + 13, y + 1, z + 23, Block5, 0, 3);
		world.setBlock(x + 17, y + 1, z + 23, Block2, 0, 3);
		world.setBlock(x + 25, y + 1, z + 23, Block2, 0, 3);
		world.setBlock(x + 35, y + 1, z + 23, Block2, 0, 3);
		world.setBlock(x + 40, y + 1, z + 23, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 24, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 1, z + 24, Block5, 0, 3);
		world.setBlock(x + 13, y + 1, z + 24, Block5, 0, 3);
		world.setBlock(x + 23, y + 1, z + 24, Block2, 0, 3);
		world.setBlock(x + 40, y + 1, z + 24, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 25, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 1, z + 25, Block5, 0, 3);
		world.setBlock(x + 13, y + 1, z + 25, Block5, 0, 3);
		world.setBlock(x + 40, y + 1, z + 25, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 26, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 1, z + 26, Block5, 0, 3);
		world.setBlock(x + 13, y + 1, z + 26, Block5, 0, 3);
		world.setBlock(x + 40, y + 1, z + 26, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 27, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 1, z + 27, Block5, 0, 3);
		world.setBlock(x + 13, y + 1, z + 27, Block5, 0, 3);
		world.setBlock(x + 19, y + 1, z + 27, Block2, 0, 3);
		world.setBlock(x + 20, y + 1, z + 27, Block2, 0, 3);
		world.setBlock(x + 21, y + 1, z + 27, Block2, 0, 3);
		world.setBlock(x + 24, y + 1, z + 27, Block2, 0, 3);
		world.setBlock(x + 25, y + 1, z + 27, Block2, 0, 3);
		world.setBlock(x + 30, y + 1, z + 27, Block2, 0, 3);
		world.setBlock(x + 35, y + 1, z + 27, Block2, 0, 3);
		world.setBlock(x + 40, y + 1, z + 27, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 28, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 1, z + 28, Block5, 0, 3);
		world.setBlock(x + 12, y + 1, z + 28, Block5, 0, 3);
		world.setBlock(x + 25, y + 1, z + 28, Block2, 0, 3);
		world.setBlock(x + 40, y + 1, z + 28, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 29, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 1, z + 29, Block5, 0, 3);
		world.setBlock(x + 5, y + 1, z + 29, Block5, 0, 3);
		world.setBlock(x + 11, y + 1, z + 29, Block5, 0, 3);
		world.setBlock(x + 12, y + 1, z + 29, Block5, 0, 3);
		world.setBlock(x + 40, y + 1, z + 29, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 30, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 1, z + 30, Block5, 0, 3);
		world.setBlock(x + 7, y + 1, z + 30, Block5, 0, 3);
		world.setBlock(x + 8, y + 1, z + 30, Block5, 0, 3);
		world.setBlock(x + 9, y + 1, z + 30, Block5, 0, 3);
		world.setBlock(x + 10, y + 1, z + 30, Block5, 0, 3);
		world.setBlock(x + 40, y + 1, z + 30, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 1, z + 31, Block5, 0, 3);
		world.setBlock(x + 17, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 18, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 19, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 20, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 21, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 22, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 23, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 24, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 25, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 26, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 27, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 28, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 29, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 30, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 31, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 32, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 33, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 34, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 35, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 36, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 37, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 38, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 39, y + 1, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 1, z + 31, Block5, 0, 3);
		world.setBlock(x + 0, y + 1, z + 32, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 1, z + 32, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 1, z + 33, Block5, 0, 3);
		world.setBlock(x + 1, y + 1, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 2, y + 1, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 1, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 1, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 5, y + 1, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 1, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 7, y + 1, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 8, y + 1, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 9, y + 1, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 10, y + 1, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 11, y + 1, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 12, y + 1, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 13, y + 1, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 14, y + 1, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 15, y + 1, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 1, z + 33, Block5, 0, 3);
		world.setBlock(x + 0, y + 2, z + 0, Block5, 0, 3);
		world.setBlock(x + 1, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 2, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 5, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 7, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 8, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 9, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 10, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 11, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 12, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 13, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 14, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 15, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 17, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 18, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 19, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 20, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 21, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 22, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 23, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 24, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 25, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 26, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 27, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 28, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 29, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 30, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 31, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 32, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 33, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 34, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 35, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 36, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 37, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 38, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 39, y + 2, z + 0, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 2, z + 0, Block5, 0, 3);
		world.setBlock(x + 0, y + 2, z + 1, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 2, z + 1, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 2, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 2, z + 2, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 3, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 2, z + 3, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 4, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 2, z + 4, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 5, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 2, z + 5, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 6, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 21, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 22, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 26, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 27, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 28, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 29, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 33, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 34, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 35, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 36, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 37, y + 2, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 2, z + 6, Block5, 0, 3);
		world.setBlock(x + 0, y + 2, z + 7, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 7, y + 2, z + 7, Block8, 2, 3);
		world.setBlock(x + 9, y + 2, z + 7, Block8, 2, 3);
		world.setBlock(x + 16, y + 2, z + 7, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 2, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + 2, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 19, y + 2, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 2, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + 2, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 2, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 2, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 30, y + 2, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 2, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 32, y + 2, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 2, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 37, y + 2, z + 7, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 2, z + 7, Block5, 0, 3);
		world.setBlock(x + 0, y + 2, z + 8, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 2, z + 8, Block5, 0, 3);
		world.setBlock(x + 7, y + 2, z + 8, Block5, 0, 3);
		world.setBlock(x + 8, y + 2, z + 8, Block5, 0, 3);
		world.setBlock(x + 9, y + 2, z + 8, Block5, 0, 3);
		world.setBlock(x + 10, y + 2, z + 8, Block5, 0, 3);
		world.setBlock(x + 16, y + 2, z + 8, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 2, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 26, y + 2, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 2, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 37, y + 2, z + 8, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 40, y + 2, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		world.setBlock(x + 0, y + 2, z + 9, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 5, y + 2, z + 9, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 2, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 2, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 2, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 2, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 2, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + 2, z + 9, Block5, 0, 3);
		world.setBlock(x + 16, y + 2, z + 9, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 2, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 32, y + 2, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 33, y + 2, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 37, y + 2, z + 9, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 40, y + 2, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		world.setBlock(x + 0, y + 2, z + 10, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 2, z + 10, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 2, z + 10, Block5, 0, 3);
		world.setBlock(x + 16, y + 2, z + 10, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + 2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 22, y + 2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 23, y + 2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 24, y + 2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 25, y + 2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 32, y + 2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 34, y + 2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 2, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(1), 3); }
		world.setBlock(x + 37, y + 2, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 2, z + 10, Block5, 0, 3);
		world.setBlock(x + 0, y + 2, z + 11, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 2, z + 11, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 2, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 2, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 2, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 2, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 2, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 2, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 2, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 2, z + 11, Block5, 0, 3);
		world.setBlock(x + 16, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 21, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 22, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 26, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 27, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 28, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 29, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 33, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 34, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 35, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 36, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 37, y + 2, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 2, z + 11, Block5, 0, 3);
		world.setBlock(x + 0, y + 2, z + 12, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 2, z + 12, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 8, y + 2, z + 12, Block14, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 2, z + 12, Block5, 0, 3);
		world.setBlock(x + 16, y + 2, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 2, z + 12, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + 2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		world.setBlock(x + 22, y + 2, z + 12, Block9, 4, 3);
		world.setBlock(x + 23, y + 2, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 2, z + 12, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 25, y + 2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		world.setBlock(x + 28, y + 2, z + 12, Block8, 3, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 30, y + 2, z + 12, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 33, y + 2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 2, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(4), 3); }
		world.setBlock(x + 37, y + 2, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 2, z + 12, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 13, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 2, z + 13, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 2, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 2, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 2, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 2, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 2, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 2, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 2, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 2, z + 13, Block5, 0, 3);
		world.setBlock(x + 16, y + 2, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 2, z + 13, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 2, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 22, y + 2, z + 13, Block9, 4, 3);
		world.setBlock(x + 23, y + 2, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 2, z + 13, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 25, y + 2, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 2, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 30, y + 2, z + 13, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 2, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 2, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 37, y + 2, z + 13, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 2, z + 13, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 14, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 2, z + 14, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 2, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 2, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 2, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 2, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 2, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 2, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 2, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 2, z + 14, Block5, 0, 3);
		world.setBlock(x + 16, y + 2, z + 14, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 17, y + 2, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 18, y + 2, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		world.setBlock(x + 19, y + 2, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 22, y + 2, z + 14, Block9, 4, 3);
		world.setBlock(x + 23, y + 2, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 2, z + 14, Block9, 5, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 2, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		world.setBlock(x + 30, y + 2, z + 14, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 2, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_BRICK_STAIRS.getStateFromMeta(0), 3); }
		world.setBlock(x + 37, y + 2, z + 14, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 2, z + 14, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 15, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 5, y + 2, z + 15, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 2, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 2, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 2, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 2, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 2, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + 2, z + 15, Block5, 0, 3);
		world.setBlock(x + 16, y + 2, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 2, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + 2, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 2, z + 15, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 2, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + 2, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(8), 3); }
		world.setBlock(x + 22, y + 2, z + 15, Block5, 0, 3);
		world.setBlock(x + 23, y + 2, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 2, z + 15, Block9, 5, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 27, y + 2, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 2, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 30, y + 2, z + 15, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 2, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 2, z + 15); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_BRICK_STAIRS.getStateFromMeta(0), 3); }
		world.setBlock(x + 37, y + 2, z + 15, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 2, z + 15, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 16, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 2, z + 16, Block5, 0, 3);
		world.setBlock(x + 7, y + 2, z + 16, Block5, 0, 3);
		world.setBlock(x + 8, y + 2, z + 16, Block5, 0, 3);
		world.setBlock(x + 9, y + 2, z + 16, Block5, 0, 3);
		world.setBlock(x + 10, y + 2, z + 16, Block5, 0, 3);
		world.setBlock(x + 16, y + 2, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 2, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + 2, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 2, z + 16, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 20, y + 2, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 21, y + 2, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 22, y + 2, z + 16, Block9, 4, 3);
		world.setBlock(x + 23, y + 2, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 2, z + 16, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 25, y + 2, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 29, y + 2, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 30, y + 2, z + 16, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 2, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 2, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 2, z + 16); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_BRICK_STAIRS.getStateFromMeta(0), 3); }
		world.setBlock(x + 37, y + 2, z + 16, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 2, z + 16, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 17, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 2, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 2, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + 2, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 2, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + 2, z + 17, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 21, y + 2, z + 17, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 22, y + 2, z + 17, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 23, y + 2, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 2, z + 17, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 28, y + 2, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 30, y + 2, z + 17, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 31, y + 2, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 34, y + 2, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 2, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.VINE.getStateFromMeta(3), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 36, y + 2, z + 17); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_BRICK_STAIRS.getStateFromMeta(0), 3); }
		world.setBlock(x + 37, y + 2, z + 17, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 2, z + 17, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 18, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 2, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 2, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + 2, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 2, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + 2, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 21, y + 2, z + 18, Block11, 0, 3);
		world.setBlock(x + 22, y + 2, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + 2, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 2, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 27, y + 2, z + 18, Block11, 0, 3);
		world.setBlock(x + 28, y + 2, z + 18, Block11, 0, 3);
		world.setBlock(x + 29, y + 2, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + 2, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + 2, z + 18, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + 2, z + 18, Block11, 0, 3);
		world.setBlock(x + 34, y + 2, z + 18, Block11, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 35, y + 2, z + 18); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 36, y + 2, z + 18, Library.getRandomConcrete(), 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 37, y + 2, z + 18); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRAVEL.getStateFromMeta(0), 3); }
		world.setBlock(x + 40, y + 2, z + 18, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 19, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 2, z + 19, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 20, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 2, z + 20, Block15, 0, 3);
		world.setBlock(x + 7, y + 2, z + 20, Block15, 0, 3);
		world.setBlock(x + 8, y + 2, z + 20, Block15, 0, 3);
		world.setBlock(x + 9, y + 2, z + 20, Block15, 0, 3);
		world.setBlock(x + 10, y + 2, z + 20, Block15, 0, 3);
		world.setBlock(x + 40, y + 2, z + 20, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 21, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 2, z + 21, Block15, 0, 3);
		world.setBlock(x + 5, y + 2, z + 21, Block15, 0, 3);
		world.setBlock(x + 11, y + 2, z + 21, Block15, 0, 3);
		world.setBlock(x + 12, y + 2, z + 21, Block15, 0, 3);
		world.setBlock(x + 40, y + 2, z + 21, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 22, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 2, z + 22, Block15, 0, 3);
		world.setBlock(x + 12, y + 2, z + 22, Block15, 0, 3);
		world.setBlock(x + 40, y + 2, z + 22, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 23, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 2, z + 23, Block15, 0, 3);
		world.setBlock(x + 13, y + 2, z + 23, Block15, 0, 3);
		world.setBlock(x + 40, y + 2, z + 23, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 24, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 2, z + 24, Block15, 0, 3);
		world.setBlock(x + 13, y + 2, z + 24, Block15, 0, 3);
		world.setBlock(x + 40, y + 2, z + 24, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 25, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 2, z + 25, Block15, 0, 3);
		world.setBlock(x + 13, y + 2, z + 25, Block15, 0, 3);
		world.setBlock(x + 40, y + 2, z + 25, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 26, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 2, z + 26, Block15, 0, 3);
		world.setBlock(x + 13, y + 2, z + 26, Block15, 0, 3);
		world.setBlock(x + 40, y + 2, z + 26, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 27, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 2, z + 27, Block15, 0, 3);
		world.setBlock(x + 13, y + 2, z + 27, Block15, 0, 3);
		world.setBlock(x + 24, y + 2, z + 27, Block2, 0, 3);
		world.setBlock(x + 40, y + 2, z + 27, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 28, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 2, z + 28, Block15, 0, 3);
		world.setBlock(x + 12, y + 2, z + 28, Block15, 0, 3);
		world.setBlock(x + 40, y + 2, z + 28, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 29, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 2, z + 29, Block15, 0, 3);
		world.setBlock(x + 5, y + 2, z + 29, Block15, 0, 3);
		world.setBlock(x + 11, y + 2, z + 29, Block15, 0, 3);
		world.setBlock(x + 12, y + 2, z + 29, Block15, 0, 3);
		world.setBlock(x + 40, y + 2, z + 29, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 30, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 2, z + 30, Block15, 0, 3);
		world.setBlock(x + 7, y + 2, z + 30, Block15, 0, 3);
		world.setBlock(x + 8, y + 2, z + 30, Block15, 0, 3);
		world.setBlock(x + 9, y + 2, z + 30, Block15, 0, 3);
		world.setBlock(x + 10, y + 2, z + 30, Block15, 0, 3);
		world.setBlock(x + 40, y + 2, z + 30, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 2, z + 31, Block5, 0, 3);
		world.setBlock(x + 17, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 18, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 19, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 20, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 21, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 22, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 23, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 24, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 25, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 26, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 27, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 28, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 29, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 30, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 31, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 32, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 33, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 34, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 35, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 36, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 37, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 38, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 39, y + 2, z + 31, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 40, y + 2, z + 31, Block5, 0, 3);
		world.setBlock(x + 0, y + 2, z + 32, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 2, z + 32, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 0, y + 2, z + 33, Block5, 0, 3);
		world.setBlock(x + 1, y + 2, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 2, y + 2, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 3, y + 2, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 4, y + 2, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 5, y + 2, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 6, y + 2, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 7, y + 2, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 8, y + 2, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 9, y + 2, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 10, y + 2, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 11, y + 2, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 12, y + 2, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 13, y + 2, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 14, y + 2, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 15, y + 2, z + 33, ModBlocks.fence_metal, 0, 3);
		world.setBlock(x + 16, y + 2, z + 33, Block5, 0, 3);
		world.setBlock(x + 0, y + 3, z + 0, Block5, 0, 3);
		world.setBlock(x + 1, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 2, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 3, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 4, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 5, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 6, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 7, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 8, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 9, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 10, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 11, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 12, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 13, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 14, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 15, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 16, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 17, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 18, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 19, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 20, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 21, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 22, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 23, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 24, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 25, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 26, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 27, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 28, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 29, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 30, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 31, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 32, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 33, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 34, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 35, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 36, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 37, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 38, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 39, y + 3, z + 0, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 40, y + 3, z + 0, Block5, 0, 3);
		world.setBlock(x + 0, y + 3, z + 1, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 40, y + 3, z + 1, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 2, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 40, y + 3, z + 2, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 3, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 40, y + 3, z + 3, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 4, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 40, y + 3, z + 4, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 5, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 40, y + 3, z + 5, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 0, y + 3, z + 6, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 16, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 18, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 20, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 21, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 22, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 23, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 24, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 25, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 26, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 27, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 28, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 29, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 30, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 31, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 32, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 33, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 34, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 35, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 36, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 37, y + 3, z + 6, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 3, z + 6, Block5, 0, 3);
		world.setBlock(x + 0, y + 3, z + 7, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 7, y + 3, z + 7, Block8, 2, 3);
		world.setBlock(x + 9, y + 3, z + 7, Block8, 2, 3);
		world.setBlock(x + 16, y + 3, z + 7, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 18, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 19, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 20, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 21, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 22, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 23, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 24, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 25, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 26, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 27, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 28, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 29, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 30, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 31, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 32, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 33, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 34, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 35, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 36, y + 3, z + 7, Block6, 0, 3);
		world.setBlock(x + 37, y + 3, z + 7, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 3, z + 7, Block5, 0, 3);
		world.setBlock(x + 0, y + 3, z + 8, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 6, y + 3, z + 8, Block5, 0, 3);
		world.setBlock(x + 7, y + 3, z + 8, Block5, 0, 3);
		world.setBlock(x + 8, y + 3, z + 8, Block5, 0, 3);
		world.setBlock(x + 9, y + 3, z + 8, Block5, 0, 3);
		world.setBlock(x + 10, y + 3, z + 8, Block5, 0, 3);
		world.setBlock(x + 16, y + 3, z + 8, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 18, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 19, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 20, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 21, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 22, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 23, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 24, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 25, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 26, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 27, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 28, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 29, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 30, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 31, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 32, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 33, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 34, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 35, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 36, y + 3, z + 8, Block6, 0, 3);
		world.setBlock(x + 37, y + 3, z + 8, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 3, z + 8, Block5, 0, 3);
		world.setBlock(x + 0, y + 3, z + 9, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 5, y + 3, z + 9, Block5, 0, 3);
		world.setBlock(x + 6, y + 3, z + 9, Block5, 0, 3);
		world.setBlock(x + 7, y + 3, z + 9, Block5, 0, 3);
		world.setBlock(x + 8, y + 3, z + 9, Block5, 0, 3);
		world.setBlock(x + 9, y + 3, z + 9, Block5, 0, 3);
		world.setBlock(x + 10, y + 3, z + 9, Block5, 0, 3);
		world.setBlock(x + 11, y + 3, z + 9, Block5, 0, 3);
		world.setBlock(x + 16, y + 3, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 17, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 18, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 19, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 20, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 21, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 22, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 23, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 24, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 25, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 26, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 27, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 28, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 29, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 30, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 31, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 32, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 33, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 34, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 35, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 36, y + 3, z + 9, Block6, 0, 3);
		world.setBlock(x + 37, y + 3, z + 9, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 3, z + 9, Block5, 0, 3);
		world.setBlock(x + 0, y + 3, z + 10, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 4, y + 3, z + 10, Block5, 0, 3);
		world.setBlock(x + 5, y + 3, z + 10, Block5, 0, 3);
		world.setBlock(x + 6, y + 3, z + 10, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 3, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 8, y + 3, z + 10, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 3, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 10, y + 3, z + 10, Block5, 0, 3);
		world.setBlock(x + 11, y + 3, z + 10, Block5, 0, 3);
		world.setBlock(x + 12, y + 3, z + 10, Block5, 0, 3);
		world.setBlock(x + 16, y + 3, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 3, z + 10, Block6, 0, 3);
		world.setBlock(x + 20, y + 3, z + 10, Block6, 0, 3);
		world.setBlock(x + 21, y + 3, z + 10, Block6, 0, 3);
		world.setBlock(x + 22, y + 3, z + 10, Block6, 0, 3);
		world.setBlock(x + 23, y + 3, z + 10, Block6, 0, 3);
		world.setBlock(x + 24, y + 3, z + 10, Block6, 0, 3);
		world.setBlock(x + 25, y + 3, z + 10, Block6, 0, 3);
		world.setBlock(x + 26, y + 3, z + 10, Block6, 0, 3);
		world.setBlock(x + 27, y + 3, z + 10, Block6, 0, 3);
		world.setBlock(x + 28, y + 3, z + 10, Block6, 0, 3);
		world.setBlock(x + 29, y + 3, z + 10, Block6, 0, 3);
		world.setBlock(x + 30, y + 3, z + 10, Block6, 0, 3);
		world.setBlock(x + 31, y + 3, z + 10, Block6, 0, 3);
		world.setBlock(x + 32, y + 3, z + 10, Block6, 0, 3);
		world.setBlock(x + 33, y + 3, z + 10, Block6, 0, 3);
		world.setBlock(x + 34, y + 3, z + 10, Block6, 0, 3);
		world.setBlock(x + 35, y + 3, z + 10, Block6, 0, 3);
		world.setBlock(x + 36, y + 3, z + 10, Block6, 0, 3);
		world.setBlock(x + 37, y + 3, z + 10, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 3, z + 10, Block5, 0, 3);
		world.setBlock(x + 0, y + 3, z + 11, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 4, y + 3, z + 11, Block5, 0, 3);
		world.setBlock(x + 5, y + 3, z + 11, Block5, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 3, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 7, y + 3, z + 11, Block16, 4, 3);
		world.setBlock(x + 8, y + 3, z + 11, Block14, 0, 3);
		world.setBlock(x + 9, y + 3, z + 11, Block16, 2, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 3, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WATER.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + 3, z + 11, Block5, 0, 3);
		world.setBlock(x + 12, y + 3, z + 11, Block5, 0, 3);
		world.setBlock(x + 16, y + 3, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 3, z + 11, Block6, 0, 3);
		world.setBlock(x + 20, y + 3, z + 11, Block6, 0, 3);
		world.setBlock(x + 21, y + 3, z + 11, Block6, 0, 3);
		world.setBlock(x + 22, y + 3, z + 11, Block6, 0, 3);
		world.setBlock(x + 23, y + 3, z + 11, Block6, 0, 3);
		world.setBlock(x + 24, y + 3, z + 11, Block6, 0, 3);
		world.setBlock(x + 25, y + 3, z + 11, Block6, 0, 3);
		world.setBlock(x + 26, y + 3, z + 11, Block6, 0, 3);
		world.setBlock(x + 27, y + 3, z + 11, Block6, 0, 3);
		world.setBlock(x + 28, y + 3, z + 11, Block6, 0, 3);
		world.setBlock(x + 29, y + 3, z + 11, Block6, 0, 3);
		world.setBlock(x + 30, y + 3, z + 11, Block6, 0, 3);
		world.setBlock(x + 31, y + 3, z + 11, Block6, 0, 3);
		world.setBlock(x + 32, y + 3, z + 11, Block6, 0, 3);
		world.setBlock(x + 33, y + 3, z + 11, Block6, 0, 3);
		world.setBlock(x + 34, y + 3, z + 11, Block6, 0, 3);
		world.setBlock(x + 35, y + 3, z + 11, Block6, 0, 3);
		world.setBlock(x + 36, y + 3, z + 11, Block6, 0, 3);
		world.setBlock(x + 37, y + 3, z + 11, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 40, y + 3, z + 11, Block5, 0, 3);
		world.setBlock(x + 0, y + 3, z + 12, ModBlocks.barbed_wire, 0, 3);
		world.setBlock(x + 4, y + 3, z + 12, Block5, 0, 3);
		world.setBlock(x + 5, y + 3, z + 12, Block5, 0, 3);
		world.setBlock(x + 6, y + 3, z + 12, Block5, 0, 3);
		world.setBlock(x + 7, y + 3, z + 12, Block14, 0, 3);
		world.setBlock(x + 8, y + 3, z + 12, Block17, 0, 3);
		world.setBlock(x + 9, y + 3, z + 12, Block14, 0, 3);
		world.setBlock(x + 10, y + 3, z + 12, Block5, 0, 3);
		world.setBlock(x + 11, y + 3, z + 12, Block5, 0, 3);
		world.setBlock(x + 12, y + 3, z + 12, Block5, 0, 3);
		world.setBlock(x + 16, y + 3, z + 12, Library.getRandomConcrete(), 0, 3);
		world.setBlock(x + 19, y + 3, z + 12, Block6, 0, 3);
		world.setBlock(x + 20, y + 3, z + 12, Block6, 0, 3);

		new DesertAtom003().generate_r00(world, rand, x, y, z);
		return true;

	}
}