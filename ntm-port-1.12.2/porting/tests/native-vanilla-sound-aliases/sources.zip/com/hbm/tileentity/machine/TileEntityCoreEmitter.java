package com.hbm.tileentity.machine;

import api.hbm.block.ILaserable;
import api.hbm.energymk2.IEnergyReceiverMK2;
import api.hbm.fluid.IFluidStandardReceiver;
import api.hbm.redstoneoverradio.IRORInteractive;
import api.hbm.tile.IInfoProviderEC;

import com.hbm.handler.CompatHandler;
import com.hbm.inventory.container.ContainerCoreEmitter;
import com.hbm.inventory.fluid.Fluids;
import com.hbm.inventory.fluid.tank.FluidTank;
import com.hbm.inventory.gui.GUICoreEmitter;
import com.hbm.lib.ModDamageSource;
import com.hbm.tileentity.IGUIProvider;
import com.hbm.tileentity.TileEntityMachineBase;
import com.hbm.util.CompatEnergyControl;

import net.minecraftforge.fml.common.Optional;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import io.netty.buffer.ByteBuf;
import li.cil.oc.api.machine.Arguments;
import li.cil.oc.api.machine.Callback;
import li.cil.oc.api.machine.Context;
import li.cil.oc.api.network.SimpleComponent;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.Container;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import com.hbm.lib.ForgeDirection;

import java.util.List;

@Optional.InterfaceList({@Optional.Interface(iface = "li.cil.oc.api.network.SimpleComponent", modid = "OpenComputers")})
public class TileEntityCoreEmitter extends TileEntityMachineBase implements IEnergyReceiverMK2, ILaserable, IFluidStandardReceiver, SimpleComponent, IGUIProvider, IInfoProviderEC, CompatHandler.OCComponent, IRORInteractive {
	
	public long power;
	public static final long maxPower = 1000000000L;
	public int watts;
	public int beam;
	public long joules;
	public boolean isOn;
	public FluidTank tank;
	public long prev;
	
	public static final int range = 50;

	public TileEntityCoreEmitter() {
		super(0);
		tank = new FluidTank(Fluids.CRYOGEL, 64000);
	}

	@Override
	public String getDefaultName() {
		return "container.dfcEmitter";
	}

	@Override
	public void update() {

		if (!this.world.isRemote) {
			for(ForgeDirection dir : ForgeDirection.VALID_DIRECTIONS) this.trySubscribe(this.world, this.pos.getX() + dir.offsetX, this.pos.getY() + dir.offsetY, this.pos.getZ() + dir.offsetZ, dir);
			this.subscribeToAllAround(tank.getTankType(), this);
			
			watts = MathHelper.clamp(watts, 1, 100);
			long demand = maxPower * watts / 2000;
			
			beam = 0;
			
			if(joules > 0 || prev > 0) {

				if(tank.getFill() >= 20) {
					tank.setFill(tank.getFill() - 20);
				} else {
					this.world.setBlock(this.pos.getX(), this.pos.getY(), this.pos.getZ(), Blocks.FLOWING_LAVA);
					return;
				}
			}
			
			if(isOn) {
				
				//i.e. 50,000,000 HE = 10,000 SPK
				//1 SPK = 5,000HE
				
				if(power >= demand) {
					power -= demand;
					long add = watts * 100;
					joules += add;
				}
				prev = joules;
				
				if(joules > 0) {
					
					long out = joules * 95 / 100;
					
					ForgeDirection dir = ForgeDirection.getOrientation(this.getBlockMetadata());
					for(int i = 1; i <= range; i++) {
						
						beam = i;
		
						int x = this.pos.getX() + dir.offsetX * i;
						int y = this.pos.getY() + dir.offsetY * i;
						int z = this.pos.getZ() + dir.offsetZ * i;
						
						Block block = com.hbm.world.WorldBlockState.read(this.world, x, y, z).getBlock();
						TileEntity te = this.world.getTileEntity(new net.minecraft.util.math.BlockPos(x, y, z));
						
						if(block instanceof ILaserable) { ((ILaserable)block).addEnergy(this.world, x, y, z, out, dir); break; }
						if(te instanceof ILaserable) { ((ILaserable)te).addEnergy(this.world, x, y, z, out, dir); break; }
						if(te instanceof TileEntityCore) { out = ((TileEntityCore)te).burn(out); continue; }
						
						Block b = com.hbm.world.WorldBlockState.read(this.world, x, y, z).getBlock();
						
						if(!b.isAir(this.world, x, y, z)) {
							
							if(b.getDefaultState().getMaterial().isLiquid()) {
								this.world.playSoundEffect(x + 0.5, y + 0.5, z + 0.5, "random.fizz", 1.0F, 1.0F);
								com.hbm.world.WorldAirRemoval.remove(this.world, x, y, z);
								break;
							}
							
							float hardness = b.getExplosionResistance(null);
							if(hardness < 6000 && this.world.rand.nextInt(20) == 0) {
								this.world.func_147480_a(x, y, z, false);
							}
							
							break;
						}
					}
					
					
					joules = 0;
		
					double blx = Math.min(this.pos.getX(), this.pos.getX() + dir.offsetX * beam) + 0.2;
					double bux = Math.max(this.pos.getX(), this.pos.getX() + dir.offsetX * beam) + 0.8;
					double bly = Math.min(this.pos.getY(), this.pos.getY() + dir.offsetY * beam) + 0.2;
					double buy = Math.max(this.pos.getY(), this.pos.getY() + dir.offsetY * beam) + 0.8;
					double blz = Math.min(this.pos.getZ(), this.pos.getZ() + dir.offsetZ * beam) + 0.2;
					double buz = Math.max(this.pos.getZ(), this.pos.getZ() + dir.offsetZ * beam) + 0.8;
					
					List<Entity> list = this.world.getEntitiesWithinAABB(Entity.class, AxisAlignedBB.getBoundingBox(blx, bly, blz, bux, buy, buz));
					
					for(Entity e : list) {
						e.attackEntityFrom(ModDamageSource.amsCore, 50);
						e.setFire(10);
					}
				}
			} else {
				joules = 0;
				prev = 0;
			}
			
			this.markDirty();

			this.networkPackNT(250);
		}
	}

	@Override
	public void serialize(ByteBuf buf) {
		super.serialize(buf);

		buf.writeLong(power);
		buf.writeInt(watts);
		buf.writeLong(prev);
		buf.writeInt(beam);
		buf.writeBoolean(isOn);
		tank.serialize(buf);
	}

	@Override
	public void deserialize(ByteBuf buf) {
		super.deserialize(buf);

		this.power = buf.readLong();
		this.watts = buf.readInt();
		this.prev = buf.readLong();
		this.beam = buf.readInt();
		this.isOn = buf.readBoolean();
		tank.deserialize(buf);
	}
	
	public long getPowerScaled(long i) {
		return (power * i) / maxPower;
	}
	
	public int getWattsScaled(int i) {
		return (watts * i) / 100;
	}

	@Override
	public void setPower(long i) {
		this.power = i;
	}

	@Override
	public long getPower() {
		return this.power;
	}

	@Override
	public long getMaxPower() {
		return this.maxPower;
	}

	@Override
	public boolean canConnect(ForgeDirection dir) {
		return dir != ForgeDirection.UNKNOWN;
	}

	@Override
	public void addEnergy(World world, int x, int y, int z, long energy, ForgeDirection dir) {
		
		//do not accept lasers from the front
		if(dir.getOpposite().ordinal() != this.getBlockMetadata())
			joules += energy;
	}
	
	@Override
	public AxisAlignedBB getRenderBoundingBox() {
		return TileEntity.INFINITE_EXTENT_AABB;
	}
	
	@Override
	@SideOnly(Side.CLIENT)
	public double getMaxRenderDistanceSquared()
	{
		return 65536.0D;
	}
	
	@Override
	public void readFromNBT(NBTTagCompound nbt) {
		super.readFromNBT(nbt);
		
		power = nbt.getLong("power");
		watts = nbt.getInteger("watts");
		joules = nbt.getLong("joules");
		prev = nbt.getLong("prev");
		isOn = nbt.getBoolean("isOn");
		tank.readFromNBT(nbt, "tank");
	}
	
	@Override
	public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
		super.writeToNBT(nbt);
		
		nbt.setLong("power", power);
		nbt.setInteger("watts", watts);
		nbt.setLong("joules", joules);
		nbt.setLong("prev", prev);
		nbt.setBoolean("isOn", isOn);
		tank.writeToNBT(nbt, "tank");
		return nbt;
	}

	@Override
	public FluidTank[] getReceivingTanks() {
		return new FluidTank[] { tank };
	}

	@Override
	public FluidTank[] getAllTanks() {
		return new FluidTank[] { tank };
	}
	
	// do some opencomputer stuff
	@Override
	@Optional.Method(modid = "OpenComputers")
	public String getComponentName() {
		return "dfc_emitter";
	}

	@Callback(direct = true)
	@Optional.Method(modid = "OpenComputers")
	public Object[] getEnergyInfo(Context context, Arguments args) {
		return new Object[] {getPower(), getMaxPower()};
	}

	@Callback(direct = true)
	@Optional.Method(modid = "OpenComputers")
	public Object[] getCryogel(Context context, Arguments args) {
		return new Object[] {tank.getFill()};
	}

	@Callback(direct = true)
	@Optional.Method(modid = "OpenComputers")
	public Object[] getInput(Context context, Arguments args) {
		return new Object[] {watts};
	}

	@Callback(direct = true)
	@Optional.Method(modid = "OpenComputers")
	public Object[] getInfo(Context context, Arguments args) {
		return new Object[] {getPower(), getMaxPower(), tank.getFill(), watts, isOn};
	}

	@Callback(direct = true)
	@Optional.Method(modid = "OpenComputers")
	public Object[] isActive(Context context, Arguments args) {
		return new Object[] {isOn};
	}

	@Callback(direct = true, limit = 4)
	@Optional.Method(modid = "OpenComputers")
	public Object[] setActive(Context context, Arguments args) {
		isOn = args.checkBoolean(0);
		return new Object[] {};
	}

	@Callback(direct = true, limit = 4)
	@Optional.Method(modid = "OpenComputers")
	public Object[] setInput(Context context, Arguments args) {
		int newOutput = args.checkInteger(0);
		watts = MathHelper.clamp(newOutput, 0, 100);
		return new Object[] {};
	}

	@Override
	public Container provideContainer(int ID, EntityPlayer player, World world, int x, int y, int z) {
		return new ContainerCoreEmitter(player.inventory, this);
	}

	@Override
	@SideOnly(Side.CLIENT)
	public Object provideGUI(int ID, EntityPlayer player, World world, int x, int y, int z) {
		return new GUICoreEmitter(player.inventory, this);
	}

	@Override
	public void provideExtraInfo(NBTTagCompound data) {
		data.setDouble(CompatEnergyControl.D_CONSUMPTION_MB, joules > 0 || prev > 0 ? 20 : 0);
		data.setDouble(CompatEnergyControl.D_CONSUMPTION_HE, maxPower * watts / 2000);
	}

	@Override
	public String[] getFunctionInfo() {
		return new String[] {
				PREFIX_FUNCTION + "setpower" + NAME_SEPARATOR + "percent",
				PREFIX_FUNCTION + "toggle",
				PREFIX_FUNCTION + "switch" + NAME_SEPARATOR + "on/off",
		};
	}

	@Override
	public String runRORFunction(String name, String[] params) {
		
		if((PREFIX_FUNCTION + "setpower").equals(name) && params.length > 0) {
			int watts = IRORInteractive.parseInt(params[0], 0, 100);
			this.watts = watts;
			this.markChanged();
			return null;
		}
		
		if((PREFIX_FUNCTION + "toggle").equals(name)) {
			this.isOn = !this.isOn;
			this.markChanged();
			return null;
		}
			
		
		if((PREFIX_FUNCTION + "switch").equals(name) && params.length > 0) {
			if("on".equals(params[0])) {
				this.isOn = true;
				this.markChanged();
				return null;
			}
			if("off".equals(params[0])) {
				this.isOn = false;
				this.markChanged();
				return null;
			}
		}
		
		return null;
	}
}
