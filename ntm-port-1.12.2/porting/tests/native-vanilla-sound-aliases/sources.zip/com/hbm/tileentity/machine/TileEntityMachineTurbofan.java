package com.hbm.tileentity.machine;

import java.util.HashMap;
import java.util.List;

import com.hbm.blocks.BlockDummyable;
import com.hbm.blocks.ModBlocks;
import com.hbm.handler.MultiblockHandlerXR;
import com.hbm.handler.threading.PacketThreading;
import com.hbm.inventory.UpgradeManagerNT;
import com.hbm.inventory.container.ContainerMachineTurbofan;
import com.hbm.inventory.fluid.Fluids;
import com.hbm.inventory.fluid.tank.FluidTank;
import com.hbm.inventory.fluid.trait.FT_Combustible;
import com.hbm.inventory.fluid.trait.FT_Combustible.FuelGrade;
import com.hbm.inventory.fluid.trait.FluidTrait;
import com.hbm.inventory.gui.GUIMachineTurbofan;
import com.hbm.items.ModItems;
import com.hbm.items.machine.ItemMachineUpgrade.UpgradeType;
import com.hbm.lib.Library;
import com.hbm.lib.ModDamageSource;
import com.hbm.main.MainRegistry;
import com.hbm.packet.toclient.AuxParticlePacketNT;
import com.hbm.sound.AudioWrapper;
import com.hbm.tileentity.IFluidCopiable;
import com.hbm.tileentity.IGUIProvider;
import com.hbm.tileentity.IUpgradeInfoProvider;
import com.hbm.tileentity.TileEntityMachinePolluting;
import com.hbm.util.CompatEnergyControl;
import com.hbm.util.fauxpointtwelve.DirPos;
import com.hbm.util.i18n.I18nUtil;

import api.hbm.energymk2.IEnergyProviderMK2;
import api.hbm.fluid.IFluidStandardTransceiver;
import api.hbm.tile.IInfoProviderEC;
import net.minecraftforge.fml.common.network.NetworkRegistry.TargetPoint;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import com.hbm.lib.ForgeDirection;

public class TileEntityMachineTurbofan extends TileEntityMachinePolluting implements IEnergyProviderMK2, IFluidStandardTransceiver, IGUIProvider, IUpgradeInfoProvider, IInfoProviderEC, IFluidCopiable {

	public long power;
	public static final long maxPower = 1_000_000;
	public FluidTank tank;
	public FluidTank blood;

	public int afterburner;
	public boolean wasOn;
	public boolean showBlood = false;
	protected int output;
	protected int consumption;

	public float spin;
	public float lastSpin;
	public int momentum = 0;

	private AudioWrapper audio;

	public UpgradeManagerNT upgradeManager = new UpgradeManagerNT();

	public TileEntityMachineTurbofan() {
		super(5, 150);
		tank = new FluidTank(Fluids.KEROSENE, 24000);
		blood = new FluidTank(Fluids.BLOOD, 24000);
	}

	@Override
	public String getDefaultName() {
		return "container.machineTurbofan";
	}

	@Override
	public void readFromNBT(NBTTagCompound nbt) {
		super.readFromNBT(nbt);

		this.power = nbt.getLong("powerTime");
		tank.readFromNBT(nbt, "fuel");
		blood.readFromNBT(nbt, "blood");
		this.showBlood = nbt.getBoolean("showBlood");
	}

	@Override
	public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
		super.writeToNBT(nbt);

		nbt.setLong("powerTime", power);
		tank.writeToNBT(nbt, "fuel");
		blood.writeToNBT(nbt, "blood");
		nbt.setBoolean("showBlood", showBlood);
		return nbt;
	}

	public long getPowerScaled(long i) {
		return (power * i) / maxPower;
	}

	protected DirPos[] getConPos() {

		ForgeDirection dir = ForgeDirection.getOrientation(this.getBlockMetadata() - 10).getRotation(ForgeDirection.UP);
		ForgeDirection rot = dir.getRotation(ForgeDirection.DOWN);

		return new DirPos[] {
				new DirPos(this.pos.getX() + rot.offsetX * 2, this.pos.getY(), this.pos.getZ() + rot.offsetZ * 2, rot),
				new DirPos(this.pos.getX() + rot.offsetX * 2 - dir.offsetX, this.pos.getY(), this.pos.getZ() + rot.offsetZ * 2 - dir.offsetZ, rot),
				new DirPos(this.pos.getX() - rot.offsetX * 2, this.pos.getY(), this.pos.getZ() - rot.offsetZ * 2, rot.getOpposite()),
				new DirPos(this.pos.getX() - rot.offsetX * 2 - dir.offsetX, this.pos.getY(), this.pos.getZ() - rot.offsetZ * 2 - dir.offsetZ, rot.getOpposite())
		};
	}

	@Override
	public void update() {

		if(!this.world.isRemote) {

			this.output = 0;
			this.consumption = 0;

			//meta below 12 means that it's an old multiblock configuration
			if(this.getBlockMetadata() < 12) {
				//get old direction
				ForgeDirection dir = ForgeDirection.getOrientation(this.getBlockMetadata());
				//remove tile from the world to prevent inventory dropping
				this.world.removeTileEntity(this.pos.getX(), this.pos.getY(), this.pos.getZ());
				//use fillspace to create a new multiblock configuration
				this.world.setBlock(this.pos.getX(), this.pos.getY(), this.pos.getZ(), ModBlocks.machine_turbofan, dir.ordinal() + 10, 3);
				MultiblockHandlerXR.fillSpace(this.world, this.pos.getX(), this.pos.getY(), this.pos.getZ(), ((BlockDummyable) ModBlocks.machine_turbofan).getDimensions(), ModBlocks.machine_turbofan, dir);
				//restore connections
				ForgeDirection rot = dir.getRotation(ForgeDirection.UP);
				((BlockDummyable) ModBlocks.machine_turbofan).makeExtra(this.world, this.pos.getX() + dir.offsetX, this.pos.getY(), this.pos.getZ() + dir.offsetZ);
				((BlockDummyable) ModBlocks.machine_turbofan).makeExtra(this.world, this.pos.getX() + dir.offsetX - rot.offsetX, this.pos.getY(), this.pos.getZ() + dir.offsetZ - rot.offsetZ);
				((BlockDummyable) ModBlocks.machine_turbofan).makeExtra(this.world, this.pos.getX() - dir.offsetX, this.pos.getY(), this.pos.getZ() - dir.offsetZ);
				((BlockDummyable) ModBlocks.machine_turbofan).makeExtra(this.world, this.pos.getX() - dir.offsetX - rot.offsetX, this.pos.getY(), this.pos.getZ() - dir.offsetZ - rot.offsetZ);
				//load the tile data to restore the old values
				NBTTagCompound data = new NBTTagCompound();
				this.writeToNBT(data);
				this.world.getTileEntity(new net.minecraft.util.math.BlockPos(this.pos.getX(), this.pos.getY(), this.pos.getZ())).readFromNBT(data);
				return;
			}

			tank.setType(4, slots);
			tank.loadTank(0, 1, slots);
			blood.setTankType(Fluids.BLOOD);

			this.wasOn = false;

			upgradeManager.checkSlots(this, slots, 2, 2);
			this.afterburner = upgradeManager.getLevel(UpgradeType.AFTERBURN);

			if(slots[2] != null && slots[2].getItem() == ModItems.flame_pony)
				this.afterburner = 100;

			long burnValue = 0;
			int amount = 1 + this.afterburner;

			boolean redstone = false;

			for(DirPos pos : getConPos()) {
				if(this.world.isBlockIndirectlyGettingPowered(pos.getX(), pos.getY(), pos.getZ())) {
					redstone = true;
					break;
				}
			}

			int amountToBurn = 0;

			if(!redstone) {

				if(tank.getTankType().hasTrait(FT_Combustible.class) && tank.getTankType().getTrait(FT_Combustible.class).getGrade() == FuelGrade.AERO) {
					burnValue = tank.getTankType().getTrait(FT_Combustible.class).getCombustionEnergy() / 1_000;
				}

				amountToBurn = Math.min(amount, this.tank.getFill());
				if(amountToBurn > 0 && !breatheAir(amountToBurn)) amountToBurn = 0;

				if(amountToBurn > 0) {
					this.wasOn = true;
					this.tank.setFill(this.tank.getFill() - amountToBurn);
					this.output = (int) (burnValue * amountToBurn * (1 + Math.min(this.afterburner / 3D, 4)));
					this.power += this.output;
					this.consumption = amountToBurn;

					if(this.world.getTotalWorldTime() % 20 == 0) super.pollute(tank.getTankType(), FluidTrait.FluidReleaseType.BURN, amountToBurn * 5);;
				}
			}

			power = Library.chargeItemsFromTE(slots, 3, power, power);

			for(DirPos pos : getConPos()) {
				this.tryProvide(this.world, pos.getX(), pos.getY(), pos.getZ(), pos.getDir());
				this.trySubscribe(tank.getTankType(), this.world, pos.getX(), pos.getY(), pos.getZ(), pos.getDir());
				if(this.blood.getFill() > 0) this.sendFluid(blood, this.world, pos.getX(), pos.getY(), pos.getZ(), pos.getDir());
				this.sendSmoke(pos.getX(), pos.getY(), pos.getZ(), pos.getDir());
			}

			if(burnValue > 0 && amountToBurn > 0) {

				ForgeDirection dir = ForgeDirection.getOrientation(this.getBlockMetadata() - 10).getRotation(ForgeDirection.UP);
				ForgeDirection rot = dir.getRotation(ForgeDirection.UP);

				if(this.afterburner > 0) {

					for(int i = 0; i < 2; i++) {
						double speed = 2 + this.world.rand.nextDouble() * 3;
						double deviation = this.world.rand.nextGaussian() * 0.2;
						NBTTagCompound data = new NBTTagCompound();
						data.setString("type", "gasfire");
						data.setDouble("mX", -dir.offsetX * speed + deviation);
						data.setDouble("mZ", -dir.offsetZ * speed + deviation);
						data.setFloat("scale", 8F);
						PacketThreading.createAllAroundThreadedPacket(new AuxParticlePacketNT(data, this.pos.getX() + 0.5F - dir.offsetX * (3 - i), this.pos.getY() + 1.5F, this.pos.getZ() + 0.5F - dir.offsetZ * (3 - i)), new TargetPoint(this.world.provider.getDimension(), this.pos.getX(), this.pos.getY(), this.pos.getZ(), 150));
					}

					/*if(this.afterburner > 90 && worldObj.rand.nextInt(60) == 0) {
						worldObj.newExplosion(null, xCoord + 0.5 + dir.offsetX * 3.5, yCoord + 0.5, zCoord + 0.5 + dir.offsetZ * 3.5, 3F, false, false);
					}*/

					if(this.afterburner > 90 && this.world.rand.nextInt(30) == 0) {
						com.hbm.sound.WorldSoundEffects.play(this.world, this.pos.getX() + 0.5, this.pos.getY() + 1.5, this.pos.getZ() + 0.5, "hbm:block.damage", 3.0F, 0.95F + this.world.rand.nextFloat() * 0.2F);
					}

					if(this.afterburner > 90) {
						NBTTagCompound data = new NBTTagCompound();
						data.setString("type", "gasfire");
						data.setDouble("mY", 0.1 * this.world.rand.nextDouble());
						data.setFloat("scale", 4F);
						PacketThreading.createAllAroundThreadedPacket(new AuxParticlePacketNT(data,
								this.pos.getX() + 0.5F + dir.offsetX * (this.world.rand.nextDouble() * 4 - 2) + rot.offsetX * (this.world.rand.nextDouble() * 2 - 1),
								this.pos.getY() + 1F + this.world.rand.nextDouble() * 2,
								this.pos.getZ() + 0.5F - dir.offsetZ * (this.world.rand.nextDouble() * 4 - 2) + rot.offsetZ * (this.world.rand.nextDouble() * 2 - 1)
								), new TargetPoint(this.world.provider.getDimension(), this.pos.getX(), this.pos.getY(), this.pos.getZ(), 150));
					}
				}

				double minX = this.pos.getX() + 0.5 - dir.offsetX * 3.5 - rot.offsetX * 1.5;
				double maxX = this.pos.getX() + 0.5 - dir.offsetX * 19.5 + rot.offsetX * 1.5;
				double minZ = this.pos.getZ() + 0.5 - dir.offsetZ * 3.5 - rot.offsetZ * 1.5;
				double maxZ = this.pos.getZ() + 0.5 - dir.offsetZ * 19.5 + rot.offsetZ * 1.5;

				List<Entity> list = this.world.getEntitiesWithinAABB(Entity.class, AxisAlignedBB.getBoundingBox(Math.min(minX, maxX), this.pos.getY(), Math.min(minZ, maxZ), Math.max(minX, maxX), this.pos.getY() + 3, Math.max(minZ, maxZ)));

				for(Entity e : list) {

					if(this.afterburner > 0) {
						e.setFire(5);
						e.attackEntityFrom(DamageSource.onFire, 5F);
					}
					e.motionX -= dir.offsetX * 0.2;
					e.motionZ -= dir.offsetZ * 0.2;
				}

				minX = this.pos.getX() + 0.5 + dir.offsetX * 3.5 - rot.offsetX * 1.5;
				maxX = this.pos.getX() + 0.5 + dir.offsetX * 8.5 + rot.offsetX * 1.5;
				minZ = this.pos.getZ() + 0.5 + dir.offsetZ * 3.5 - rot.offsetZ * 1.5;
				maxZ = this.pos.getZ() + 0.5 + dir.offsetZ * 8.5 + rot.offsetZ * 1.5;

				list = this.world.getEntitiesWithinAABB(Entity.class, AxisAlignedBB.getBoundingBox(Math.min(minX, maxX), this.pos.getY(), Math.min(minZ, maxZ), Math.max(minX, maxX), this.pos.getY() + 3, Math.max(minZ, maxZ)));

				for(Entity e : list) {
					e.motionX -= dir.offsetX * 0.2;
					e.motionZ -= dir.offsetZ * 0.2;
				}

				minX = this.pos.getX() + 0.5 + dir.offsetX * 3.5 - rot.offsetX * 1.5;
				maxX = this.pos.getX() + 0.5 + dir.offsetX * 3.75 + rot.offsetX * 1.5;
				minZ = this.pos.getZ() + 0.5 + dir.offsetZ * 3.5 - rot.offsetZ * 1.5;
				maxZ = this.pos.getZ() + 0.5 + dir.offsetZ * 3.75 + rot.offsetZ * 1.5;

				list = this.world.getEntitiesWithinAABB(Entity.class, AxisAlignedBB.getBoundingBox(Math.min(minX, maxX), this.pos.getY(), Math.min(minZ, maxZ), Math.max(minX, maxX), this.pos.getY() + 3, Math.max(minZ, maxZ)));

				for(Entity e : list) {
					e.attackEntityFrom(ModDamageSource.turbofan, 1000);
					e.setInWeb();

					if(!e.isEntityAlive() && e instanceof EntityLivingBase) {
						NBTTagCompound vdat = new NBTTagCompound();
						vdat.setString("type", "giblets");
						vdat.setInteger("ent", e.getEntityId());
						vdat.setInteger("cDiv", 5);
						PacketThreading.createAllAroundThreadedPacket(new AuxParticlePacketNT(vdat, e.posX, e.posY + e.height * 0.5, e.posZ), new TargetPoint(e.dimension, e.posX, e.posY + e.height * 0.5, e.posZ, 150));

						this.world.playSoundEffect(e.posX, e.posY, e.posZ, "mob.zombie.woodbreak", 2.0F, 0.95F + this.world.rand.nextFloat() * 0.2F);

						blood.setFill(blood.getFill() + 50);
						if(blood.getFill() > blood.getMaxFill()) {
							blood.setFill(blood.getMaxFill());
						}
						this.showBlood = true;
					}
				}
			}

			if(this.power > this.maxPower) {
				this.power = this.maxPower;
			}

			this.networkPackNT(150);

		} else {

			this.lastSpin = this.spin;

			if(wasOn) {
				if(this.momentum < 100F)
					this.momentum++;
			} else {
				if(this.momentum > 0)
					this.momentum--;
			}

			this.spin += momentum / 2;

			if(this.spin >= 360) {
				this.spin -= 360F;
				this.lastSpin -= 360F;
			}

			if(momentum > 0) {

				if(audio == null) {
					audio = createAudioLoop();
					audio.startSound();
				} else if(!audio.isPlaying()) {
					audio = rebootAudio(audio);
				}

				audio.keepAlive();
				audio.updateVolume(getVolume(momentum / 50F));
				audio.updatePitch(momentum / 200F + 0.5F + this.afterburner * 0.16F);

			} else {

				if(audio != null) {
					audio.stopSound();
					audio = null;
				}
			}

			/*
			 * All movement related stuff has to be repeated on the client, but only for the client's player
			 * Otherwise this could lead to desync since the motion is never sent form the server
			 */
			if(wasOn && !MainRegistry.proxy.me().capabilities.isCreativeMode) {
				ForgeDirection dir = ForgeDirection.getOrientation(this.getBlockMetadata() - 10).getRotation(ForgeDirection.UP);
				ForgeDirection rot = dir.getRotation(ForgeDirection.UP);

				double minX = this.pos.getX() + 0.5 - dir.offsetX * 3.5 - rot.offsetX * 1.5;
				double maxX = this.pos.getX() + 0.5 - dir.offsetX * 19.5 + rot.offsetX * 1.5;
				double minZ = this.pos.getZ() + 0.5 - dir.offsetZ * 3.5 - rot.offsetZ * 1.5;
				double maxZ = this.pos.getZ() + 0.5 - dir.offsetZ * 19.5 + rot.offsetZ * 1.5;

				List<Entity> list = this.world.getEntitiesWithinAABB(Entity.class, AxisAlignedBB.getBoundingBox(Math.min(minX, maxX), this.pos.getY(), Math.min(minZ, maxZ), Math.max(minX, maxX), this.pos.getY() + 3, Math.max(minZ, maxZ)));

				for(Entity e : list) {
					if(e == MainRegistry.proxy.me()) {
						e.motionX -= dir.offsetX * 0.2;
						e.motionZ -= dir.offsetZ * 0.2;
					}
				}

				minX = this.pos.getX() + 0.5 + dir.offsetX * 3.5 - rot.offsetX * 1.5;
				maxX = this.pos.getX() + 0.5 + dir.offsetX * 8.5 + rot.offsetX * 1.5;
				minZ = this.pos.getZ() + 0.5 + dir.offsetZ * 3.5 - rot.offsetZ * 1.5;
				maxZ = this.pos.getZ() + 0.5 + dir.offsetZ * 8.5 + rot.offsetZ * 1.5;

				list = this.world.getEntitiesWithinAABB(Entity.class, AxisAlignedBB.getBoundingBox(Math.min(minX, maxX), this.pos.getY(), Math.min(minZ, maxZ), Math.max(minX, maxX), this.pos.getY() + 3, Math.max(minZ, maxZ)));

				for(Entity e : list) {
					if(e == MainRegistry.proxy.me()) {
						e.motionX -= dir.offsetX * 0.2;
						e.motionZ -= dir.offsetZ * 0.2;
					}
				}

				minX = this.pos.getX() + 0.5 + dir.offsetX * 3.5 - rot.offsetX * 1.5;
				maxX = this.pos.getX() + 0.5 + dir.offsetX * 3.75 + rot.offsetX * 1.5;
				minZ = this.pos.getZ() + 0.5 + dir.offsetZ * 3.5 - rot.offsetZ * 1.5;
				maxZ = this.pos.getZ() + 0.5 + dir.offsetZ * 3.75 + rot.offsetZ * 1.5;

				list = this.world.getEntitiesWithinAABB(Entity.class, AxisAlignedBB.getBoundingBox(Math.min(minX, maxX), this.pos.getY(), Math.min(minZ, maxZ), Math.max(minX, maxX), this.pos.getY() + 3, Math.max(minZ, maxZ)));

				for(Entity e : list) {
					if(e == MainRegistry.proxy.me()) {
						e.setInWeb();
					}
				}
			}
		}
	}

	@Override
	public void serialize(ByteBuf buf) {
		super.serialize(buf);
		buf.writeLong(power);
		buf.writeByte((byte) afterburner);
		buf.writeBoolean(wasOn);
		buf.writeBoolean(showBlood);
		tank.serialize(buf);
		blood.serialize(buf);
	}

	@Override
	public void deserialize(ByteBuf buf) {
		super.deserialize(buf);
		this.power = buf.readLong();
		this.afterburner = buf.readByte();
		this.wasOn = buf.readBoolean();
		this.showBlood = buf.readBoolean();
		tank.deserialize(buf);
		blood.deserialize(buf);
	}

	public AudioWrapper createAudioLoop() {
		return MainRegistry.proxy.getLoopedSound("hbm:block.turbofanOperate", this.pos.getX(), this.pos.getY(), this.pos.getZ(), 1.0F, 50F, 1.0F, 20);
	}

	@Override
	public void onChunkUnload() {

		if(audio != null) {
			audio.stopSound();
			audio = null;
		}
	}

	@Override
	public void invalidate() {

		super.invalidate();

		if(audio != null) {
			audio.stopSound();
			audio = null;
		}
	}

	@Override
	public long getPower() {
		return power;
	}

	@Override
	public long getMaxPower() {
		return maxPower;
	}

	@Override
	public void setPower(long i) {
		this.power = i;
	}

	@Override
	public AxisAlignedBB getRenderBoundingBox() {
		return TileEntity.INFINITE_EXTENT_AABB;
	}

	@Override
	@SideOnly(Side.CLIENT)
	public double getMaxRenderDistanceSquared() {
		return 65536.0D;
	}

	@Override
	public FluidTank[] getReceivingTanks() {
		return new FluidTank[] { tank };
	}

	@Override
	public FluidTank[] getSendingTanks() {
		return new FluidTank[] { blood };
	}

	@Override
	public FluidTank[] getAllTanks() {
		return new FluidTank[] { tank, blood, smoke, smoke_leaded, smoke_poison };
	}

	@Override
	public Container provideContainer(int ID, EntityPlayer player, World world, int x, int y, int z) {
		return new ContainerMachineTurbofan(player.inventory, this);
	}

	@Override
	@SideOnly(Side.CLIENT)
	public Object provideGUI(int ID, EntityPlayer player, World world, int x, int y, int z) {
		return new GUIMachineTurbofan(player.inventory, this);
	}

	@Override
	public boolean canProvideInfo(UpgradeType type, int level, boolean extendedInfo) {
		return type == UpgradeType.AFTERBURN;
	}

	@Override
	public void provideInfo(UpgradeType type, int level, List<String> info, boolean extendedInfo) {
		info.add(IUpgradeInfoProvider.getStandardLabel(ModBlocks.machine_turbofan));
		if(type == UpgradeType.AFTERBURN) {
			info.add(TextFormatting.GREEN + I18nUtil.resolveKey(this.KEY_EFFICIENCY, "+" + (int)(level * 100 * (1 + Math.min(level / 3D, 4D))) + "%"));
			info.add(TextFormatting.RED + I18nUtil.resolveKey(this.KEY_CONSUMPTION, "+" + (level * 100) + "%"));
		}
	}

	@Override
	public HashMap<UpgradeType, Integer> getValidUpgrades() {
		HashMap<UpgradeType, Integer> upgrades = new HashMap<>();
		upgrades.put(UpgradeType.AFTERBURN, 3);
		return upgrades;
	}

	@Override
	public void provideExtraInfo(NBTTagCompound data) {
		data.setBoolean(CompatEnergyControl.B_ACTIVE, this.output > 0);
		data.setDouble(CompatEnergyControl.D_CONSUMPTION_MB, this.consumption);
		data.setDouble(CompatEnergyControl.D_OUTPUT_HE, this.output);
	}
}
