package com.hbm.sound;

import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.audio.SoundList;
import net.minecraft.client.audio.SoundListSerializer;
import net.minecraft.client.resources.IResource;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.resources.IResourceManagerReloadListener;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** Retains the original sounds.json category metadata that native SoundHandler no longer reads. */
public final class SoundCategoryResolver implements IResourceManagerReloadListener {

	private static final Logger LOGGER = LogManager.getLogger();
	private static final Gson SOUND_LISTS = new GsonBuilder().registerTypeAdapter(SoundList.class, new SoundListSerializer()).create();
	private static volatile Map<ResourceLocation, SoundCategory> categories = Collections.emptyMap();

	public static SoundCategory get(ResourceLocation sound) {
		SoundCategory category = categories.get(sound);
		return category == null ? SoundCategory.MASTER : category;
	}

	@Override
	public void onResourceManagerReload(IResourceManager manager) {
		Map<ResourceLocation, SoundCategory> loaded = new LinkedHashMap<>();
		for(String namespace : manager.getResourceDomains()) {
			ResourceLocation source = new ResourceLocation(namespace, "sounds.json");
			try {
				for(IResource resource : manager.getAllResources(source)) {
					try(IResource closeable = resource;
						InputStreamReader reader = new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8)) {
						JsonObject entries = new JsonParser().parse(reader).getAsJsonObject();
						Map<ResourceLocation, SoundCategory> next = new LinkedHashMap<>(loaded);
						for(Map.Entry<String, JsonElement> entry : entries.entrySet()) {
							// Keep metadata from a malformed pack out of the snapshot too.
							// Native parsing validates the sound definitions; this listener never loads samples.
							SOUND_LISTS.fromJson(entry.getValue(), SoundList.class);
							JsonObject definition = JsonUtils.getJsonObject(entry.getValue(), entry.getKey());
							SoundCategory category = SoundCategory.getByName(JsonUtils.getString(definition, "category", "master"));
							if(category == null) throw new IllegalArgumentException("Invalid sound category: " + entry.getKey());
							ResourceLocation sound = new ResourceLocation(namespace, entry.getKey());
							// Original SoundHandler retained the first category when appending samples.
							if(!next.containsKey(sound) || JsonUtils.getBoolean(definition, "replace", false)) next.put(sound, category);
						}
						loaded = next;
					} catch(RuntimeException invalid) {
						LOGGER.warn("Invalid sound category metadata in {} from {}", source, resource.getResourcePackName(), invalid);
					}
				}
			} catch(IOException missing) {
				// A resource domain need not contain sounds.json, just as in SoundHandler.
			}
		}
		categories = Collections.unmodifiableMap(loaded);
	}
}
