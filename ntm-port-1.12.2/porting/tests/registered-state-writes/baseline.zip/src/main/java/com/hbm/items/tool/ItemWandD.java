package com.hbm.items.tool;

import java.util.List;
import java.util.Random;

import com.hbm.blocks.ModBlocks;
import com.hbm.config.SpaceConfig;
import com.hbm.dim.CelestialBody;
import com.hbm.dim.CelestialTeleporter;
import com.hbm.dim.SolarSystem;
import com.hbm.dim.orbit.WorldProviderOrbit;
import com.hbm.dim.trait.CBT_Atmosphere;
import com.hbm.dim.trait.CBT_Atmosphere.FluidEntry;
import com.hbm.entity.missile.EntityBobmazon;
import com.hbm.entity.missile.EntityCombatDropPod;
import com.hbm.entity.mob.glyphid.EntityGlyphid;
import com.hbm.dim.trait.CBT_Destroyed;
import com.hbm.lib.Library;

import net.minecraft.entity.EntityList;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;

public class ItemWandD extends Item {


	@Override
	public ItemStack onItemRightClick(ItemStack stack, World world, EntityPlayer player) {

		if(world.isRemote)
			return stack;

		RayTraceResult pos = Library.rayTrace(player, 500, 1, false, true, false);

		if(pos != null) {

			if(stack.getTagCompound() == null)
				stack.setTagCompound(new NBTTagCompound());

			if(!player.isSneaking()) {
				int targetId = stack.getTagCompound().getInteger("dim");

				if(targetId == 0) {
					CelestialTeleporter.teleport(player, SpaceConfig.orbitDimension, player.posX, 128, player.posZ, false);
					player.sendMessage(new TextComponentString("Teleported to: ORBIT"));
				} else {
					SolarSystem.Body target = SolarSystem.Body.values()[targetId];

					CelestialTeleporter.teleport(player, target.getBody().dimensionId, player.posX, 300, player.posZ, true);
					player.sendMessage(new TextComponentString("Teleported to: " + target.getBody().getUnlocalizedName()));
				}

			} else {

				
				int targetId = stack.getTagCompound().getInteger("dim");
				targetId++;

				if(targetId >= SolarSystem.Body.values().length) {
					targetId = 0;
				}

				stack.getTagCompound().setInteger("dim", targetId);

				if(targetId == 0) {
					player.sendMessage(new TextComponentString("Set teleport target to: ORBIT"));
				} else {
					SolarSystem.Body target = SolarSystem.Body.values()[targetId];
					player.sendMessage(new TextComponentString("Set teleport target to: " + target.getBody().getUnlocalizedName()));
				}
			}
		} else if(!(world.provider instanceof WorldProviderOrbit)) {
			if(!player.isSneaking()) {
				// TESTING: View atmospheric data
				CBT_Atmosphere atmosphere = CelestialBody.getTrait(world, CBT_Atmosphere.class);

				boolean isVacuum = true;
				if(atmosphere != null) {
					for(FluidEntry entry : atmosphere.fluids) {
						// if(entry.pressure > 0.001) {
							player.sendMessage(new TextComponentString("Atmosphere: " + entry.fluid.getUnlocalizedName() + " - " + entry.pressure + "bar"));
							isVacuum = false;
						// }
					}
				}

				if(isVacuum)
					player.sendMessage(new TextComponentString("Atmosphere: NEAR VACUUM"));
			} else {
				CelestialBody star = CelestialBody.getStar(world);

				if(!star.hasTrait(CBT_Destroyed.class)) {

					// TESTING: END OF TIME
					star.modifyTraits(new CBT_Destroyed());

					// TESTING: END OF LIFE
					CelestialBody.degas(world);

					// GOD
					// DAMN
					player.sendMessage(new TextComponentString(TextFormatting.RED + "GOD"));
					player.sendMessage(new TextComponentString(TextFormatting.RED + "DAMN"));
					player.sendMessage(new TextComponentString(TextFormatting.RED + "THE"));
					player.sendMessage(new TextComponentString(TextFormatting.RED + "" + TextFormatting.OBFUSCATED + "SUN"));
				} else {

					star.clearTraits();
					CelestialBody.clearTraits(world);

					player.sendMessage(new TextComponentString("kidding"));
				}
			}
		} else {
			world.setBlock(MathHelper.floor(player.posX), MathHelper.floor(player.posY) - 1, MathHelper.floor(player.posZ), ModBlocks.concrete);
		}

		return stack;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void addInformation(ItemStack stack, net.minecraft.world.World tooltipWorld, List<String> list, net.minecraft.client.util.ITooltipFlag tooltipFlag) {
		list.add("Dimension teleporter and atmosphere debugger.");

		if(stack.getTagCompound() != null) {
			int targetId = stack.getTagCompound().getInteger("dim");
			if(targetId == 0) {
				list.add("Teleportation target: ORBIT");
			} else {
				SolarSystem.Body target = SolarSystem.Body.values()[targetId];
				list.add("Teleportation target: " + target.getBody().getUnlocalizedName());
			}
		}
	}
}
