package com.hbm.items.tool;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.lwjgl.input.Keyboard;

import com.hbm.blocks.ILookOverlay;
import com.hbm.blocks.ModBlocks;
import com.hbm.blocks.network.BlockConveyorBase;
import com.hbm.blocks.network.BlockConveyorBendable;
import com.hbm.blocks.network.BlockCraneBase;
import com.hbm.main.MainRegistry;
import com.hbm.render.util.RenderOverhead;
import com.hbm.util.i18n.I18nUtil;
import com.hbm.wiaj.WorldInAJar;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.play.server.SPacketBlockChange;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Pre;
import net.minecraftforge.common.ForgeHooks;
import com.hbm.lib.ForgeDirection;

public class ItemConveyorWand extends Item implements ILookOverlay {

	public ItemConveyorWand() {
		setHasSubtypes(true);
	}

	public static enum ConveyorType {
		REGULAR,
		EXPRESS,
		DOUBLE,
		TRIPLE
	}

	public static ConveyorType getType(ItemStack stack) {
		if(stack == null) return ConveyorType.REGULAR;
		return ConveyorType.values()[stack.getItemDamage()];
	}

	public static Block getConveyorBlock(ConveyorType type) {
		switch(type) {
		case EXPRESS: return ModBlocks.conveyor_express;
		case DOUBLE: return ModBlocks.conveyor_double;
		case TRIPLE: return ModBlocks.conveyor_triple;
		default: return ModBlocks.conveyor;
		}
	}

	public static boolean hasSnakesAndLadders(ConveyorType type) {
		return type == ConveyorType.REGULAR;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	@SideOnly(Side.CLIENT)
	public void getSubItems(CreativeTabs tab, NonNullList<ItemStack> list) {
		for(ConveyorType type : ConveyorType.values()) {
			list.add(new ItemStack(this, 1, type.ordinal()));
		}
	}

	@Override
	public String getTranslationKey(ItemStack stack) {
		return super.getTranslationKey() + "." + getType(stack).name().toLowerCase(Locale.US);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void addInformation(ItemStack stack, World world, List<String> list, ITooltipFlag flag) {

		if(Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
			for(String s : I18nUtil.resolveKeyArray(super.getTranslationKey(stack) + ".desc")) {
				list.add(TextFormatting.YELLOW + s);
			}
			if(hasSnakesAndLadders(getType(stack))) {
				list.add(TextFormatting.AQUA + I18nUtil.resolveKey(super.getTranslationKey(stack) + ".vertical.desc"));
			}
		} else {
			list.add(TextFormatting.DARK_GRAY + "" + TextFormatting.ITALIC + "Hold <" + TextFormatting.YELLOW + "" + TextFormatting.ITALIC + "LSHIFT" + TextFormatting.DARK_GRAY
					+ "" + TextFormatting.ITALIC + "> to display more info");
		}
	}

	@Override
	public EnumActionResult onItemUse(EntityPlayer player, World world, BlockPos pos, EnumHand hand, EnumFacing facing, float fx, float fy, float fz) {
		ItemStack stack = player.getHeldItem(hand);
		int x = pos.getX(), y = pos.getY(), z = pos.getZ(), side = facing.getIndex();
		if(player.isSneaking() && !stack.hasTagCompound()) {
			ForgeDirection dir = ForgeDirection.getOrientation(side);
			IBlockState onState = world.getBlockState(new BlockPos(x, y, z));
			Block onBlock = onState.getBlock();
			int onMeta = onBlock.getMetaFromState(onState);
			ConveyorType type = getType(stack);

			if(hasSnakesAndLadders(type) && onBlock == ModBlocks.conveyor && onMeta < 6) {
				if(dir == ForgeDirection.UP) {
					onBlock = ModBlocks.conveyor_lift;
					world.setBlockState(new BlockPos(x, y, z), onBlock.getStateFromMeta(onMeta), 3);
				} else if(dir == ForgeDirection.DOWN) {
					onBlock = ModBlocks.conveyor_chute;
					world.setBlockState(new BlockPos(x, y, z), onBlock.getStateFromMeta(onMeta), 3);
				}
			}

			Block toPlace = getConveyorBlock(type);
			if(hasSnakesAndLadders(type)) {
				if(onBlock == ModBlocks.conveyor_lift && dir == ForgeDirection.UP) toPlace = ModBlocks.conveyor_lift;
				if(onBlock == ModBlocks.conveyor_chute && dir == ForgeDirection.DOWN) toPlace = ModBlocks.conveyor_chute;
			}

			x += dir.offsetX;
			y += dir.offsetY;
			z += dir.offsetZ;

			if(world.getBlockState(new BlockPos(x, y, z)).getBlock().isReplaceable(world, new BlockPos(x, y, z))) {
				world.setBlockState(new BlockPos(x, y, z), toPlace.getDefaultState());
				toPlace.onBlockPlacedBy(world, new BlockPos(x, y, z), world.getBlockState(new BlockPos(x, y, z)), player, stack);
				stack.shrink(1);
			}

			return EnumActionResult.SUCCESS;
		}

		// If placing on top of a conveyor block, auto-snap to edge if possible
		// this makes it easier to connect without having to click the small edge of a conveyor
		Block onBlock = world.getBlockState(new BlockPos(x, y, z)).getBlock();
		if(onBlock instanceof BlockConveyorBendable) {
			BlockConveyorBase bendable = (BlockConveyorBase) onBlock;
			ForgeDirection moveDir = stack.hasTagCompound() ? bendable.getInputDirection(world, x, y, z) : bendable.getOutputDirection(world, x, y, z);

			int ox = x + moveDir.offsetX;
			int oy = y + moveDir.offsetY;
			int oz = z + moveDir.offsetZ;

			if(world.getBlockState(new BlockPos(ox, oy, oz)).getBlock().isReplaceable(world, new BlockPos(ox, oy, oz))) {
				side = moveDir.ordinal();
			}
		}

		if(!stack.hasTagCompound()) {
			// Starting placement
			NBTTagCompound nbt = new NBTTagCompound();
			stack.setTagCompound(nbt);

			nbt.setInteger("x", x);
			nbt.setInteger("y", y);
			nbt.setInteger("z", z);
			nbt.setInteger("side", side);

			int count = 0;
			if(player.capabilities.isCreativeMode) {
				count = 256;
			} else {
				for(ItemStack inventoryStack : player.inventory.mainInventory) {
					if(inventoryStack != null && inventoryStack.getItem() == this && inventoryStack.getItemDamage() == stack.getItemDamage()) {
						count += inventoryStack.getCount();
					}
				}
			}

			nbt.setInteger("count", count);
		} else {
			// Constructing conveyor
			NBTTagCompound nbt = stack.getTagCompound();

			int sx = nbt.getInteger("x");
			int sy = nbt.getInteger("y");
			int sz = nbt.getInteger("z");
			int sSide = nbt.getInteger("side");
			int count = nbt.getInteger("count");

			if(!world.isRemote) {
				ConveyorType type = getType(stack);

				// pretend to construct, if it doesn't fail, actually construct
				int constructCount = construct(world, null, type, player, sx, sy, sz, sSide, x, y, z, side, 0, 0, 0, count);
				if(constructCount > 0) {
					int toRemove = construct(world, world, type, player, sx, sy, sz, sSide, x, y, z, side, 0, 0, 0, count);

					if(!player.capabilities.isCreativeMode) {
						for(ItemStack inventoryStack : player.inventory.mainInventory) {
							if(inventoryStack != null && inventoryStack.getItem() == this && inventoryStack.getItemDamage() == stack.getItemDamage()) {
								int removing = Math.min(toRemove, inventoryStack.getCount());
								inventoryStack.shrink(removing);
								toRemove -= removing;
							}

							if(toRemove <= 0) break;
						}

						player.inventoryContainer.detectAndSendChanges();
					}

					player.sendMessage(new TextComponentString("Conveyor built!"));
				} else if(constructCount == 0) {
					player.sendMessage(new TextComponentString("Not enough conveyors, build cancelled"));
				} else {
					player.sendMessage(new TextComponentString("Conveyor obstructed, build cancelled"));
				}
			} else {
				RenderOverhead.clearActionPreview();
				lastMop = null;
			}

			stack.setTagCompound(null);
		}

		return EnumActionResult.SUCCESS; // always eat interactions
	}

	private static RayTraceResult lastMop;
	private static int lastSide;
	private static float lastYaw;

	@Override
	public void onUpdate(ItemStack stack, World world, Entity entity, int slot, boolean inHand) {
		if(!(entity instanceof EntityPlayer)) return;
		EntityPlayer player = (EntityPlayer) entity;

		if(!inHand && stack.hasTagCompound()) {
			ItemStack held = player.getHeldItemMainhand();
			if(held == null || held.getItem() != this || held.getItemDamage() != stack.getItemDamage()) {
				stack.setTagCompound(null);
				if(world.isRemote) {
					RenderOverhead.clearActionPreview();
					lastMop = null;
				}
			}
		}

		// clientside prediction only
		if(world.isRemote && inHand) {
			if(!stack.hasTagCompound()) {
				RenderOverhead.clearActionPreview();
				lastMop = null;
				return;
			}

			RayTraceResult mop = Minecraft.getMinecraft().objectMouseOver;
			if(mop == null || mop.typeOfHit != RayTraceResult.Type.BLOCK) {
				RenderOverhead.clearActionPreview();
				lastMop = null;
				return;
			}

			int x = mop.getBlockPos().getX();
			int y = mop.getBlockPos().getY();
			int z = mop.getBlockPos().getZ();
			int side = mop.sideHit.getIndex();

			Block onBlock = world.getBlockState(new BlockPos(x, y, z)).getBlock();
			if(onBlock instanceof BlockConveyorBendable) {
				BlockConveyorBase bendable = (BlockConveyorBase) onBlock;
				ForgeDirection moveDir = bendable.getInputDirection(world, x, y, z);

				int ox = x + moveDir.offsetX;
				int oy = y + moveDir.offsetY;
				int oz = z + moveDir.offsetZ;

				if(world.getBlockState(new BlockPos(ox, oy, oz)).getBlock().isReplaceable(world, new BlockPos(ox, oy, oz))) {
					side = moveDir.ordinal();
				}
			}

			if(lastMop != null && mop.getBlockPos().equals(lastMop.getBlockPos()) && side == lastSide && Math.abs(lastYaw - player.rotationYaw) < 15) return;
			lastMop = mop;
			lastYaw = player.rotationYaw;
			lastSide = side;

			NBTTagCompound nbt = stack.getTagCompound();

			int sx = nbt.getInteger("x");
			int sy = nbt.getInteger("y");
			int sz = nbt.getInteger("z");
			int sSide = nbt.getInteger("side");
			int count = nbt.getInteger("count");

			// Size has a one block buffer on both sides, for overshooting conveyors
			int sizeX = Math.abs(sx - x) + 3;
			int sizeY = Math.abs(sy - y) + 3;
			int sizeZ = Math.abs(sz - z) + 3;

			int minX = Math.min(sx, x) - 1;
			int minY = Math.min(sy, y) - 1;
			int minZ = Math.min(sz, z) - 1;

			WorldInAJar wiaj = new WorldInAJar(sizeX, sizeY, sizeZ);
			boolean pathSuccess = construct(world, wiaj, getType(stack), player, sx, sy, sz, sSide, x, y, z, side, minX, minY, minZ, count) > 0;

			RenderOverhead.setActionPreview(wiaj, minX, minY, minZ, pathSuccess);
		}
	}

	// In creative, auto delete connected conveyors
	@Override
	public boolean onBlockStartBreak(ItemStack stack, BlockPos pos, EntityPlayer playerEntity) {
		int x = pos.getX(), y = pos.getY(), z = pos.getZ();
		if(!playerEntity.isSneaking()) return false;

		World world = playerEntity.world;
		Block block = world.getBlockState(new BlockPos(x, y, z)).getBlock();

		if(!playerEntity.capabilities.isCreativeMode) return false;
		if(!(playerEntity instanceof EntityPlayerMP)) return false;

		EntityPlayerMP player = (EntityPlayerMP) playerEntity;

		if(!world.isRemote && block instanceof BlockConveyorBase) {
			BlockConveyorBase conveyor = (BlockConveyorBase) block;
			ForgeDirection input = conveyor.getInputDirection(world, x, y, z);
			ForgeDirection output = conveyor.getOutputDirection(world, x, y, z);
			breakExtra(world, player, x + input.offsetX, y + input.offsetY, z + input.offsetZ, 32);
			breakExtra(world, player, x + output.offsetX, y + output.offsetY, z + output.offsetZ, 32);
		}

		return false;
	}

	private void breakExtra(World world, EntityPlayerMP player, int x, int y, int z, int depth) {
		depth--;
		if(depth <= 0) return;

		IBlockState state = world.getBlockState(new BlockPos(x, y, z));
		Block block = state.getBlock();
		if(!(block instanceof BlockConveyorBase)) return;

		BlockConveyorBase conveyor = (BlockConveyorBase) block;
		ForgeDirection input = conveyor.getInputDirection(world, x, y, z);
		ForgeDirection output = conveyor.getOutputDirection(world, x, y, z);

		int event = ForgeHooks.onBlockBreakEvent(world, player.interactionManager.getGameType(), player, new BlockPos(x, y, z));
		if(event == -1)
			return;

		block.onBlockHarvested(world, new BlockPos(x, y, z), state, player);
		if(block.removedByPlayer(state, world, new BlockPos(x, y, z), player, false)) {
			block.onPlayerDestroy(world, new BlockPos(x, y, z), state);
		}

		player.connection.sendPacket(new SPacketBlockChange(world, new BlockPos(x, y, z)));
		breakExtra(world, player, x + input.offsetX, y + input.offsetY, z + input.offsetZ, depth);
		breakExtra(world, player, x + output.offsetX, y + output.offsetY, z + output.offsetZ, depth);
	}

	// attempts to construct a conveyor between two points, including bends, lifts, and chutes
	private static int construct(World routeWorld, IBlockAccess buildWorld, ConveyorType type, EntityPlayer player, int x1, int y1, int z1, int side1, int x2, int y2, int z2, int side2, int box, int boy, int boz, int max) {
		ForgeDirection dir = ForgeDirection.getOrientation(side1);
		ForgeDirection targetDir = ForgeDirection.getOrientation(side2);

		// if placing within a single block, we have to handle rotation specially, treating it like a manual placement with player facing
		if(x1 == x2 && y1 == y2 && z1 == z2 && side1 == side2 && (dir == ForgeDirection.UP || dir == ForgeDirection.DOWN)) {
			int meta = getFacingMeta(player);

			y1 += dir.offsetY;

			if(!routeWorld.getBlockState(new BlockPos(x1, y1, z1)).getBlock().isReplaceable(routeWorld, new BlockPos(x1, y1, z1))) return -1;

			Block block = getConveyorBlock(type);
			if(buildWorld instanceof World) {
				((World) buildWorld).setBlockState(new BlockPos(x1 - box, y1 - boy, z1 - boz), block.getStateFromMeta(meta), 3);
			} else if(buildWorld instanceof WorldInAJar) {
				((WorldInAJar) buildWorld).setBlock(x1 - box, y1 - boy, z1 - boz, block, meta);
			}

			return 1;
		}

		boolean hasVertical = hasSnakesAndLadders(type);

		int tx = x2 + targetDir.offsetX;
		int ty = y2 + targetDir.offsetY;
		int tz = z2 + targetDir.offsetZ;

		int x = x1 + dir.offsetX;
		int y = y1 + dir.offsetY;
		int z = z1 + dir.offsetZ;

		if(dir == ForgeDirection.UP || dir == ForgeDirection.DOWN) {
			dir = getTargetDirection(x, y, z, x2, y2, z2, hasVertical);
		}

		Block targetBlock = routeWorld.getBlockState(new BlockPos(x2, y2, z2)).getBlock();
		boolean isTargetHorizontal = targetDir != ForgeDirection.UP && targetDir != ForgeDirection.DOWN;
		boolean shouldTurnToTarget = isTargetHorizontal || targetBlock instanceof BlockCraneBase || targetBlock == ModBlocks.conveyor_lift || targetBlock == ModBlocks.conveyor_chute;

		ForgeDirection horDir = dir == ForgeDirection.UP || dir == ForgeDirection.DOWN ? ForgeDirection.getOrientation(getFacingMeta(player)).getOpposite() : dir;

		// Initial dropdown to floor level, if possible
		if(hasVertical && y > ty) {
			if(routeWorld.getBlockState(new BlockPos(x, y - 1, z)).getBlock().isReplaceable(routeWorld, new BlockPos(x, y - 1, z))) {
				dir = ForgeDirection.DOWN;
			}
		}

		for(int loopDepth = 1; loopDepth <= max; loopDepth++) {
			if(!routeWorld.getBlockState(new BlockPos(x, y, z)).getBlock().isReplaceable(routeWorld, new BlockPos(x, y, z))) return -1;

			Block block = getConveyorForDirection(type, dir);
			int meta = getConveyorMetaForDirection(block, dir, targetDir, horDir);

			int ox = x + dir.offsetX;
			int oy = y + dir.offsetY;
			int oz = z + dir.offsetZ;

			// check if we should turn before continuing
			int fromDistance = taxiDistance(x, y, z, tx, ty, tz);
			int toDistance = taxiDistance(ox, oy, oz, tx, ty, tz);
			int finalDistance = taxiDistance(ox, oy, oz, x2, y2, z2);
			boolean notAtTarget = (shouldTurnToTarget ? finalDistance : fromDistance) > 0;
			boolean willBeObstructed = notAtTarget && !routeWorld.getBlockState(new BlockPos(ox, oy, oz)).getBlock().isReplaceable(routeWorld, new BlockPos(ox, oy, oz));
			boolean shouldTurn = (toDistance >= fromDistance && notAtTarget) || willBeObstructed;

			if(shouldTurn) {
				ForgeDirection newDir = getTargetDirection(x, y, z, shouldTurnToTarget ? x2 : tx, shouldTurnToTarget ? y2 : ty, shouldTurnToTarget ? z2 : tz, tx, ty, tz, dir, willBeObstructed, hasVertical);

				if(newDir == ForgeDirection.UP) {
					block = ModBlocks.conveyor_lift;
				} else if(newDir == ForgeDirection.DOWN) {
					block = ModBlocks.conveyor_chute;
				} else if(dir.getRotation(ForgeDirection.UP) == newDir) {
					meta += 8;
				} else if(dir.getRotation(ForgeDirection.DOWN) == newDir) {
					meta += 4;
				}

				dir = newDir;
				if(dir != ForgeDirection.UP && dir != ForgeDirection.DOWN) horDir = dir;
			}

			if(buildWorld instanceof World) {
				((World) buildWorld).setBlockState(new BlockPos(x - box, y - boy, z - boz), block.getStateFromMeta(meta), 3);
			} else if(buildWorld instanceof WorldInAJar) {
				((WorldInAJar) buildWorld).setBlock(x - box, y - boy, z - boz, block, meta);
			}

			if(x == tx && y == ty && z == tz) return loopDepth;

			x += dir.offsetX;
			y += dir.offsetY;
			z += dir.offsetZ;
		}

		return 0;
	}

	private static int getFacingMeta(EntityPlayer player) {
		int meta = MathHelper.floor(player.rotationYaw * 4.0F / 360.0F + 0.5D) & 3;
		switch(meta) {
			case 0: return 2;
			case 1: return 5;
			case 2: return 3;
			case 3: return 4;
		}
		return 2;
	}

	private static int getConveyorMetaForDirection(Block block, ForgeDirection dir, ForgeDirection targetDir, ForgeDirection horDir) {
		if(block != ModBlocks.conveyor_chute && block != ModBlocks.conveyor_lift) return dir.getOpposite().ordinal();
		if(targetDir == ForgeDirection.UP || targetDir == ForgeDirection.DOWN) return horDir.getOpposite().ordinal();
		return targetDir.ordinal();
	}

	private static Block getConveyorForDirection(ConveyorType type, ForgeDirection dir) {
		if(dir == ForgeDirection.UP) return ModBlocks.conveyor_lift;
		if(dir == ForgeDirection.DOWN) return ModBlocks.conveyor_chute;
		return getConveyorBlock(type);
	}

	private static ForgeDirection getTargetDirection(int x1, int y1, int z1, int x2, int y2, int z2, boolean hasVertical) {
		return getTargetDirection(x1, y1, z1, x2, y2, z2, x2, y2, z2, null, false, hasVertical);
	}

	private static ForgeDirection getTargetDirection(int x1, int y1, int z1, int x2, int y2, int z2, int tx, int ty, int tz, ForgeDirection heading, boolean willBeObstructed, boolean hasVertical) {
		if(hasVertical && (y1 != y2 || y1 != ty) && (willBeObstructed || (x1 == x2 && z1 == z2) || (x1 == tx && z1 == tz))) return y1 > y2 ? ForgeDirection.DOWN : ForgeDirection.UP;

		if(Math.abs(x1 - x2) > Math.abs(z1 - z2)) {
			if(heading == ForgeDirection.EAST || heading == ForgeDirection.WEST) return z1 > z2 ? ForgeDirection.NORTH : ForgeDirection.SOUTH;
			return x1 > x2 ? ForgeDirection.WEST : ForgeDirection.EAST;
		} else {
			if(heading == ForgeDirection.NORTH || heading == ForgeDirection.SOUTH) return x1 > x2 ? ForgeDirection.WEST : ForgeDirection.EAST;
			return z1 > z2 ? ForgeDirection.NORTH : ForgeDirection.SOUTH;
		}
	}

	private static int taxiDistance(int x1, int y1, int z1, int x2, int y2, int z2) {
		return Math.abs(x1 - x2) + Math.abs(y1 - y2) + Math.abs(z1 - z2);
	}

	@Override
	@SideOnly(Side.CLIENT)
	public void printHook(Pre event, World world, int x, int y, int z) {
		EntityPlayer player = MainRegistry.proxy.me();
		if(player == null || !player.isSneaking() || !player.capabilities.isCreativeMode) return;

		Block block = world.getBlockState(new BlockPos(x, y, z)).getBlock();
		if(block instanceof BlockConveyorBase) {
			List<String> text = new ArrayList<>();
			text.add("Break whole conveyor line");
			ILookOverlay.printGeneric(event, I18nUtil.resolveKey(block.getTranslationKey() + ".name"), 0xffff00, 0x404000, text);
		}
	}

}
