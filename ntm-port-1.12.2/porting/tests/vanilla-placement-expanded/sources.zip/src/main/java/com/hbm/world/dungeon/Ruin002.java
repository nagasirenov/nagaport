//Schematic to java Structure by jajo_11 | inspired by "MITHION'S.SCHEMATIC TO JAVA CONVERTINGTOOL"

package com.hbm.world.dungeon;

import java.util.Random;

import com.hbm.blocks.ModBlocks;

import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class Ruin002 {

	Block Block1 = ModBlocks.brick_concrete;
	Block Block4 = ModBlocks.deco_steel;
	Block Block5 = ModBlocks.steel_wall;
	
	public boolean generate_r00(World world, Random rand, int x, int y, int z) {
		
		world.setBlock(x + 0, y + 5, z + 4, Block1, 0, 3);
		world.setBlock(x + 1, y + 5, z + 4, Block1, 0, 3);
		world.setBlock(x + 2, y + 5, z + 4, Block1, 0, 3);
		world.setBlock(x + 3, y + 5, z + 4, Block1, 0, 3);
		world.setBlock(x + 4, y + 5, z + 4, Block1, 0, 3);
		world.setBlock(x + 5, y + 5, z + 4, Block1, 0, 3);
		world.setBlock(x + 6, y + 5, z + 4, Block1, 0, 3);
		world.setBlock(x + 7, y + 5, z + 4, Block1, 0, 3);
		world.setBlock(x + 8, y + 5, z + 4, Block1, 0, 3);
		world.setBlock(x + 9, y + 5, z + 4, Block1, 0, 3);
		world.setBlock(x + 10, y + 5, z + 4, Block1, 0, 3);
		world.setBlock(x + 11, y + 5, z + 4, Block1, 0, 3);
		world.setBlock(x + 12, y + 5, z + 4, Block1, 0, 3);
		world.setBlock(x + 0, y + 5, z + 5, Block1, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 5, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 5, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 5, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 5, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 5, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.CHEST.getStateFromMeta(3), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 5, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.CHEST.getStateFromMeta(3), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 5, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 5, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 5, z + 5, Block1, 0, 3);
		world.setBlock(x + 0, y + 5, z + 6, Block1, 0, 3);
		world.setBlock(x + 1, y + 5, z + 6, ModBlocks.red_cable, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 5, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 5, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 5, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 5, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 5, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 5, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 5, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 5, z + 6, Block1, 0, 3);
		world.setBlock(x + 0, y + 5, z + 7, Block1, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 5, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 5, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 5, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 5, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 5, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 5, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 5, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 5, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 5, z + 7, Block1, 0, 3);
		world.setBlock(x + 0, y + 5, z + 8, Block1, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 5, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 5, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 5, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 5, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 5, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 5, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 5, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 5, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 5, z + 8, Block1, 0, 3);
		world.setBlock(x + 0, y + 5, z + 9, Block1, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 5, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 5, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 5, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 5, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 5, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 5, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 5, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 5, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 5, z + 9, Block1, 0, 3);
		world.setBlock(x + 0, y + 5, z + 10, Block1, 0, 3);
		world.setBlock(x + 1, y + 5, z + 10, ModBlocks.red_cable, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 5, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 5, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 5, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 5, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 5, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 5, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 5, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 5, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 5, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 5, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 5, z + 10, Block1, 0, 3);
		world.setBlock(x + 0, y + 5, z + 11, Block1, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 5, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 5, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 5, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 5, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 5, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 5, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 5, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 5, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 5, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 5, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 5, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 5, z + 11, Block1, 0, 3);
		world.setBlock(x + 0, y + 5, z + 12, Block1, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 5, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 5, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 5, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 5, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 5, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 5, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 5, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 5, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 5, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + 5, z + 12, Block1, 0, 3);
		world.setBlock(x + 12, y + 5, z + 12, Block1, 0, 3);
		world.setBlock(x + 0, y + 5, z + 13, Block1, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 5, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 5, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 5, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 5, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 5, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 5, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 5, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 5, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 5, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 10, y + 5, z + 13, Block1, 0, 3);
		world.setBlock(x + 11, y + 5, z + 13, Block1, 0, 3);
		world.setBlock(x + 12, y + 5, z + 13, Block1, 0, 3);
		world.setBlock(x + 1, y + 5, z + 14, Block1, 0, 3);
		world.setBlock(x + 2, y + 5, z + 14, Block1, 0, 3);
		world.setBlock(x + 3, y + 5, z + 14, Block1, 0, 3);
		world.setBlock(x + 4, y + 5, z + 14, Block1, 0, 3);
		world.setBlock(x + 5, y + 5, z + 14, Block1, 0, 3);
		world.setBlock(x + 6, y + 5, z + 14, Block1, 0, 3);
		world.setBlock(x + 7, y + 5, z + 14, Block1, 0, 3);
		world.setBlock(x + 8, y + 5, z + 14, Block1, 0, 3);
		world.setBlock(x + 9, y + 5, z + 14, Block1, 0, 3);
		world.setBlock(x + 10, y + 5, z + 14, Block1, 0, 3);
		world.setBlock(x + 11, y + 5, z + 14, Block1, 0, 3);
		world.setBlock(x + 0, y + 6, z + 4, Block1, 0, 3);
		world.setBlock(x + 1, y + 6, z + 4, Block1, 0, 3);
		world.setBlock(x + 2, y + 6, z + 4, Block1, 0, 3);
		world.setBlock(x + 3, y + 6, z + 4, Block1, 0, 3);
		world.setBlock(x + 4, y + 6, z + 4, Block1, 0, 3);
		world.setBlock(x + 5, y + 6, z + 4, Block1, 0, 3);
		world.setBlock(x + 6, y + 6, z + 4, Block1, 0, 3);
		world.setBlock(x + 7, y + 6, z + 4, Block1, 0, 3);
		world.setBlock(x + 8, y + 6, z + 4, Block1, 0, 3);
		world.setBlock(x + 9, y + 6, z + 4, Block1, 0, 3);
		world.setBlock(x + 10, y + 6, z + 4, Block1, 0, 3);
		world.setBlock(x + 11, y + 6, z + 4, Block1, 0, 3);
		world.setBlock(x + 12, y + 6, z + 4, Block1, 0, 3);
		world.setBlock(x + 0, y + 6, z + 5, Block1, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 6, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 6, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 6, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 6, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 6, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 6, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 6, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 6, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 6, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 6, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 6, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 6, z + 5, Block1, 0, 3);
		world.setBlock(x + 0, y + 6, z + 6, Block1, 0, 3);
		world.setBlock(x + 1, y + 6, z + 6, ModBlocks.red_cable, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 6, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 6, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 6, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 6, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 6, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 6, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 6, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 6, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 6, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 6, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 6, z + 6, Block1, 0, 3);
		world.setBlock(x + 0, y + 6, z + 7, Block1, 0, 3);
		world.setBlock(x + 1, y + 6, z + 7, ModBlocks.red_cable, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 6, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 6, z + 7, Block1, 0, 3);
		world.setBlock(x + 0, y + 6, z + 8, Block1, 0, 3);
		world.setBlock(x + 1, y + 6, z + 8, ModBlocks.red_cable, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 6, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 6, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 6, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 6, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 6, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 6, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 6, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 6, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 6, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 6, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 6, z + 8, Block1, 0, 3);
		world.setBlock(x + 0, y + 6, z + 9, Block1, 0, 3);
		world.setBlock(x + 1, y + 6, z + 9, ModBlocks.cable_switch, 1, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 6, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 6, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 6, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 6, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 6, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 6, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 6, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 6, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 6, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 6, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 6, z + 9, Block1, 0, 3);
		world.setBlock(x + 0, y + 6, z + 10, Block1, 0, 3);
		world.setBlock(x + 1, y + 6, z + 10, ModBlocks.red_cable, 0, 3);
		world.setBlock(x + 2, y + 6, z + 10, ModBlocks.red_cable, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 6, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 6, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 6, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 6, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 6, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 6, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 6, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 6, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 6, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 6, z + 10, Block1, 0, 3);
		world.setBlock(x + 0, y + 6, z + 11, Block1, 0, 3);
		world.setBlock(x + 1, y + 6, z + 11, ModBlocks.red_cable, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 6, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 6, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 6, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 6, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 6, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 6, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 6, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 6, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 6, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 6, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 12, y + 6, z + 11, Block1, 0, 3);
		world.setBlock(x + 0, y + 6, z + 12, Block1, 0, 3);
		world.setBlock(x + 1, y + 6, z + 12, ModBlocks.red_cable, 0, 3);
		world.setBlock(x + 2, y + 6, z + 12, ModBlocks.red_cable, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 6, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 6, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 6, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 6, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 6, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 6, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 6, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 11, y + 6, z + 12, Block1, 0, 3);
		world.setBlock(x + 12, y + 6, z + 12, Block1, 0, 3);
		world.setBlock(x + 0, y + 6, z + 13, Block1, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 6, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 6, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WEB.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 6, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 6, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 6, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 6, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 6, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 6, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 6, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 10, y + 6, z + 13, Block1, 0, 3);
		world.setBlock(x + 11, y + 6, z + 13, Block1, 0, 3);
		world.setBlock(x + 12, y + 6, z + 13, Block1, 0, 3);
		world.setBlock(x + 1, y + 6, z + 14, Block1, 0, 3);
		world.setBlock(x + 2, y + 6, z + 14, Block1, 0, 3);
		world.setBlock(x + 3, y + 6, z + 14, Block1, 0, 3);
		world.setBlock(x + 4, y + 6, z + 14, Block1, 0, 3);
		world.setBlock(x + 5, y + 6, z + 14, Block1, 0, 3);
		world.setBlock(x + 6, y + 6, z + 14, Block1, 0, 3);
		world.setBlock(x + 7, y + 6, z + 14, Block1, 0, 3);
		world.setBlock(x + 8, y + 6, z + 14, Block1, 0, 3);
		world.setBlock(x + 9, y + 6, z + 14, Block1, 0, 3);
		world.setBlock(x + 10, y + 6, z + 14, Block1, 0, 3);
		world.setBlock(x + 11, y + 6, z + 14, Block1, 0, 3);
		world.setBlock(x + 0, y + 7, z + 4, Block1, 0, 3);
		world.setBlock(x + 1, y + 7, z + 4, Block1, 0, 3);
		world.setBlock(x + 2, y + 7, z + 4, Block1, 0, 3);
		world.setBlock(x + 3, y + 7, z + 4, Block1, 0, 3);
		world.setBlock(x + 4, y + 7, z + 4, Block1, 0, 3);
		world.setBlock(x + 5, y + 7, z + 4, Block1, 0, 3);
		world.setBlock(x + 6, y + 7, z + 4, Block1, 0, 3);
		world.setBlock(x + 7, y + 7, z + 4, Block1, 0, 3);
		world.setBlock(x + 8, y + 7, z + 4, Block1, 0, 3);
		world.setBlock(x + 9, y + 7, z + 4, Block1, 0, 3);
		world.setBlock(x + 10, y + 7, z + 4, Block1, 0, 3);
		world.setBlock(x + 11, y + 7, z + 4, Block1, 0, 3);
		world.setBlock(x + 0, y + 7, z + 5, Block1, 0, 3);
		world.setBlock(x + 1, y + 7, z + 5, Block1, 0, 3);
		world.setBlock(x + 2, y + 7, z + 5, Block1, 0, 3);
		world.setBlock(x + 3, y + 7, z + 5, Block1, 0, 3);
		world.setBlock(x + 4, y + 7, z + 5, Block1, 0, 3);
		world.setBlock(x + 5, y + 7, z + 5, Block1, 0, 3);
		world.setBlock(x + 6, y + 7, z + 5, Block1, 0, 3);
		world.setBlock(x + 7, y + 7, z + 5, Block1, 0, 3);
		world.setBlock(x + 8, y + 7, z + 5, Block1, 0, 3);
		world.setBlock(x + 9, y + 7, z + 5, Block1, 0, 3);
		world.setBlock(x + 10, y + 7, z + 5, Block1, 0, 3);
		world.setBlock(x + 11, y + 7, z + 5, Block1, 0, 3);
		world.setBlock(x + 0, y + 7, z + 6, Block1, 0, 3);
		world.setBlock(x + 1, y + 7, z + 6, Block1, 0, 3);
		world.setBlock(x + 2, y + 7, z + 6, Block1, 0, 3);
		world.setBlock(x + 3, y + 7, z + 6, Block1, 0, 3);
		world.setBlock(x + 4, y + 7, z + 6, Block1, 0, 3);
		world.setBlock(x + 5, y + 7, z + 6, Block1, 0, 3);
		world.setBlock(x + 6, y + 7, z + 6, Block1, 0, 3);
		world.setBlock(x + 7, y + 7, z + 6, Block1, 0, 3);
		world.setBlock(x + 8, y + 7, z + 6, Block1, 0, 3);
		world.setBlock(x + 9, y + 7, z + 6, Block1, 0, 3);
		world.setBlock(x + 10, y + 7, z + 6, Block1, 0, 3);
		world.setBlock(x + 11, y + 7, z + 6, Block1, 0, 3);
		world.setBlock(x + 0, y + 7, z + 7, Block1, 0, 3);
		world.setBlock(x + 1, y + 7, z + 7, Block1, 0, 3);
		world.setBlock(x + 2, y + 7, z + 7, Block1, 0, 3);
		world.setBlock(x + 3, y + 7, z + 7, Block1, 0, 3);
		world.setBlock(x + 4, y + 7, z + 7, Block1, 0, 3);
		world.setBlock(x + 5, y + 7, z + 7, Block1, 0, 3);
		world.setBlock(x + 6, y + 7, z + 7, Block1, 0, 3);
		world.setBlock(x + 7, y + 7, z + 7, Block1, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 7, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 9, y + 7, z + 7, Block1, 0, 3);
		world.setBlock(x + 10, y + 7, z + 7, Block1, 0, 3);
		world.setBlock(x + 11, y + 7, z + 7, Block1, 0, 3);
		world.setBlock(x + 0, y + 7, z + 8, Block1, 0, 3);
		world.setBlock(x + 1, y + 7, z + 8, Block1, 0, 3);
		world.setBlock(x + 2, y + 7, z + 8, Block1, 0, 3);
		world.setBlock(x + 3, y + 7, z + 8, Block1, 0, 3);
		world.setBlock(x + 4, y + 7, z + 8, Block1, 0, 3);
		world.setBlock(x + 5, y + 7, z + 8, Block1, 0, 3);
		world.setBlock(x + 6, y + 7, z + 8, Block1, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 7, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 7, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 9, y + 7, z + 8, Block1, 0, 3);
		world.setBlock(x + 10, y + 7, z + 8, Block1, 0, 3);
		world.setBlock(x + 11, y + 7, z + 8, Block1, 0, 3);
		world.setBlock(x + 0, y + 7, z + 9, Block1, 0, 3);
		world.setBlock(x + 1, y + 7, z + 9, Block1, 0, 3);
		world.setBlock(x + 2, y + 7, z + 9, Block1, 0, 3);
		world.setBlock(x + 3, y + 7, z + 9, Block1, 0, 3);
		world.setBlock(x + 4, y + 7, z + 9, Block1, 0, 3);
		world.setBlock(x + 5, y + 7, z + 9, Block1, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 7, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 7, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 7, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 7, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 10, y + 7, z + 9, Block1, 0, 3);
		world.setBlock(x + 11, y + 7, z + 9, Block1, 0, 3);
		world.setBlock(x + 0, y + 7, z + 10, Block1, 0, 3);
		world.setBlock(x + 1, y + 7, z + 10, Block1, 0, 3);
		world.setBlock(x + 2, y + 7, z + 10, ModBlocks.red_cable, 0, 3);
		world.setBlock(x + 3, y + 7, z + 10, Block1, 0, 3);
		world.setBlock(x + 4, y + 7, z + 10, Block1, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 7, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 7, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 7, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 7, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 7, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 10, y + 7, z + 10, Block1, 0, 3);
		world.setBlock(x + 11, y + 7, z + 10, Block1, 0, 3);
		world.setBlock(x + 0, y + 7, z + 11, Block1, 0, 3);
		world.setBlock(x + 1, y + 7, z + 11, Block1, 0, 3);
		world.setBlock(x + 2, y + 7, z + 11, Block1, 0, 3);
		world.setBlock(x + 3, y + 7, z + 11, Block1, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 7, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 7, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 7, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 7, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 7, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 9, y + 7, z + 11, Block1, 0, 3);
		world.setBlock(x + 10, y + 7, z + 11, Block1, 0, 3);
		world.setBlock(x + 11, y + 7, z + 11, Block1, 0, 3);
		world.setBlock(x + 0, y + 7, z + 12, Block1, 0, 3);
		world.setBlock(x + 1, y + 7, z + 12, Block1, 0, 3);
		world.setBlock(x + 2, y + 7, z + 12, ModBlocks.red_cable, 0, 3);
		world.setBlock(x + 3, y + 7, z + 12, Block1, 0, 3);
		world.setBlock(x + 4, y + 7, z + 12, Block1, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 7, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 6, y + 7, z + 12, Block1, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 7, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 8, y + 7, z + 12, Block1, 0, 3);
		world.setBlock(x + 9, y + 7, z + 12, Block1, 0, 3);
		world.setBlock(x + 11, y + 7, z + 12, Block1, 0, 3);
		world.setBlock(x + 0, y + 7, z + 13, Block1, 0, 3);
		world.setBlock(x + 1, y + 7, z + 13, Block1, 0, 3);
		world.setBlock(x + 2, y + 7, z + 13, Block1, 0, 3);
		world.setBlock(x + 3, y + 7, z + 13, Block1, 0, 3);
		world.setBlock(x + 4, y + 7, z + 13, Block1, 0, 3);
		world.setBlock(x + 5, y + 7, z + 13, Block1, 0, 3);
		world.setBlock(x + 6, y + 7, z + 13, Block1, 0, 3);
		world.setBlock(x + 7, y + 7, z + 13, Block1, 0, 3);
		world.setBlock(x + 8, y + 7, z + 13, Block1, 0, 3);
		world.setBlock(x + 9, y + 7, z + 13, Block1, 0, 3);
		world.setBlock(x + 10, y + 7, z + 13, Block1, 0, 3);
		world.setBlock(x + 11, y + 7, z + 13, Block1, 0, 3);
		world.setBlock(x + 1, y + 7, z + 14, Block1, 0, 3);
		world.setBlock(x + 2, y + 7, z + 14, Block1, 0, 3);
		world.setBlock(x + 3, y + 7, z + 14, Block1, 0, 3);
		world.setBlock(x + 4, y + 7, z + 14, Block1, 0, 3);
		world.setBlock(x + 5, y + 7, z + 14, Block1, 0, 3);
		world.setBlock(x + 6, y + 7, z + 14, Block1, 0, 3);
		world.setBlock(x + 7, y + 7, z + 14, Block1, 0, 3);
		world.setBlock(x + 8, y + 7, z + 14, Block1, 0, 3);
		world.setBlock(x + 9, y + 7, z + 14, Block1, 0, 3);
		world.setBlock(x + 10, y + 7, z + 14, Block1, 0, 3);
		world.setBlock(x + 11, y + 7, z + 14, Block1, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 8, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 8, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 8, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 8, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 8, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 8, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 8, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 8, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 8, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 8, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 8, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 8, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 8, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 8, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 8, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 8, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 8, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 8, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 8, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 8, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 8, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 8, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 8, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 8, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 8, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 8, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 8, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 8, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 8, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 8, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 8, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_SLAB.getStateFromMeta(3), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 8, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 8, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 8, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 8, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(3), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 8, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 8, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 8, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 8, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 8, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 8, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 8, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 8, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 8, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 8, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 8, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 8, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 8, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 8, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DIRT.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 8, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 8, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 8, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 8, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 8, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 8, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 8, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 8, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 8, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 8, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 8, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 8, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DIRT.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 8, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 8, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(15), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 8, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 8, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(15), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 8, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.PLANKS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 8, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.SPRUCE_STAIRS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 8, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.PLANKS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 8, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.PLANKS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 8, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.SPRUCE_STAIRS.getStateFromMeta(3), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 8, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.SPRUCE_STAIRS.getStateFromMeta(3), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 8, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 8, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DIRT.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 8, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 8, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 8, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(15), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 8, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 8, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.PLANKS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 8, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.SPRUCE_STAIRS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 8, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 8, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 8, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.SPRUCE_STAIRS.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 8, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.SPRUCE_STAIRS.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 8, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(5), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 8, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DIRT.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 8, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 8, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(15), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 8, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 8, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(15), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 8, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.PLANKS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 8, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.PLANKS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 8, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 8, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 8, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.PLANKS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 8, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 8, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 8, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRASS.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 8, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 8, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 8, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(15), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 8, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 8, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.SPRUCE_STAIRS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 8, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 8, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 8, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 8, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.PLANKS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 8, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.PLANKS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 8, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 8, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRASS.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 8, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		world.setBlock(x + 2, y + 8, z + 10, ModBlocks.red_cable, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 8, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 8, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(15), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 8, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 8, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 8, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 8, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 8, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.PLANKS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 8, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.PLANKS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 8, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 8, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRASS.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 8, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 8, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 8, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(15), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 8, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 8, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 8, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 8, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 8, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 8, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.PLANKS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 8, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.PLANKS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 8, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 8, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRASS.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 8, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		world.setBlock(x + 2, y + 8, z + 12, ModBlocks.red_cable, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 8, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 8, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_HARDENED_CLAY.getStateFromMeta(15), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 8, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 8, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.SPRUCE_STAIRS.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 8, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.SPRUCE_STAIRS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 8, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.PLANKS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 8, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.PLANKS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 8, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.TRAPDOOR.getStateFromMeta(13), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 8, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 8, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DIRT.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 8, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 8, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 8, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 8, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 8, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 8, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 8, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 8, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 8, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 8, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 8, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 8, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DIRT.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 8, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRASS.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 8, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DIRT.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 8, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DIRT.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 8, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DIRT.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 8, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.GRASS.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 8, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DIRT.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 8, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DIRT.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 8, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DIRT.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 8, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DIRT.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 9, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 9, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 9, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 9, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 9, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 9, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 9, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 9, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 9, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 9, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 9, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 9, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 9, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 9, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 9, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 9, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 9, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 9, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 9, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 9, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 9, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 9, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 9, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 9, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 9, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 9, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 9, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 9, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 9, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 9, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 9, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 9, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 9, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 9, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 9, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 9, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 9, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 9, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 9, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 9, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 9, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 9, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 9, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 9, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 9, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 9, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 9, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 9, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 9, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 9, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 9, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 9, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 9, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 9, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 9, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 9, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		world.setBlock(x + 6, y + 9, z + 5, Blocks.DIAMOND_BLOCK, 5, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 9, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 9, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 9, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 9, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 9, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 9, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 9, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 9, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 9, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.IRON_BLOCK.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 9, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.IRON_DOOR.getStateFromMeta(0), 3); }
		world.setBlock(x + 4, y + 9, z + 6, Block4, 0, 3);
		world.setBlock(x + 5, y + 9, z + 6, Block5, 5, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 9, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 9, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 9, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 9, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 9, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.CHEST.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 9, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 9, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 9, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 9, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		world.setBlock(x + 2, y + 9, z + 7, Block4, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 9, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 4, y + 9, z + 7, Block4, 0, 3);
		world.setBlock(x + 5, y + 9, z + 7, Block5, 5, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 9, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 9, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 9, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 9, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 9, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 9, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 9, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 9, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 9, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 9, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.CAULDRON.getStateFromMeta(3), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 9, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 4, y + 9, z + 8, Block4, 0, 3);
		world.setBlock(x + 5, y + 9, z + 8, Block5, 5, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 9, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 9, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 9, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 9, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 9, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 9, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 9, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 9, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		world.setBlock(x + 2, y + 9, z + 9, Block4, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 9, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		world.setBlock(x + 4, y + 9, z + 9, Block4, 0, 3);
		world.setBlock(x + 5, y + 9, z + 9, Block5, 5, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 9, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 9, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 9, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 9, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 9, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 9, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 9, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 9, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		world.setBlock(x + 2, y + 9, z + 10, Blocks.LIT_REDSTONE_LAMP, 5, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 9, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 9, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 9, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 9, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 9, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 9, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 9, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.SPRUCE_STAIRS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 9, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.NETHER_BRICK_FENCE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 9, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 9, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 9, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		world.setBlock(x + 2, y + 9, z + 11, Block4, 0, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 9, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 9, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 9, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 9, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 9, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 9, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 9, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.SPRUCE_STAIRS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 9, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.NETHER_BRICK_FENCE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 9, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 9, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 9, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		world.setBlock(x + 2, y + 9, z + 12, Blocks.LIT_REDSTONE_LAMP, 5, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 9, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 9, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 9, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 9, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 9, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 9, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 9, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 9, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 9, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(5), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 9, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 9, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 9, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 9, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 9, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 9, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(3), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 9, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 9, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 9, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 9, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 9, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 9, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.MOSSY_COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 9, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 9, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 9, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 9, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 9, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 9, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 9, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 9, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 9, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 9, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 9, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 10, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 10, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 10, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 10, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 10, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 10, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 10, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 10, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 10, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 10, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 10, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 10, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 10, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 10, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 10, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 10, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 10, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 10, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 10, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 10, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 10, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 10, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 10, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 10, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 10, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 10, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 10, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 10, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 10, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 10, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 10, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 10, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 10, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 10, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 10, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 10, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 10, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 10, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 10, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 10, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 10, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 10, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 10, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 10, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 10, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 10, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 10, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 10, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 10, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 10, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 10, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 10, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 10, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 10, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 10, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_SLAB.getStateFromMeta(3), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 10, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		world.setBlock(x + 6, y + 10, z + 5, Blocks.DIAMOND_BLOCK, 8, 3);
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 10, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 10, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 10, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_SLAB.getStateFromMeta(3), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 10, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 10, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 10, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 10, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 10, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 10, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DISPENSER.getStateFromMeta(5), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 10, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.IRON_DOOR.getStateFromMeta(8), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 10, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.FLOWER_POT.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 10, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 10, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 10, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 10, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 10, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 10, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 10, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 10, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 10, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 10, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 10, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 10, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 10, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 10, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 10, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 10, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 10, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 10, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 10, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 10, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 10, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 10, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 10, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 10, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 10, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 10, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 10, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 10, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 10, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 10, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 10, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 10, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 10, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 10, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 10, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 10, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 10, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 10, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 10, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 10, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 10, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 10, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 10, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 10, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_SLAB.getStateFromMeta(3), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 10, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 10, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 10, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 10, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 10, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 10, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 10, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 10, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 10, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 10, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 10, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 10, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 10, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 10, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 10, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 10, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 10, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 10, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 10, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 10, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 10, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 10, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 10, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 10, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 10, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 10, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 10, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 10, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 10, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 10, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 10, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 10, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 10, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 10, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 10, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 10, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_SLAB.getStateFromMeta(3), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 10, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 10, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 10, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 10, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 10, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(7), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 10, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 10, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_GLASS.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 10, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 10, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_GLASS.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 10, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 10, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 10, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 10, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 10, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 10, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 10, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 10, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 10, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 10, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 10, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 10, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 10, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 10, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 10, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 10, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 11, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 11, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 11, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 11, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 11, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 11, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 11, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 11, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 11, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 11, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 11, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 11, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 11, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 11, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 11, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 11, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 11, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 11, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 11, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 11, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 11, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 11, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 11, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 11, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 11, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 11, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 11, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 11, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 11, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 11, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 11, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 11, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.OAK_FENCE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 11, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 11, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 11, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 11, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 11, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 11, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 11, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 11, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 11, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 11, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 11, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 11, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 11, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 11, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 11, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 11, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 11, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 11, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 11, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 11, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 11, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 11, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(6), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 11, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 11, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 11, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 11, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 11, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 11, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 11, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 11, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 11, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 11, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 11, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 11, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 11, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 11, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 11, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 11, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 11, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 11, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 11, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 11, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 11, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_SLAB.getStateFromMeta(3), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 11, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 11, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 11, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 11, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 11, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 11, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 11, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 11, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 11, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 11, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 11, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 11, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 11, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_SLAB.getStateFromMeta(3), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 11, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 11, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 11, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 11, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 11, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 11, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 11, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 11, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 11, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 11, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 11, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 11, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 11, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 11, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 11, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 11, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 11, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.TRAPPED_CHEST.getStateFromMeta(5), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 11, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 11, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 11, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 11, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 11, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 11, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 11, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 11, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 11, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 11, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 11, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 11, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 11, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.CHEST.getStateFromMeta(5), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 11, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 11, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 11, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 11, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 11, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 11, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 11, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 11, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 11, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 11, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 11, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 11, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 11, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.TRAPPED_CHEST.getStateFromMeta(5), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 11, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 11, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 11, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 11, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 11, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 11, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 11, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 11, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 11, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 11, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 11, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 11, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 11, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.CHEST.getStateFromMeta(5), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 11, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 11, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 11, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 11, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 11, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 11, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 11, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 11, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 11, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 11, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 11, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 11, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 11, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 11, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 11, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 11, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 11, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STAINED_GLASS.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 11, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 11, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 11, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_STAIRS.getStateFromMeta(3), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 11, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 11, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.COBBLESTONE.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 11, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 11, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 11, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 11, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 11, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 11, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 11, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 11, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 11, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 11, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 11, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 11, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 12, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 12, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 12, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 12, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 12, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 12, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 12, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 12, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 12, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 12, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 12, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 12, z + 1); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 12, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 12, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 12, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 12, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 12, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 12, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 12, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 12, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 12, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 12, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 12, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 12, z + 2); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 12, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 12, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 12, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 12, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 12, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 12, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 12, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 12, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 12, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 12, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 12, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 12, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 12, z + 3); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 12, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 12, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 12, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 12, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 12, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 12, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 12, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 12, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 12, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 12, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 12, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 12, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 12, z + 4); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 12, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 12, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 12, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 12, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 12, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 12, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 12, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 12, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 12, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 12, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 12, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 12, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 12, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 12, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 12, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 12, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 12, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 12, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 12, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 12, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 12, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 12, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 12, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 12, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 12, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 12, z + 6); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 12, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 12, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 12, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 12, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 12, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 12, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 12, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 12, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 12, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 12, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 12, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 12, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 12, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 12, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 12, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 12, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 12, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 12, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 12, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 12, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 12, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 12, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 12, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 12, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 12, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 12, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 12, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 12, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 12, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 12, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 12, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 12, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 12, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 12, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 12, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 12, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 12, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 12, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 12, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 12, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 12, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 12, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 12, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 12, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 12, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 12, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 12, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 12, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 12, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 12, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 12, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 12, z + 10); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 12, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 12, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 12, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 12, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 12, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 12, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 12, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 12, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 12, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 12, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 12, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 12, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 12, z + 11); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 12, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 12, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 12, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 12, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }

		generate_r01(world, rand, x, y, z);
		return true;

	}
	public boolean generate_r01(World world, Random rand, int x, int y, int z)
	{

		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 12, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 12, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 12, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 12, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 12, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 12, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 12, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 12, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 12, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 0, y + 12, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 12, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 12, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 12, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 12, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 12, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 12, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 12, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 12, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 12, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 12, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 12, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.DOUBLE_WOODEN_SLAB.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 12, y + 12, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 12, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 12, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 3, y + 12, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 4, y + 12, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 5, y + 12, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 12, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 7, y + 12, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 8, y + 12, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 9, y + 12, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 12, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 11, y + 12, z + 14); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.AIR.getStateFromMeta(0), 3); }

		generate_r02_last(world, rand, x, y, z);
		return true;

	}
	
	public boolean generate_r02_last(World world, Random rand, int x, int y, int z) {

		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 3, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.LADDER.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 1, y + 4, z + 5); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.TORCH.getStateFromMeta(1), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 4, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.LADDER.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 6, y + 4, z + 13); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.TORCH.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 5, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.LADDER.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 6, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.LADDER.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 7, z + 12); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.LADDER.getStateFromMeta(4), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 10, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.STONE_BUTTON.getStateFromMeta(3), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 10, y + 10, z + 7); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.TORCH.getStateFromMeta(2), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 10, z + 8); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.LEVER.getStateFromMeta(9), 3); }
		{ BlockPos dungeonPos = new BlockPos(x + 2, y + 10, z + 9); if (world.isValid(dungeonPos)) world.setBlockState(dungeonPos, Blocks.TORCH.getStateFromMeta(1), 3); }
		return true;

	}

}