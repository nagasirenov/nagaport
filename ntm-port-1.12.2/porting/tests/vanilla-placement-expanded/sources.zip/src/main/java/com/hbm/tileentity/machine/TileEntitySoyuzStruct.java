package com.hbm.tileentity.machine;

import com.hbm.blocks.ModBlocks;
import com.hbm.blocks.machine.SoyuzLauncher;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.AxisAlignedBB;
import com.hbm.lib.ForgeDirection;

public class TileEntitySoyuzStruct extends TileEntity implements net.minecraft.util.ITickable {
	
	int age;
	
	@Override
	public void update() {
		
		if(this.world.isRemote)
			return;
		
		age++;
		
		if(age < 20)
			return;
		
		age = 0;

		/// CHECK PAD ///
		for(int i = -6; i <= 6; i++)
			for(int j = 3; j <= 4; j++)
				for(int k = -6; k <= 6; k++)
					if(this.world.getBlock(this.pos.getX() + i, this.pos.getY() + j, this.pos.getZ() + k) != ModBlocks.struct_launcher)
						return;
		
		for(int i = -1; i <= 1; i++)
			for(int j = 3; j <= 4; j++)
				for(int k = -8; k <= -7; k++)
					if(this.world.getBlock(this.pos.getX() + i, this.pos.getY() + j, this.pos.getZ() + k) != ModBlocks.struct_launcher)
						return;
		
		for(int i = -2; i <= 2; i++)
			for(int j = 3; j <= 4; j++)
				for(int k = 7; k <= 9; k++)
					if(this.world.getBlock(this.pos.getX() + i, this.pos.getY() + j, this.pos.getZ() + k) != ModBlocks.struct_launcher)
						return;
		
		for(int i = -2; i <= 2; i++)
			for(int k = 5; k <= 9; k++)
				if(this.world.getBlock(this.pos.getX() + i, this.pos.getY() + 51, this.pos.getZ() + k) != ModBlocks.struct_launcher)
					return;
		
		for(int i = -1; i <= 1; i++)
			for(int k = -8; k <= -6; k++)
				if(this.world.getBlock(this.pos.getX() + i, this.pos.getY() + 38, this.pos.getZ() + k) != ModBlocks.struct_launcher)
					return;
		
		/// CHECK LEGS ///
		for(int i = 3; i <= 6; i++)
			for(int j = 0; j <= 2; j++)
				for(int k = 3; k <= 6; k++)
					if(this.world.getBlock(this.pos.getX() + i, this.pos.getY() + j, this.pos.getZ() + k) != ModBlocks.concrete &&
							this.world.getBlock(this.pos.getX() + i, this.pos.getY() + j, this.pos.getZ() + k) != ModBlocks.concrete_smooth)
						return;
		
		for(int i = -6; i <= -3; i++)
			for(int j = 0; j <= 2; j++)
				for(int k = 3; k <= 6; k++)
					if(this.world.getBlock(this.pos.getX() + i, this.pos.getY() + j, this.pos.getZ() + k) != ModBlocks.concrete &&
					this.world.getBlock(this.pos.getX() + i, this.pos.getY() + j, this.pos.getZ() + k) != ModBlocks.concrete_smooth)
				return;
		
		for(int i = -6; i <= -3; i++)
			for(int j = 0; j <= 2; j++)
				for(int k = -6; k <= -3; k++)
					if(this.world.getBlock(this.pos.getX() + i, this.pos.getY() + j, this.pos.getZ() + k) != ModBlocks.concrete &&
					this.world.getBlock(this.pos.getX() + i, this.pos.getY() + j, this.pos.getZ() + k) != ModBlocks.concrete_smooth)
				return;
		
		for(int i = 3; i <= 6; i++)
			for(int j = 0; j <= 2; j++)
				for(int k = -6; k <= -3; k++)
					if(this.world.getBlock(this.pos.getX() + i, this.pos.getY() + j, this.pos.getZ() + k) != ModBlocks.concrete &&
					this.world.getBlock(this.pos.getX() + i, this.pos.getY() + j, this.pos.getZ() + k) != ModBlocks.concrete_smooth)
				return;
		
		for(int i = -1; i <= 1; i++)
			for(int j = 0; j <= 2; j++)
				for(int k = -8; k <= -6; k++)
					if(this.world.getBlock(this.pos.getX() + i, this.pos.getY() + j, this.pos.getZ() + k) != ModBlocks.concrete &&
					this.world.getBlock(this.pos.getX() + i, this.pos.getY() + j, this.pos.getZ() + k) != ModBlocks.concrete_smooth)
				return;
		
		for(int i = -2; i <= 2; i++)
			for(int j = 0; j <= 2; j++)
				for(int k = 5; k <= 9; k++)
					if(this.world.getBlock(this.pos.getX() + i, this.pos.getY() + j, this.pos.getZ() + k) != ModBlocks.concrete &&
					this.world.getBlock(this.pos.getX() + i, this.pos.getY() + j, this.pos.getZ() + k) != ModBlocks.concrete_smooth)
				return;
		
		/// CHECK SCAFFOLDING ///
		for(int i = -1; i <= 1; i++)
			for(int j = 5; j <= 50; j++)
				for(int k = 6; k <= 8; k++)
					if(this.world.getBlock(this.pos.getX() + i, this.pos.getY() + j, this.pos.getZ() + k) != ModBlocks.struct_scaffold)
						return;
		
		for(int j = 5; j <= 37; j++)
			if(this.world.getBlock(this.pos.getX(), this.pos.getY() + j, this.pos.getZ() - 7) != ModBlocks.struct_scaffold)
				return;
		/// CHECKS COMPLETE ///
		
		/// DELETE SCAFFOLDING ///
		
		for(int i = -2; i <= 2; i++)
			for(int k = 5; k <= 9; k++)
				this.world.setBlock(this.pos.getX() + i, this.pos.getY() + 51, this.pos.getZ() + k, Blocks.AIR);
		
		for(int i = -1; i <= 1; i++)
			for(int k = -8; k <= -6; k++)
				this.world.setBlock(this.pos.getX() + i, this.pos.getY() + 38, this.pos.getZ() + k, Blocks.AIR);
		
		for(int i = -2; i <= 2; i++)
			for(int j = 0; j <= 2; j++)
				for(int k = 5; k <= 9; k++)
					this.world.setBlock(this.pos.getX() + i, this.pos.getY() + j, this.pos.getZ() + k, Blocks.AIR);
		
		for(int i = -1; i <= 1; i++)
			for(int j = 5; j <= 50; j++)
				for(int k = 6; k <= 8; k++)
					this.world.setBlock(this.pos.getX() + i, this.pos.getY() + j, this.pos.getZ() + k, Blocks.AIR);
		
		for(int j = 5; j <= 37; j++)
			this.world.setBlock(this.pos.getX(), this.pos.getY() + j, this.pos.getZ() - 7, Blocks.AIR);

		/// GENERATE LAUNCHER ///
		
		ForgeDirection dir = ForgeDirection.EAST;
		
		this.world.setBlock(this.pos.getX(), this.pos.getY(), this.pos.getZ(), Blocks.AIR);
		this.world.setBlock(this.pos.getX() , this.pos.getY() + SoyuzLauncher.height, this.pos.getZ(), ModBlocks.soyuz_launcher, dir.ordinal() + SoyuzLauncher.offset, 3);
		((SoyuzLauncher)ModBlocks.soyuz_launcher).fillSpace(this.world, this.pos.getX(), this.pos.getY(), this.pos.getZ(), dir, 0);
	}
	
	@Override
	public AxisAlignedBB getRenderBoundingBox() {
		return TileEntity.INFINITE_EXTENT_AABB;
	}
	
	@Override
	@SideOnly(Side.CLIENT)
	public double getMaxRenderDistanceSquared() {
		return 65536.0D;
	}
}
