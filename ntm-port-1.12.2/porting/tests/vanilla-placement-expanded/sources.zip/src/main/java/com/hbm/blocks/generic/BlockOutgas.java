package com.hbm.blocks.generic;

import java.util.Random;

import com.hbm.blocks.ModBlocks;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.world.World;
import com.hbm.lib.ForgeDirection;

public class BlockOutgas extends Block {
	
	boolean randomTick;
	int rate;
	boolean onBreak;
	boolean onNeighbour;
	

	public BlockOutgas(Material mat, boolean randomTick, int rate, boolean onBreak) {
		super(mat);
		this.setTickRandomly(randomTick);
		this.randomTick = randomTick;
		this.rate = rate;
		this.onBreak = onBreak;
		this.onNeighbour = false;
	}

	public BlockOutgas(Material mat, boolean randomTick, int rate, boolean onBreak, boolean onNeighbour) {
		this(mat, randomTick, rate, onBreak);
		this.onNeighbour = onNeighbour;
	}

	public int tickRate(World world) {
		return rate;
	}
	
	protected Block getGas() {
		if(this == ModBlocks.ore_uranium_scorched ||
				this == ModBlocks.ore_gneiss_uranium || this == ModBlocks.ore_gneiss_uranium_scorched || 
				this == ModBlocks.ore_nether_uranium || this == ModBlocks.ore_nether_uranium_scorched) {
			return ModBlocks.gas_radon;
		}
		
		if(this == ModBlocks.block_corium_cobble)
			return ModBlocks.gas_radon;
		
		if(this == ModBlocks.ancient_scrap)
			return ModBlocks.gas_radon_tomb;
		
		if(this == ModBlocks.ore_nether_coal) {
			return ModBlocks.gas_monoxide;
		}
		
		if(this == ModBlocks.ore_gneiss_asbestos ||
				this == ModBlocks.block_asbestos || this == ModBlocks.deco_asbestos ||
				this == ModBlocks.brick_asbestos || this == ModBlocks.tile_lab ||
				this == ModBlocks.tile_lab_cracked || this == ModBlocks.tile_lab_broken) {
			return ModBlocks.gas_asbestos;
		}
		
		return Blocks.AIR;
	}
	
	@Override
	public int quantityDroppedWithBonus(int fortune, Random rand) {
		
		if(fortune > 0 && Item.getItemFromBlock(this) != this.getItemDropped(0, rand, fortune)) {
			int mult = rand.nextInt(fortune + 2) - 1;

			if(mult < 0) {
				mult = 0;
			}

			return this.quantityDropped(rand) * (mult + 1);
		} else {
			return this.quantityDropped(rand);
		}
	}

	@Override
	public void onEntityWalking(World world, int x, int y, int z, Entity entity) {
		
		if(this.randomTick && getGas() == ModBlocks.gas_asbestos) {
			
			if(world.getBlock(x, y + 1, z) == Blocks.AIR) {
				
				if(world.rand.nextInt(10) == 0)
				world.setBlock(x, y + 1, z, ModBlocks.gas_asbestos);
				
				for(int i = 0; i < 5; i++)
					world.spawnParticle("townaura", x + world.rand.nextFloat(), y + 1.1, z + world.rand.nextFloat(), 0.0D, 0.0D, 0.0D);
			}
		}
	}
	
	@Override
	public void updateTick(World world, int x, int y, int z, Random rand) {
		
		ForgeDirection dir = ForgeDirection.getOrientation(rand.nextInt(6));
		
		if(world.getBlock(x + dir.offsetX, y + dir.offsetY, z + dir.offsetZ) == Blocks.AIR) {
			world.setBlock(x + dir.offsetX, y + dir.offsetY, z + dir.offsetZ, getGas());
		}
	}

	@Override
	public void dropBlockAsItemWithChance(World world, int x, int y, int z, int meta, float chance, int fortune) {
		
		if(onBreak) {
			world.setBlock(x, y, z, this.getGas());
		}
		
		super.dropBlockAsItemWithChance(world, x, y, z, meta, chance, fortune);
	}

	@Override
	public void onNeighborBlockChange(World world, int x, int y, int z, Block block) {
		
		if(onNeighbour && world.rand.nextInt(3) == 0) {

			for(ForgeDirection dir : ForgeDirection.VALID_DIRECTIONS) {
				
				if(world.getBlock(x + dir.offsetX, y + dir.offsetY, z + dir.offsetZ) == Blocks.AIR) {
					world.setBlock(x + dir.offsetX, y + dir.offsetY, z + dir.offsetZ, getGas());
				}
			}
		}
	}

	@Override
	public void breakBlock(World world, int x, int y, int z, Block block, int i) {
		super.breakBlock(world, x, y, z, block, i);
		
		if(this == ModBlocks.ancient_scrap) {
			for(int ix = -2; ix <= 2; ix++) {
				for(int iy = -2; iy <= 2; iy++) {
					for(int iz = -2; iz <= 2; iz++) {
						
						if(Math.abs(ix + iy + iz) < 5 && Math.abs(ix + iy + iz) > 0 && world.getBlock(x + ix, y + iy, z + iz) == Blocks.AIR) {
							world.setBlock(x + ix, y + iy, z + iz, this.getGas());
						}
					}
				}
			}
		}
	}
}
