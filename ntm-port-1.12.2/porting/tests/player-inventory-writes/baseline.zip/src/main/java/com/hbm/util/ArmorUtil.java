package com.hbm.util;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import com.hbm.dim.trait.CBT_Atmosphere;
import com.hbm.handler.ArmorModHandler;
import com.hbm.handler.HazmatRegistry;
import com.hbm.handler.atmosphere.ChunkAtmosphereManager;
import com.hbm.items.ModItems;
import com.hbm.items.armor.ArmorDNT;
import com.hbm.items.armor.ArmorFSB;
import com.hbm.items.armor.ItemModInsert;
import com.hbm.items.armor.ItemModOxy;
import com.hbm.lib.Library;
import com.hbm.main.ServerProxy;
import com.hbm.packet.PacketDispatcher;
import com.hbm.packet.toclient.PlayerInformPacket;
import com.hbm.potion.HbmPotion;
import com.hbm.util.ArmorRegistry.HazardClass;
import com.hbm.util.Tuple.Pair;

import api.hbm.item.IGasMask;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import com.hbm.util.NullableInventoryStackNbt;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetHandlerPlayServer;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.event.ForgeEventFactory;

public class ArmorUtil {
	
	public static List<Pair<Item, HazardClass[]>> external = new ArrayList();

	public static HazardClass[] FULL_NO_LIGHT = new HazardClass[] {HazardClass.PARTICLE_COARSE, HazardClass.PARTICLE_FINE, HazardClass.GAS_LUNG, HazardClass.BACTERIA, HazardClass.GAS_BLISTERING, HazardClass.GAS_MONOXIDE, HazardClass.SAND};
	public static HazardClass[] FULL_PACKAGE = new HazardClass[] {HazardClass.PARTICLE_COARSE, HazardClass.PARTICLE_FINE, HazardClass.GAS_LUNG, HazardClass.BACTERIA, HazardClass.GAS_BLISTERING, HazardClass.GAS_MONOXIDE, HazardClass.LIGHT, HazardClass.SAND};

	/*
	 * The less horrifying part
	 */

	public static void register() {
		ArmorRegistry.registerHazard(ModItems.gas_mask_filter, HazardClass.PARTICLE_COARSE, HazardClass.PARTICLE_FINE, HazardClass.GAS_LUNG, HazardClass.GAS_BLISTERING, HazardClass.BACTERIA);
		ArmorRegistry.registerHazard(ModItems.gas_mask_filter_mono, HazardClass.PARTICLE_COARSE, HazardClass.GAS_MONOXIDE);
		ArmorRegistry.registerHazard(ModItems.gas_mask_filter_combo, HazardClass.PARTICLE_COARSE, HazardClass.PARTICLE_FINE, HazardClass.GAS_LUNG, HazardClass.GAS_BLISTERING, HazardClass.BACTERIA, HazardClass.GAS_MONOXIDE);
		ArmorRegistry.registerHazard(ModItems.gas_mask_filter_rag, HazardClass.PARTICLE_COARSE);
		ArmorRegistry.registerHazard(ModItems.gas_mask_filter_piss, HazardClass.PARTICLE_COARSE, HazardClass.GAS_LUNG);

		ArmorRegistry.registerHazard(ModItems.gas_mask, HazardClass.SAND, HazardClass.LIGHT);
		ArmorRegistry.registerHazard(ModItems.gas_mask_m65, HazardClass.SAND);
		ArmorRegistry.registerHazard(ModItems.mask_rag, HazardClass.PARTICLE_COARSE);
		ArmorRegistry.registerHazard(ModItems.mask_piss, HazardClass.PARTICLE_COARSE, HazardClass.GAS_LUNG);

		ArmorRegistry.registerHazard(ModItems.goggles, HazardClass.LIGHT, HazardClass.SAND);
		ArmorRegistry.registerHazard(ModItems.ashglasses, HazardClass.LIGHT, HazardClass.SAND);

		ArmorRegistry.registerHazard(ModItems.attachment_mask, HazardClass.SAND);

		ArmorRegistry.registerHazard(ModItems.asbestos_helmet, HazardClass.SAND, HazardClass.LIGHT);
		
		ArmorRegistry.registerHazard(ModItems.hazmat_helmet, HazardClass.SAND);
		ArmorRegistry.registerHazard(ModItems.hazmat_helmet_red, HazardClass.SAND);
		ArmorRegistry.registerHazard(ModItems.hazmat_helmet_grey, HazardClass.SAND);
		ArmorRegistry.registerHazard(ModItems.hazmat_paa_helmet, HazardClass.LIGHT, HazardClass.SAND);
		ArmorRegistry.registerHazard(ModItems.liquidator_helmet, HazardClass.LIGHT, HazardClass.SAND);
		
		ArmorRegistry.registerHazard(ModItems.schrabidium_helmet, HazardClass.PARTICLE_COARSE, HazardClass.PARTICLE_FINE, HazardClass.GAS_LUNG, HazardClass.BACTERIA, HazardClass.GAS_BLISTERING, HazardClass.GAS_MONOXIDE, HazardClass.LIGHT, HazardClass.SAND);
		ArmorRegistry.registerHazard(ModItems.euphemium_helmet, HazardClass.PARTICLE_COARSE, HazardClass.PARTICLE_FINE, HazardClass.GAS_LUNG, HazardClass.BACTERIA, HazardClass.GAS_BLISTERING, HazardClass.GAS_MONOXIDE, HazardClass.LIGHT, HazardClass.SAND);

		for(Pair<Item, HazardClass[]> pair : external) {
			ArmorRegistry.registerHazard(pair.getKey(), pair.getValue());
		}
		
		//Ob ihr wirklich richtig steht, seht ihr wenn das Licht angeht!
		registerIfExists(Compat.MOD_GT6, "gt.armor.hazmat.universal.head", HazardClass.PARTICLE_COARSE, HazardClass.PARTICLE_FINE, HazardClass.GAS_LUNG, HazardClass.BACTERIA, HazardClass.GAS_BLISTERING, HazardClass.GAS_MONOXIDE, HazardClass.LIGHT, HazardClass.SAND);
		registerIfExists(Compat.MOD_GT6, "gt.armor.hazmat.biochemgas.head", HazardClass.PARTICLE_COARSE, HazardClass.PARTICLE_FINE, HazardClass.GAS_LUNG, HazardClass.BACTERIA, HazardClass.GAS_BLISTERING, HazardClass.GAS_MONOXIDE, HazardClass.LIGHT, HazardClass.SAND);
		registerIfExists(Compat.MOD_GT6, "gt.armor.hazmat.radiation.head", HazardClass.PARTICLE_COARSE, HazardClass.PARTICLE_FINE, HazardClass.GAS_LUNG, HazardClass.BACTERIA, HazardClass.GAS_BLISTERING, HazardClass.GAS_MONOXIDE, HazardClass.LIGHT, HazardClass.SAND);
	}

	private static void registerIfExists(String domain, String name, HazardClass... classes) {
		Item item = Compat.tryLoadItem(domain, name);
		if(item != null)
			ArmorRegistry.registerHazard(item, classes);
	}

	public static boolean checkArmor(EntityLivingBase entity, Item... armor) {

		for(int i = 0; i < 4; i++) {
			if(!checkArmorPiece(entity, armor[i], 3 - i))
				return false;
		}

		return true;
	}

	public static boolean checkArmorPiece(EntityLivingBase entity, Item armor, int slot) {
		return !checkArmorNull(entity, slot) && entity.getEquipmentInSlot(slot + 1).getItem() == armor;
	}

	public static boolean checkArmorNull(EntityLivingBase player, int slot) {
		return player.getEquipmentInSlot(slot + 1) == null;
	}

	public static void damageSuit(EntityLivingBase entity, int slot, int amount) {

		if(entity.getEquipmentInSlot(slot + 1) == null)
			return;

		entity.getEquipmentInSlot(slot + 1).damageItem(amount, entity);

		if(entity.getEquipmentInSlot(slot + 1).stackSize == 0) {
			entity.setCurrentItemOrArmor(slot + 1, null);
		}
	}

	public static void resetFlightTime(EntityPlayer player) {

		if(player instanceof EntityPlayerMP) {
			EntityPlayerMP mp = (EntityPlayerMP) player;
			ReflectionHelper.setPrivateValue(NetHandlerPlayServer.class, mp.playerNetServerHandler, 0, "floatingTickCount", "field_147365_f");
		}
	}

	//TODO: figure out a way of handling this more gracefully (hazmat trait for FSBs?)
	//and stop using this shit
	@Deprecated public static boolean checkForHazmat(EntityLivingBase player) {

		if(checkArmor(player, ModItems.hazmat_helmet, ModItems.hazmat_plate, ModItems.hazmat_legs, ModItems.hazmat_boots) ||
				checkArmor(player, ModItems.hazmat_helmet_red, ModItems.hazmat_plate_red, ModItems.hazmat_legs_red, ModItems.hazmat_boots_red) ||
				checkArmor(player, ModItems.hazmat_helmet_grey, ModItems.hazmat_plate_grey, ModItems.hazmat_legs_grey, ModItems.hazmat_boots_grey) ||
				checkArmor(player, ModItems.schrabidium_helmet, ModItems.schrabidium_plate, ModItems.schrabidium_legs, ModItems.schrabidium_boots) ||
				checkForHaz2(player)) {

			return true;
		}

		if(player.isPotionActive(HbmPotion.mutation) || player.isPotionActive(HbmPotion.nitan)) return true;
		return false;
	}

	@Deprecated public static boolean checkForHaz2(EntityLivingBase player) {

		if(checkArmor(player, ModItems.hazmat_paa_helmet, ModItems.hazmat_paa_plate, ModItems.hazmat_paa_legs, ModItems.hazmat_paa_boots) ||
				checkArmor(player, ModItems.liquidator_helmet, ModItems.liquidator_plate, ModItems.liquidator_legs, ModItems.liquidator_boots) ||
				checkArmor(player, ModItems.euphemium_helmet, ModItems.euphemium_plate, ModItems.euphemium_legs, ModItems.euphemium_boots) ||
				checkArmor(player, ModItems.rpa_helmet, ModItems.rpa_plate, ModItems.rpa_legs, ModItems.rpa_boots) ||
				checkArmor(player, ModItems.fau_helmet, ModItems.fau_plate, ModItems.fau_legs, ModItems.fau_boots) ||
				checkArmor(player, ModItems.dns_helmet, ModItems.dns_plate, ModItems.dns_legs, ModItems.dns_boots))
		{
			return true;
		}

		return false;
	}

	public static boolean checkForAsbestos(EntityLivingBase player) {
		if(checkArmor(player, ModItems.asbestos_helmet, ModItems.asbestos_plate, ModItems.asbestos_legs, ModItems.asbestos_boots)) return true;
		return false;
	}

	public static boolean checkForOxy(EntityLivingBase entity, CBT_Atmosphere atmosphere) {
		if(!(entity instanceof EntityPlayer)) return ChunkAtmosphereManager.proxy.canBreathe(atmosphere);
		EntityPlayer player = (EntityPlayer) entity;

		if(checkSpecialBreathing(player)) return true;
		if(checkModBreathing(player)) return true;

		ItemStack tank = getOxygenTank(player);
		if(tank == null) return ChunkAtmosphereManager.proxy.canBreathe(atmosphere);

		// If we have an oxygen tank, block drowning
		boolean isInWater = entity.getAir() < 300;
		boolean canBreatheTank = ((ItemModOxy)tank.getItem()).attemptBreathing(entity, tank, atmosphere, isInWater);

		if(isInWater && canBreatheTank) {
			entity.setAir(300);
		}

		return canBreatheTank;
	}

	public static ItemStack getOxygenTank(EntityPlayer player) {
		// TODO: only require pressure suits in near vacuums, and use regular oxygen tanks otherwise

		// Check that all the armor pieces are sealed
		for(int i = 0; i < 4; i++) {
			ItemStack stack = player.getCurrentArmor(i);
			if(stack == null || !(stack.getItem() instanceof ArmorFSB)) return null;
			if(!((ArmorFSB)stack.getItem()).canSeal) return null;
		}

		// Check for a non-empty oxygen tank
		ItemStack helmet = player.getCurrentArmor(3);
		if(ArmorModHandler.hasMods(helmet)) {
			ItemStack tankMod = ArmorModHandler.pryMods(helmet)[ArmorModHandler.plate_only];
			if(tankMod == null || !(tankMod.getItem() instanceof ItemModOxy)) return null;

			return tankMod;
		}

		return null;
	}

	private static boolean checkSpecialBreathing(EntityPlayer player) {
		if(player.capabilities.isCreativeMode) return true;

		// Check DNT
		for(int i = 0; i < 4; i++) {
			ItemStack stack = player.getCurrentArmor(i);
			if(stack == null || !(stack.getItem() instanceof ArmorDNT)) return false;
		}

		return true;
	}

	/**
	 * Support for:
	 *  - Fisk's Superheroes
	 */

	private static final MethodHandle canBreatheInSpaceFiskHandle;
	private static final MethodHandle getHeroIterationHandle;
	private static final Class<?> heroIteration;

	static {
		if(Loader.isModLoaded("fiskheroes")) {
			try {
				Class<?> worldHelper = Class.forName("com.fiskmods.heroes.util.WorldHelper");
				Class<?> heroTracker = Class.forName("com.fiskmods.heroes.common.hero.HeroTracker");
				heroIteration = Class.forName("com.fiskmods.heroes.common.hero.HeroIteration");

				MethodHandles.Lookup lookup = MethodHandles.publicLookup();

				MethodType canBreatheType = MethodType.methodType(boolean.class, EntityLivingBase.class, heroIteration);
				canBreatheInSpaceFiskHandle = lookup.findStatic(worldHelper, "canBreatheInSpace", canBreatheType);

				MethodType herpesIterationType = MethodType.methodType(heroIteration, EntityPlayer.class);
				getHeroIterationHandle = lookup.findStatic(heroTracker, "iter", herpesIterationType);
			} catch(Exception e) {
				throw new AssertionError();
			}
		} else {
			canBreatheInSpaceFiskHandle = null;
			getHeroIterationHandle = null;
			heroIteration = null;
		}
	}

	private static boolean checkModBreathing(EntityPlayer player) {
		if(canBreatheInSpaceFiskHandle != null) {
			try {
				// this could have been `invokeExact` but the damn canBreatheInSpace method
				// expects some internal armor representation ugh
				Object iter = getHeroIterationHandle.invoke(player);
				if((boolean)canBreatheInSpaceFiskHandle.invoke((EntityLivingBase) player, iter)) return true;
			} catch (Throwable e) {
				e.printStackTrace();
				// halt and catch herpes
			}
		}

		return false;
	}


	public static boolean checkForCorrosion(EntityLivingBase entity, CBT_Atmosphere atmosphere) {
		if(!ChunkAtmosphereManager.proxy.willCorrode(atmosphere)) return false;

		if(!(entity instanceof EntityPlayer)) return true;
		EntityPlayer player = (EntityPlayer) entity;

		ItemStack insert = getCorrosionProtection(player);
		if(insert == null) {
			boolean isSealed = true; // safe, for now...
			Random rand = entity.getRNG();

			// if we have a full set of armor, deplete that rapidly first before applying damage
			for(int i = 0; i < 4; i++) {
				ItemStack stack = player.getCurrentArmor(i);
				if(stack == null || !(stack.getItem() instanceof ArmorFSB) || !((ArmorFSB)stack.getItem()).canSeal) {
					isSealed = false;
				}

				if(stack == null) continue;

				if(rand.nextInt(2) == 0) {
					stack.setItemDamage(stack.getItemDamage() + 1);
				}

				if(stack.getItemDamage() >= stack.getMaxDamage() || !(stack.getItem() instanceof ArmorFSB) || !((ArmorFSB)stack.getItem()).isArmorEnabled(stack)) {
					stack.stackSize = 0;
					player.inventory.armorInventory[i] = null;
					entity.world.playSoundAtEntity(entity, "random.fizz", 0.2F, 1F);
				}
			}

			if(isSealed && entity instanceof EntityPlayerMP) {
				PacketDispatcher.wrapper.sendTo(new PlayerInformPacket(ChatBuilder.start("").nextTranslation("info.corrosion").color(TextFormatting.RED).flush(), ServerProxy.ID_GAS_HAZARD, 3000), (EntityPlayerMP) entity);
			}

			return !isSealed;
		}

		return false;
	}

	public static ItemStack getCorrosionProtection(EntityPlayer player) {
		// Check chest piece has a valid insert
		ItemStack chest = player.getCurrentArmor(2);
		if(chest != null && ArmorModHandler.hasMods(chest)) {
			ItemStack insertMod = ArmorModHandler.pryMods(chest)[ArmorModHandler.kevlar];
			if(insertMod == null || !(insertMod.getItem() instanceof ItemModInsert)) return null;
			if(!((ItemModInsert)insertMod.getItem()).corrosionProtection) return null;

			return insertMod;
		}

		return null;
	}

	public static boolean checkForDigamma(EntityPlayer player) {
		if(checkArmor(player, ModItems.fau_helmet, ModItems.fau_plate, ModItems.fau_legs, ModItems.fau_boots)) return true;
		if(checkArmor(player, ModItems.dns_helmet, ModItems.dns_plate, ModItems.dns_legs, ModItems.dns_boots)) return true;
		if(player.isPotionActive(HbmPotion.stability.id)) return true;

		return false;
	}

	public static boolean checkForDigamma2(EntityPlayer player) {

		if(!checkArmor(player, ModItems.robes_helmet, ModItems.robes_plate, ModItems.robes_legs, ModItems.robes_boots)) return false;
		if(!player.isPotionActive(HbmPotion.stability.id)) return false;

		for(int i = 0; i < 4; i++) {
			ItemStack armor = player.getCurrentArmor(i);

			if(armor != null && ArmorModHandler.hasMods(armor)) {
				ItemStack mods[] = ArmorModHandler.pryMods(armor);
				if(!(mods[ArmorModHandler.cladding] != null && mods[ArmorModHandler.cladding].getItem() == ModItems.cladding_iron))
					return false;
			}
		}

		return player.getMaxHealth() < 3;
	}

	public static boolean checkForFaraday(EntityPlayer player) {

		ItemStack[] armor = player.inventory.armorInventory;

		if(armor[0] == null || armor[1] == null || armor[2] == null || armor[3] == null) return false;

		if(isFaradayArmor(armor[0]) && isFaradayArmor(armor[1]) && isFaradayArmor(armor[2]) && isFaradayArmor(armor[3]))
			return true;

		return false;
	}

	public static final String[] metals = new String[] {
			"chainmail",
			"iron",
			"silver",
			"gold",
			"platinum",
			"tin",
			"lead",
			"liquidator",
			"schrabidium",
			"euphemium",
			"steel",
			"cmb",
			"titanium",
			"alloy",
			"copper",
			"bronze",
			"electrum",
			"t45",
			"t51",
			"bj",
			"starmetal",
			"hazmat", //also count because rubber is insulating
			"rubber",
			"hev",
			"ajr",
			"rpa",
			"spacesuit"
	};

	public static boolean isFaradayArmor(ItemStack item) {

		String name = item.getUnlocalizedName();

		for(String metal : metals) if(name.toLowerCase(Locale.US).contains(metal)) return true;
		if(HazmatRegistry.getCladding(item) > 0) return true;

		return false;
	}

	public static boolean checkForFiend(EntityPlayer player) {

		return checkArmorPiece(player, ModItems.jackt, 2) && Library.checkForHeld(player, ModItems.shimmer_sledge);
	}

	public static boolean checkForFiend2(EntityPlayer player) {

		return checkArmorPiece(player, ModItems.jackt2, 2) && Library.checkForHeld(player, ModItems.shimmer_axe);
	}

	/*
	 * Default implementations for IGasMask items
	 */
	public static final String FILTERK_KEY = "hfrFilter";

	public static void installGasMaskFilter(ItemStack mask, ItemStack filter) {

		if(mask == null || filter == null)
			return;

		if(!mask.hasTagCompound())
			mask.setTagCompound(new NBTTagCompound());

		NBTTagCompound attach = new NBTTagCompound();
		filter.writeToNBT(attach);

		mask.getTagCompound().setTag(FILTERK_KEY, attach);
	}

	public static void removeFilter(ItemStack mask) {

		if(mask == null)
			return;

		if(!mask.hasTagCompound())
			return;

		mask.getTagCompound().removeTag(FILTERK_KEY);
	}

	/**
	 * Grabs the installed filter or the filter of the attachment, used for attachment rendering
	 * @param mask
	 * @param entity
	 * @return
	 */
	public static ItemStack getGasMaskFilterRecursively(ItemStack mask, EntityLivingBase entity) {

		ItemStack filter = getGasMaskFilter(mask);

		if(filter == null && ArmorModHandler.hasMods(mask)) {

			ItemStack mods[] = ArmorModHandler.pryMods(mask);

			if(mods[ArmorModHandler.helmet_only] != null && mods[ArmorModHandler.helmet_only].getItem() instanceof IGasMask)
				filter = ((IGasMask)mods[ArmorModHandler.helmet_only].getItem()).getFilter(mods[ArmorModHandler.helmet_only], entity);
		}

		return filter;
	}

	public static ItemStack getGasMaskFilter(ItemStack mask) {

		if(mask == null)
			return null;

		if(!mask.hasTagCompound())
			return null;

		NBTTagCompound attach = mask.getTagCompound().getCompoundTag(FILTERK_KEY);
		ItemStack filter = NullableInventoryStackNbt.read(attach);

		return filter;
	}

	public static void damageGasMaskFilter(EntityLivingBase entity, int damage) {

		ItemStack mask = entity.getEquipmentInSlot(4);

		if(mask == null)
			return;

		if(!(mask.getItem() instanceof IGasMask)) {

			if(ArmorModHandler.hasMods(mask)) {

				ItemStack mods[] = ArmorModHandler.pryMods(mask);

				if(mods[ArmorModHandler.helmet_only] != null && mods[ArmorModHandler.helmet_only].getItem() instanceof IGasMask)
					mask = mods[ArmorModHandler.helmet_only];
			}
		}

		if(mask != null)
			damageGasMaskFilter(mask, damage);
	}

	public static void damageGasMaskFilter(ItemStack mask, int damage) {
		ItemStack filter = getGasMaskFilter(mask);

		if(filter == null) {
			if(ArmorModHandler.hasMods(mask)) {
				ItemStack mods[] = ArmorModHandler.pryMods(mask);

				if(mods[ArmorModHandler.helmet_only] != null && mods[ArmorModHandler.helmet_only].getItem() instanceof IGasMask)
					filter = getGasMaskFilter(mods[ArmorModHandler.helmet_only]);
			}
		}

		if(filter == null || filter.getMaxDamage() == 0)
			return;

		filter.setItemDamage(filter.getItemDamage() + damage);

		if(filter.getItemDamage() > filter.getMaxDamage())
			removeFilter(mask);
		else
			installGasMaskFilter(mask, filter);
	}

	public static void addGasMaskTooltip(ItemStack mask, EntityPlayer player, List list, boolean ext) {

		if(mask == null || !(mask.getItem() instanceof IGasMask))
			return;

		ItemStack filter = ((IGasMask)mask.getItem()).getFilter(mask, player);

		if(filter == null) {
			list.add(TextFormatting.RED + "No filter installed!");
			return;
		}

		list.add(TextFormatting.GOLD + "Installed filter:");

		int meta = filter.getItemDamage();
		int max = filter.getMaxDamage();

		String append = "";

		if(max > 0) {
			append = " (" + ((max - meta) * 100 / max) + "%)";
		}

		List<String> lore = new ArrayList();
		list.add("  " + filter.getDisplayName() + append);
		filter.getItem().addInformation(filter, player, lore, ext);
		ForgeEventFactory.onItemTooltip(filter, player, lore, ext);
		lore.forEach(x -> list.add(TextFormatting.YELLOW + "  " + x));
	}

	public static boolean isWearingEmptyMask(EntityPlayer player) {

		ItemStack mask = player.getEquipmentInSlot(4);

		if(mask == null)
			return false;

		if(mask.getItem() instanceof IGasMask) {
			return getGasMaskFilter(mask) == null;
		}

		ItemStack mod = ArmorModHandler.pryMods(mask)[ArmorModHandler.helmet_only];

		if(mod != null && mod.getItem() instanceof IGasMask) {
			return getGasMaskFilter(mod) == null;
		}

		return false;
	}
}
