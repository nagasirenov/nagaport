package com.hbm.blocks.generic;

import java.util.ArrayList;
import java.util.Random;

import com.hbm.blocks.BlockEnumMulti;
import com.hbm.blocks.BlockEnums;
import com.hbm.blocks.ModBlocks;
import com.hbm.items.ModItems;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.world.World;
import com.hbm.lib.ForgeDirection;

public class BlockStalagmite extends BlockEnumMulti {

	public BlockStalagmite() {
		super(Material.ROCK, BlockEnums.EnumStalagmiteType.class, true, true);
	}

	@Override
	public boolean isOpaqueCube(net.minecraft.block.state.IBlockState state) {
		return false;
	}

	@Override
	public boolean isFullCube(net.minecraft.block.state.IBlockState state) {
		return false;
	}

	@Override
	public int getRenderType() {
		return 1;
	}

	@Override
	public Item getItemDropped(int meta, Random rang, int fortune) {
		
		switch(meta) {
		case 0: return ModItems.sulfur;
		case 1: return ModItems.powder_asbestos;
		case 2: return ModItems.flesh;
		}
		
		return null;
	}
	
	public static int getMetaFromResource(Block block, int meta) {
		if(block == ModBlocks.tumor) return 2;
		return meta;
	}

	@Override
	public boolean canPlaceBlockAt(World world, int x, int y, int z) {

		if(this == ModBlocks.stalagmite) return World.doesBlockHaveSolidTopSurface(world, x, y - 1, z);
		if(this == ModBlocks.stalactite) return com.hbm.lib.FacingCompat.isWorldSideSolid(world, x, y + 1, z, ForgeDirection.DOWN);
		
		return true;
	}

	@Override
	public void onNeighborBlockChange(World world, int x, int y, int z, Block block) {
		if(!canPlaceBlockAt(world, x, y, z)) {
			world.func_147480_a(x, y, z, true);
		}
	}

	@Override
	public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int x, int y, int z) {
		return null;
	}

	@Override
	public ArrayList<ItemStack> getDrops(World world, int x, int y, int z, int metadata, int fortune) {
		return ModBlocks.getDropsWithoutDamage(world, this, metadata, fortune);
	}

}
