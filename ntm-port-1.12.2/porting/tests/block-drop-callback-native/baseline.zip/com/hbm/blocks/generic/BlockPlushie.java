package com.hbm.blocks.generic;

import java.util.List;
import java.util.Random;

import com.hbm.blocks.IBlockMulti;
import com.hbm.blocks.ITooltipProvider;
import com.hbm.world.gen.nbt.INBTTileEntityTransformable;
import com.hbm.world.gen.nbt.INBTBlockTransformable;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import com.hbm.util.i18n.I18nUtil;
import net.minecraft.world.World;

public class BlockPlushie extends BlockContainer implements IBlockMulti, ITooltipProvider, INBTBlockTransformable {

	public BlockPlushie() {
		super(Material.cloth);
	}

	@Override public int getRenderType() { return -1; }
	@Override public boolean isOpaqueCube() { return false; }
	@Override public boolean renderAsNormalBlock() { return false; }
	@Override public Item getItemDropped(int i, Random rand, int j) { return null; }

	@Override
	public ItemStack getPickBlock(RayTraceResult target, World world, BlockPos pos, EntityPlayer player) {
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		TileEntityPlushie entity = (TileEntityPlushie) world.getTileEntity(new net.minecraft.util.math.BlockPos(x, y, z));
		if(entity != null) return new ItemStack(this, 1, entity.type.ordinal());
		return super.getPickBlock(target, world, pos, player);
	}

	@Override
	public void onBlockHarvested(World world, int x, int y, int z, int meta, EntityPlayer player) {

		if(!player.capabilities.isCreativeMode) {
			harvesters.set(player);
			if(!world.isRemote) {
				TileEntityPlushie entity = (TileEntityPlushie) world.getTileEntity(new net.minecraft.util.math.BlockPos(x, y, z));
				if(entity != null) {
					EntityItem item = new EntityItem(world, x + 0.5, y, z + 0.5, new ItemStack(this, 1, entity.type.ordinal()));
					item.motionX = 0;
					item.motionY = 0;
					item.motionZ = 0;
					world.spawnEntity(item);
				}
			}
			harvesters.set(null);
		}
	}

	@Override
	public void harvestBlock(World world, EntityPlayer player, int x, int y, int z, int meta) {
		player.addStat(StatList.mineBlockStatArray[getIdFromBlock(this)], 1);
		player.addExhaustion(0.025F);
	}

	@Override
	@SideOnly(Side.CLIENT)
	public void getSubBlocks(Item item, CreativeTabs tab, List list) {
		for(int i = 1; i < PlushieType.values().length; i++) list.add(new ItemStack(item, 1, i));
	}

	@Override
	public void onBlockPlacedBy(World world, int x, int y, int z, EntityLivingBase player, ItemStack stack) {
		int meta = MathHelper.floor((double)((player.rotationYaw + 180.0F) * 16.0F / 360.0F) + 0.5D) & 15;
		world.setBlockMetadataWithNotify(x, y, z, meta, 2);

		TileEntityPlushie plushie = (TileEntityPlushie) world.getTileEntity(new net.minecraft.util.math.BlockPos(x, y, z));
		plushie.type = PlushieType.values()[Math.abs(stack.getItemDamage()) % PlushieType.values().length];
		plushie.markDirty();
	}

	@Override
	public TileEntity createNewTileEntity(World world, int meta) {
		return new TileEntityPlushie();
	}

	@Override
	public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int side, float hitX, float hitY, float hitZ) {
		TileEntityPlushie plushie = (TileEntityPlushie) world.getTileEntity(new net.minecraft.util.math.BlockPos(x, y, z));

		if(world.isRemote) {
			plushie.squishTimer = 11;
			return true;
		} else {
			if(plushie != null) {
				world.playSoundEffect(x + 0.5, y + 0.5, z + 0.5, plushie.type.sound, 0.25F, 1F);
			}
			return true;
		}
	}

	@Override
	public int transformMeta(int meta, int coordBaseMode) {
		return (meta + coordBaseMode * 4) % 16;
	}

	public static class TileEntityPlushie extends TileEntity implements INBTTileEntityTransformable, net.minecraft.util.ITickable {

		public PlushieType type = PlushieType.NONE;
		public int squishTimer;
		public float miseryFactor;
		public float lastMiseryFactor;

		@Override
		public void update() {
			if(squishTimer > 0) squishTimer--;
			lastMiseryFactor = miseryFactor;
		}

		@Override
		public SPacketUpdateTileEntity getUpdatePacket() {
			NBTTagCompound nbt = new NBTTagCompound();
			this.writeToNBT(nbt);
			return new SPacketUpdateTileEntity(this.getPos(), 0, nbt);
		}

		@Override
		public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
			this.readFromNBT(pkt.getNbtCompound());
		}

		@Override
		public void readFromNBT(NBTTagCompound nbt) {
			super.readFromNBT(nbt);
			this.type = PlushieType.values()[Math.abs(nbt.getByte("type")) % PlushieType.values().length];
		}

		@Override
		public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
			super.writeToNBT(nbt);
			nbt.setByte("type", (byte) type.ordinal());
			return nbt;
		}

		@Override
		public void transformTE(World world, int coordBaseMode) {
			type = PlushieType.values()[world.rand.nextInt(PlushieType.values().length - 1) + 1];
		}
	}

	public static enum PlushieType {
		NONE(		"NONE",				null, null),
		YOMI(		"Yomi",				"Hi! Can I be your rabbit friend?", "hbm:block.squeakyToy"),
		NUMBERNINE(	"Number Nine",		"None of y'all deserve coal.", "hbm:block.squeakyToy"),
		HUNDUN(		"Hundun",			"混沌", "hbm:block.hunduns_magnificent_howl"),
		TETO(		"Kasane Teto",		"please help I've been trapped in her basement for da-", "hbm:block.teto"),
		MIKU(		"Hatsune Miku",		"In your wifi, and your heart.", "hbm:block.miku"),
		NERU(		"Akita Neru",		"Careful, she might electrocute you.", "hbm:block.akita"),
		DERG(		"Dragon",			"Squeeze him.", "hbm:block.squeakyToy");

		public String label;
		public String inscription;
		public String sound;

		private PlushieType(String label, String inscription, String sound) {
			this.label = label;
			this.inscription = inscription;
			this.sound = sound;
		}
	}

	@Override
	public int getSubCount() {
		return PlushieType.values().length;
	}

	@Override
	public String getOverrideDisplayName(ItemStack stack) {
		PlushieType type = PlushieType.values()[Math.abs(stack.getItemDamage()) % PlushieType.values().length];
		return I18nUtil.format(this.getTranslationKey() + ".name", type == PlushieType.NONE ? "" : type.label).trim();
	}

	@Override
	public void addInformation(ItemStack stack, EntityPlayer player, List list, boolean ext) {
		PlushieType type = PlushieType.values()[Math.abs(stack.getItemDamage()) % PlushieType.values().length];
		if(type.inscription != null) list.add(type.inscription);
	}
}
