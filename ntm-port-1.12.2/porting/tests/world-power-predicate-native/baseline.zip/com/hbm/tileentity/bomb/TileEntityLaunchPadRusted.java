package com.hbm.tileentity.bomb;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.hbm.entity.missile.EntityMissileBaseNT;
import com.hbm.entity.missile.EntityMissileTier4.EntityMissileDoomsdayRusted;
import com.hbm.interfaces.IBomb.BombReturnCode;
import com.hbm.interfaces.IControlReceiver;
import com.hbm.inventory.container.ContainerLaunchPadRusted;
import com.hbm.inventory.gui.GUILaunchPadRusted;
import com.hbm.items.ModItems;
import com.hbm.main.MainRegistry;
import com.hbm.tileentity.IGUIProvider;
import com.hbm.tileentity.TileEntityMachineBase;
import com.hbm.util.TrackerUtil;
import com.hbm.util.fauxpointtwelve.BlockPos;

import api.hbm.item.IDesignatorItem;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import com.hbm.lib.ForgeDirection;

public class TileEntityLaunchPadRusted extends TileEntityMachineBase implements IGUIProvider, IControlReceiver {

	public int prevRedstonePower;
	public int redstonePower;
	public Set<BlockPos> activatedBlocks = new HashSet<>(4);

	public boolean missileLoaded;

	public TileEntityLaunchPadRusted() {
		super(4);
	}

	@Override
	public String getDefaultName() {
		return "container.launchPadRusted";
	}

	@Override
	public void update() {

		if(!this.world.isRemote) {

			if(this.redstonePower > 0 && this.prevRedstonePower <= 0) {
				this.launch();
			}

			this.prevRedstonePower = this.redstonePower;
			this.networkPackNT(250);
		} else {

			List<EntityMissileBaseNT> entities = this.world.getEntitiesWithinAABB(EntityMissileBaseNT.class, AxisAlignedBB.getBoundingBox(this.pos.getX() - 0.5, this.pos.getY(), this.pos.getZ() - 0.5, this.pos.getX() + 1.5, this.pos.getY() + 10, this.pos.getZ() + 1.5));

			if(!entities.isEmpty()) {
				for(int i = 0; i < 15; i++) {

					ForgeDirection dir = ForgeDirection.getOrientation(this.getBlockMetadata() - 10);
					if(this.world.rand.nextBoolean()) dir = dir.getOpposite();
					if(this.world.rand.nextBoolean()) dir = dir.getRotation(ForgeDirection.UP);
					float moX = (float) (this.world.rand.nextGaussian() * 0.15F + 0.75) * dir.offsetX;
					float moZ = (float) (this.world.rand.nextGaussian() * 0.15F + 0.75) * dir.offsetZ;

					NBTTagCompound data = new NBTTagCompound();
					data.setDouble("posX", this.pos.getX() + 0.5);
					data.setDouble("posY", this.pos.getY() + 0.25);
					data.setDouble("posZ", this.pos.getZ() + 0.5);
					data.setString("type", "launchSmoke");
					data.setDouble("moX", moX);
					data.setDouble("moY", 0);
					data.setDouble("moZ", moZ);
					MainRegistry.proxy.effectNT(data);

				}
			}
		}
	}

	@Override
	public void serialize(ByteBuf buf) {
		super.serialize(buf);
		buf.writeBoolean(this.missileLoaded);
	}

	@Override
	public void deserialize(ByteBuf buf) {
		super.deserialize(buf);
		this.missileLoaded = buf.readBoolean();
	}

	public BombReturnCode launch() {

		if(slots[1] != null && slots[2] != null && slots[3] != null && this.missileLoaded) {
			if(slots[1].getItem() == ModItems.launch_code && slots[2].getItem() == ModItems.launch_key) {
				if(slots[3] != null && slots[3].getItem() instanceof IDesignatorItem) {
					IDesignatorItem designator = (IDesignatorItem) slots[3].getItem();

					if(!designator.isReady(this.world, slots[3], this.pos.getX(), this.pos.getY(), this.pos.getZ())) return BombReturnCode.ERROR_MISSING_COMPONENT;

					Vec3d coords = designator.getCoords(this.world, slots[3], this.pos.getX(), this.pos.getY(), this.pos.getZ());
					int targetX = (int) Math.floor(coords.x);
					int targetZ = (int) Math.floor(coords.z);

					EntityMissileDoomsdayRusted missile = new EntityMissileDoomsdayRusted(this.world, this.pos.getX() + 0.5F, this.pos.getY() + 1F, this.pos.getZ() + 0.5F, targetX, targetZ);
					this.world.spawnEntityInWorld(missile);
					TrackerUtil.setTrackingRange(this.world, missile, 500);
					com.hbm.sound.WorldSoundEffects.play(this.world, this.pos.getX() + 0.5, this.pos.getY(), this.pos.getZ() + 0.5, "hbm:weapon.missileTakeOff", 2.0F, 1.0F);
					this.missileLoaded = false;
					this.decrStackSize(1, 1);
					this.markDirty();

					return BombReturnCode.LAUNCHED;
				}
			}
		}

		return BombReturnCode.ERROR_MISSING_COMPONENT;
	}

	@Override
	public void readFromNBT(NBTTagCompound nbt) {
		super.readFromNBT(nbt);

		this.missileLoaded = nbt.getBoolean("missileLoaded");

		this.redstonePower = nbt.getInteger("redstonePower");
		this.prevRedstonePower = nbt.getInteger("prevRedstonePower");
		NBTTagCompound activatedBlocks = nbt.getCompoundTag("activatedBlocks");
		this.activatedBlocks.clear();
		for(int i = 0; i < activatedBlocks.func_150296_c().size() / 3; i++) {
			this.activatedBlocks.add(new BlockPos(activatedBlocks.getInteger("x" + i), activatedBlocks.getInteger("y" + i), activatedBlocks.getInteger("z" + i)));
		}
	}

	@Override
	public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
		super.writeToNBT(nbt);

		nbt.setBoolean("missileLoaded", missileLoaded);

		nbt.setInteger("redstonePower", redstonePower);
		nbt.setInteger("prevRedstonePower", prevRedstonePower);
		NBTTagCompound activatedBlocks = new NBTTagCompound();
		int i = 0;
		for(BlockPos p : this.activatedBlocks) {
			activatedBlocks.setInteger("x" + i, p.getX());
			activatedBlocks.setInteger("y" + i, p.getY());
			activatedBlocks.setInteger("z" + i, p.getZ());
			i++;
		}
		nbt.setTag("activatedBlocks", activatedBlocks);
		return nbt;
	}

	public void updateRedstonePower(int x, int y, int z) {
		BlockPos pos = new BlockPos(x, y, z);
		boolean powered = this.world.isBlockIndirectlyGettingPowered(x, y, z);
		boolean contained = activatedBlocks.contains(pos);
		if(!contained && powered){
			activatedBlocks.add(pos);
			if(redstonePower == -1){
				redstonePower = 0;
			}
			redstonePower++;
		} else if(contained && !powered){
			activatedBlocks.remove(pos);
			redstonePower--;
			if(redstonePower == 0){
				redstonePower = -1;
			}
		}
	}

	AxisAlignedBB bb = null;

	@Override
	public AxisAlignedBB getRenderBoundingBox() {

		if(bb == null) {
			bb = AxisAlignedBB.getBoundingBox(
					this.pos.getX() - 2,
					this.pos.getY(),
					this.pos.getZ() - 2,
					this.pos.getX() + 3,
					this.pos.getY() + 15,
					this.pos.getZ() + 3
					);
		}

		return bb;
	}

	@Override
	@SideOnly(Side.CLIENT)
	public double getMaxRenderDistanceSquared() {
		return 65536.0D;
	}

	@Override
	public Container provideContainer(int ID, EntityPlayer player, World world, int x, int y, int z) {
		return new ContainerLaunchPadRusted(player.inventory, this);
	}

	@Override
	@SideOnly(Side.CLIENT)
	public Object provideGUI(int ID, EntityPlayer player, World world, int x, int y, int z) {
		return new GUILaunchPadRusted(player.inventory, this);
	}

	@Override
	public boolean hasPermission(EntityPlayer player) {
		return this.isUsableByPlayer(player);
	}

	@Override
	public void receiveControl(NBTTagCompound data) {
		if(data.hasKey("release")) {
			if(this.missileLoaded && slots[0] == null) {
				this.missileLoaded = false;
				slots[0] = new ItemStack(ModItems.missile_doomsday_rusted);
				this.markDirty();
			}
		}
	}
}
